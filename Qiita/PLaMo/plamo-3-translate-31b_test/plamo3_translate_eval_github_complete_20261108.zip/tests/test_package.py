"""Offline tests: no GPU, no sudo, no real Hugging Face network access."""
from __future__ import annotations

import http.server
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import unittest

KIT_ROOT = Path(__file__).resolve().parents[1]


class TestPackage(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.base = Path(self.td.name)
        self.work = self.base / "plamo_translate_eval"
        self.models = self.base / "models"
        shutil.copytree(KIT_ROOT / "scripts", self.work / "scripts")
        shutil.copytree(KIT_ROOT / "data", self.work / "data")
        (self.work / ".venv/bin").mkdir(parents=True)
        self.hf_log = self.base / "hf.log"
        self.server_log = self.base / "server.log"
        hf = self.work / ".venv/bin/hf"
        hf.write_text("""#!/usr/bin/env python3
import json, os, pathlib, sys
args=sys.argv[1:]
if len(args)<5 or args[0] != 'download' or '--local-dir' not in args:
    sys.exit(2)
i=args.index('--local-dir')
repo=args[1]
files=args[2:i]
folder=pathlib.Path(args[i+1]); folder.mkdir(parents=True, exist_ok=True)
with open(os.environ['FAKE_HF_LOG'], 'a') as fp:
    fp.write(json.dumps({'repo':repo, 'files':files, 'folder':str(folder)})+'\\n')
for name in files:
    (folder/name).write_bytes(b'fake model or template')
""", encoding="utf-8")
        hf.chmod(0o755)
        self.server = self.base / "fake-llama-server"
        self.server.write_text("""#!/usr/bin/env python3
import json, os, sys
with open(os.environ['FAKE_SERVER_LOG'], 'w') as f:
    json.dump(sys.argv[1:], f)
""", encoding="utf-8")
        self.server.chmod(0o755)
        self.env = {
            **os.environ,
            "PLAMO_WORKDIR": str(self.work),
            "PLAMO_MODELS_BASE": str(self.models),
            "FAKE_HF_LOG": str(self.hf_log),
            "FAKE_SERVER_LOG": str(self.server_log),
            "LLAMA_SERVER": str(self.server),
        }

    def tearDown(self):
        self.td.cleanup()

    def cmd(self, *args, ok=True):
        proc = subprocess.run(args, cwd="/", env=self.env, capture_output=True, text=True)
        if ok:
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        return proc

    def test_setup_declares_spirv_headers_dependency(self):
        setup = (KIT_ROOT / "scripts" / "setup_ubuntu.sh").read_text(encoding="utf-8")
        self.assertIn("glslc spirv-headers python3-venv", setup)
        self.assertIn("SPIRV-HeadersConfig.cmake", setup)
        self.assertIn("spirv-headers", setup)

    def test_download_paths_and_skip_existing_31b(self):
        model31 = self.models / "plamo-3-translate-31b-GGUF" / "plamo-3-translate-31b-Q4_K_M.gguf"
        model31.parent.mkdir(parents=True)
        model31.write_bytes(b'existing 31b weight preserved')
        self.cmd("bash", str(self.work / "scripts/download_model.sh"), "31b")
        self.assertEqual(model31.read_bytes(), b'existing 31b weight preserved')
        lines = [json.loads(line) for line in self.hf_log.read_text().splitlines()]
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0]["files"], ["chat_template.jinja"])
        self.assertEqual(lines[0]["folder"], str(model31.parent))
        self.cmd("bash", str(self.work / "scripts/download_model.sh"), "8b")
        model8 = self.models / "plamo-3-translate-8b-GGUF" / "plamo-3-translate-8b-Q4_K_M.gguf"
        self.assertTrue(model8.exists())
        self.assertTrue((model8.parent / "chat_template.jinja").exists())
        lines = [json.loads(line) for line in self.hf_log.read_text().splitlines()]
        self.assertEqual(lines[1]["files"], [model8.name])
        self.assertEqual(lines[1]["folder"], str(model8.parent))
        self.assertEqual(lines[2]["files"], ["chat_template.jinja"])
        self.cmd("bash", str(self.work / "scripts/download_model.sh"), "8b")
        self.assertEqual(len(self.hf_log.read_text().splitlines()), 3)

    def test_start_uses_exact_files_and_chat_template(self):
        self.cmd("bash", str(self.work / "scripts/download_model.sh"), "31b")
        self.cmd("bash", str(self.work / "scripts/start_server.sh"), "31b", "Vulkan1", "8123")
        args = json.loads(self.server_log.read_text())
        self.assertEqual(args[args.index("-m")+1], str(self.models / "plamo-3-translate-31b-GGUF" / "plamo-3-translate-31b-Q4_K_M.gguf"))
        self.assertEqual(args[args.index("--chat-template-file")+1], str(self.models / "plamo-3-translate-31b-GGUF" / "chat_template.jinja"))
        self.assertEqual(args[args.index("--device")+1], "Vulkan1")
        self.assertEqual(args[args.index("--port")+1], "8123")
        self.assertIn("--jinja", args)
        self.assertIn("--no-prefill-assistant", args)
        self.server_log.unlink()
        bad = self.cmd("bash", str(self.work / "scripts/start_server.sh"), "8b", "Vulkan1", ok=False)
        self.assertNotEqual(bad.returncode, 0)
        self.assertFalse(self.server_log.exists(), "wrong size must not run 31B as 8B")
        self.cmd("bash", str(self.work / "scripts/start_server.sh"), "31b", "cpu", "8000")
        args = json.loads(self.server_log.read_text())
        self.assertEqual(args[args.index("--device")+1], "none")
        self.assertEqual(args[args.index("-ngl")+1], "0")

    def test_eval_dry_run_from_unrelated_cwd(self):
        proc = self.cmd("python3", str(self.work / "scripts/run_eval.py"), "--dry-run",
                        "--ids", "en_01_chemistry", "old_04_genji", "--modes", "both",
                        "--conditions", "both")
        self.assertIn("en_01_chemistry", proc.stdout)
        self.assertIn("old_04_genji", proc.stdout)
        self.assertIn("chat_template_kwargs", proc.stdout)
        self.assertIn("<|plamo:tag|>", proc.stdout)

    def test_eval_jsonl_csv_and_resume(self):
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers["Content-Length"])
                request = json.loads(self.rfile.read(length))
                if self.path.endswith("/v1/completions"):
                    obj = {"choices": [{"text": "模擬訳文", "finish_reason": "stop"}],
                           "usage": {"prompt_tokens": 40, "completion_tokens": 5}}
                elif self.path.endswith("/v1/chat/completions"):
                    obj = {"choices": [{"message": {"content": "模擬訳文"}, "finish_reason": "stop"}],
                           "usage": {"prompt_tokens": 40, "completion_tokens": 5}}
                else:
                    self.send_error(404)
                    return
                encoded = json.dumps(obj).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)
            def log_message(self, format, *args):
                pass

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        try:
            output = self.work / "results" / "test.jsonl"
            params = ["python3", str(self.work / "scripts/run_eval.py"), "--url",
                      f"http://127.0.0.1:{server.server_port}", "--ids", "en_01_chemistry",
                      "--modes", "both", "--conditions", "both", "--run-name", "mock",
                      "--output", "results/test.jsonl"]
            self.cmd(*params)
            recs = [json.loads(s) for s in output.read_text().splitlines()]
            self.assertEqual(len(recs), 4)
            self.assertEqual({r["mode"] for r in recs}, {"pfml3", "chat"})
            self.assertTrue(all(r["translation"] == "模擬訳文" and not r["error"] for r in recs))
            self.cmd(*params, "--resume")
            self.assertEqual(len(output.read_text().splitlines()), 4)
            self.cmd("python3", str(self.work / "scripts/summarize.py"), str(output))
            self.assertTrue(output.with_suffix(".csv").exists())
        finally:
            server.shutdown()
            server.server_close()
            t.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
