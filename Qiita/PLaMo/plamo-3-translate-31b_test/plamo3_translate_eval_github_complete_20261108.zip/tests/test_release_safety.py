"""Static tests of the distributable source package; not a guarantee of full privacy."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestReleaseSafety(unittest.TestCase):
    def test_no_hardcoded_personal_home_or_secrets(self):
        scan = [p for folder in ("scripts", "data", "docs", "tests")
                for p in (ROOT / folder).rglob("*") if p.is_file() and p.suffix in (".py", ".sh", ".md", ".jsonl")]
        scan += [ROOT / "README.md", ROOT / "THIRD_PARTY_NOTICES.md", ROOT / "GITHUB_PUBLICATION.md"]
        scan = [p for p in scan if p.name != "test_release_safety.py"]
        for p in scan:
            body = p.read_text(encoding="utf-8")
            with self.subTest(file=p.relative_to(ROOT)):
                self.assertNotRegex(body, r"/home/[A-Za-z0-9_.-]+/")
                self.assertNotIn("github_pat_", body)
                self.assertNotRegex(body, r"hf_[a-zA-Z0-9]{20,}")
