import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def load(name):
    path = ROOT / 'scripts' / f'{name}.py'
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class TestPivotPublicRelease(unittest.TestCase):
    def test_six_cases_four_conditions(self):
        m = load('run_classical_pivot')
        cases = m.load_cases(ROOT / 'data' / 'classical_pivot_cases.jsonl')
        self.assertEqual(len(cases), 6)
        first = cases[0]
        direct = m.plan_first_stage(first, 'A', 'auto')['prompt']
        self.assertIn('<|plamo:val|>ja', direct)
        self.assertNotIn('glossary', direct)
        self.assertNotIn('<|plamo:key|>lang<|plamo:val|>ja<|plamo:msg|>', direct.split('<|plamo:tag|>input',1)[-1].split('<|plamo:tag|>output',1)[0])
        for cond in ['B','C','D']:
            p = m.plan_first_stage(first, cond, 'auto')['prompt']
            self.assertIn('<|plamo:val|>en', p)
        self.assertIn('<|plamo:tag|>context', m.plan_first_stage(first, 'C', 'auto')['prompt'])
        self.assertIn('<|plamo:tag|>glossary', m.plan_first_stage(first, 'D', 'auto')['prompt'])
        self.assertNotIn('<|plamo:tag|>glossary', m.plan_second_stage('The dawn.')['prompt'])

    def test_dry_run_without_server(self):
        p = subprocess.run([sys.executable, str(ROOT/'scripts/run_classical_pivot.py'),
                            '--dry-run', '--ids','old_01_makura','--conditions','A','B','C','D',
                            '--direct-source','auto'], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, msg=p.stderr)
        self.assertIn('old_01_makura', p.stdout)
        self.assertNotIn('/home/', p.stdout)

    def test_summarize_without_real_results(self):
        m = load('summarize_classical_pivot')
        rec={'case_id':'t','condition':'A','run_name':'synthetic','status':'ok',
             'server_model_filename':'dummy.gguf','source_text':'テスト','final_japanese':'test',
             'stages':[{'stage':'direct','elapsed_seconds':0.5,'usage':{'prompt_tokens':1,'completion_tokens':1}}],
             'total_elapsed_seconds':0.5,'signature':'local-test-signature'}
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)
            source=out/'r.jsonl'
            source.write_text(json.dumps(rec,ensure_ascii=False)+'\n','utf8')
            self.assertEqual(m.main([str(source),'--out-dir',str(out/'summary')]),0)
            self.assertTrue((out/'summary'/'classical_pivot_comparison.md').is_file())
            self.assertTrue((out/'summary'/'classical_pivot_results.csv').is_file())
