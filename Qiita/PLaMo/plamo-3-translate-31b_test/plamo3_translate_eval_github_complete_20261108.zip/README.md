# PLaMo 3 Translate local evaluation kit (Ubuntu / Vulkan / 8B & 31B)

[日本語] **PLaMo 3 Translate** のGGUF Q4_K_M形式を `llama.cpp` でローカル実行し、英語→日本語の翻訳と、公式には対応が保証されていない古文→現代日本語の直接変換およびピボット翻訳（古文→英語→現代日本語）を試す検証キットです。

**Built with PLaMo** — このリポジトリはPFNの公式製品ではありません。モデルの権利・利用条件は [PLaMoコミュニティライセンス](https://plamo.preferredai.jp/info/plamo-community-license-ja) に従います。コード部分のMITライセンスはモデル重みには適用されません。**重み・モデル生成訳文・外部ソフトウェアは同梱していません。**

2026-11-08版。構文・引数・模擬HTTP API・保存先をオフラインで検証しています。開発元の検証環境では31B Q4_K_MをIntel GPU（Vulkan）で動作させていますが、配布物がすべての環境で動作する保証はありません。翻訳品質の人手による定量評価は未実施です。

## 目次

- [要件とディレクトリ](#要件とディレクトリ)
- [初回導入](#初回導入)
- [モデル取得](#モデル取得)
- [サーバーと検証](#サーバーと検証)
- [古文実験の制約](#古文実験の制約)
- [成果物と公開時の留意事項](#成果物と公開時の留意事項)

## 要件とディレクトリ

- Ubuntu 26.04/26.10等のVulkanを使用できるLinux環境。`vulkaninfo --summary`でGPUを確認してください。
- 8B・31Bのいずれか。モデルファイルのダウンロード容量とGPU/システムメモリに余裕が必要です。
- `sudo` と Hugging Face へのネットワークアクセス（初回構築・取得時）。
- CUDA、SYCL、Intel oneAPI、PyTorchは本キットの導入対象ではありません。Vulkan backendを使用します。

特定のユーザー名は使いません。既定のディレクトリは以下です。

| 用途 | 既定の場所 |
|---|---|
| プロジェクト | このZIPの展開先（例：`$HOME/llm/plamo_translate_eval/`） |
| モデル | `$HOME/models/plamo-3-translate-{8b,31b}-GGUF/` |
| llama.cpp | `<プロジェクト>/vendor/llama.cpp/` |
| Python venv | `<プロジェクト>/.venv/` |
| JSONL/CSV | `<プロジェクト>/results/`（Git管理対象外） |

既存のモデル保存先を使う場合は`PLAMO_MODELS_BASE=/path/to/models`を各シェルコマンドの前に付けてください。作業ディレクトリはZIPを展開したディレクトリから自動判定します。プロジェクトの配置先は自由です。

## 初回導入

ZIPを`$HOME/Downloads/`に保存してから、例として次のように展開します。ファイル名は実際にダウンロードしたものと一致させてください。

```bash
mkdir -p "$HOME/llm/plamo_translate_eval"
unzip -o "$HOME/Downloads/plamo3_translate_eval_public_20261108.zip" \
  -d "$HOME/llm/plamo_translate_eval"
cd "$HOME/llm/plamo_translate_eval"
bash scripts/setup_ubuntu.sh
```

`setup_ubuntu.sh`はaptで `libvulkan-dev`, `glslc`, **`spirv-headers`** などを導入し、llama.cppをクローンしてVulkan版llama-serverをビルドします。既存のllama.cppチェックアウトは自動更新しません。インストール済みパッケージを変更したくない場合は `SKIP_APT=1` を指定できますが、依存パッケージは自分で用意してください。

デバイスを確認します。

```bash
./vendor/llama.cpp/build-plamo-vulkan/bin/llama-server --list-devices
```

`Vulkan0`などの番号は**NVIDIAとIntel GPUを搭載するPCでも変わり得ます**。必ずこの一覧で確認してください。B70を利用する場合もGPU番号を推測しないでください。単一GPUを指定する場合、他のGPUのVRAMが自動的に加算されるわけではありません。

### CMakeエラー対策

旧構成で `Could not find a package configuration file provided by "SPIRV-Headers"` と表示されるときは以下を実行します。

```bash
sudo apt-get install -y spirv-headers
bash scripts/setup_ubuntu.sh
```

インストール後の成功可否は、実機のCMake/ビルド出力で確認してください。`No DRI3 support detected` などの描画系警告とは区別します。

## モデル取得

```bash
bash scripts/download_model.sh 31b
bash scripts/download_model.sh 8b
bash scripts/check_environment.sh
```

- `31b`: `$HOME/models/plamo-3-translate-31b-GGUF/plamo-3-translate-31b-Q4_K_M.gguf`
- `8b`: `$HOME/models/plamo-3-translate-8b-GGUF/plamo-3-translate-8b-Q4_K_M.gguf`

両モデルはHugging Face `pfnet/plamo-3-translate-*-GGUF` から取得します。**同名ファイルが既に存在するときは上書き・再ダウンロードしません**。 `chat_template.jinja` は不足する場合に取得します。ファイルの存在チェックはハッシュ整合性まで保証しません。モデルカードの更新で再取得が必要になったときは、公式の改訂履歴を確認してください。

モデル出典:

- [31B GGUF](https://huggingface.co/pfnet/plamo-3-translate-31b-GGUF)
- [8B GGUF](https://huggingface.co/pfnet/plamo-3-translate-8b-GGUF)

## サーバーと検証

### 端末A：サーバー起動

```bash
cd "$HOME/llm/plamo_translate_eval"
bash scripts/start_server.sh 31b Vulkan1 8000
# または 8B
# bash scripts/start_server.sh 8b Vulkan1 8000
# CPU専用: bash scripts/start_server.sh 8b cpu 8000
```

`Vulkan1`は例であり、実際の識別名に変更してください。`CTX=4096`、`THREADS=8`、`GPU_LAYERS=999`などの環境変数でも調整できます。サーバーは`127.0.0.1`にのみバインドします。

### 端末B：API確認と評価

```bash
cd "$HOME/llm/plamo_translate_eval"
curl -sS http://127.0.0.1:8000/health | jq .
# モデルを実行せずプロンプト構造だけ確認
python3 scripts/run_eval.py --dry-run --ids en_01_chemistry old_04_genji \
  --modes both --conditions both
# 12題×2条件 = 24回（PFML3）
python3 scripts/run_eval.py --run-name 31b_q4_vulkan \
  --modes pfml3 --conditions both --output results/31b_pfml3.jsonl
# 人間が読めるCSVを出力
python3 scripts/summarize.py results/31b_pfml3.jsonl
```

8Bと比較するには端末Aの31Bサーバーを停止して8Bを起動し、`--run-name 8b_q4_vulkan`と`--output results/8b_pfml3.jsonl`を使います。途中からの続行は同じ引数とファイルに`--resume`を追加します。`--modes chat`でChat Completions APIも試せます。

PFNのモデルカードは、直接PFML3プロンプトを作るCompletions APIを本番利用向けとして案内しています。翻訳専用プロンプトは次の構造です（実際には改行せず連結）。

```text
<|plamo:tag|>dataset<|plamo:msg|>translation
<|plamo:tag|>input<|plamo:key|>lang<|plamo:val|>en<|plamo:msg|>The bank was muddy.
<|plamo:tag|>output<|plamo:key|>lang<|plamo:val|>ja<|plamo:key|>form<|plamo:val|>plain<|plamo:msg|>
```

参考文脈 `context` と用語集 `glossary` はオプションです。公式形式の詳細は各モデルカードを参照してください。

## 古文実験の制約

古文→現代日本語は **日本語→日本語の同一言語翻訳** であり、PFNが精度保証する翻訳方向ではありません。`--classical-source auto`（入力言語を省略）と`--classical-source ja`（明示）を比較できますが、いずれも対応を保証するものではありません。原文を単純にコピーするなどの挙動も失敗例として保存してください。

比較条件は英日6題・古文6題の各 `baseline`（補助情報なし）、`assisted`（参考文脈・用語集あり）です。`assisted` に正解に近い語義情報が入る場合は、その情報が結果に影響するため、モデル単独の能力と分けて評価します。

## 古文の4条件（直接・英語経由）

初回の `baseline`／`assisted` は直接翻訳であり、追加実験の A～D とは別の測定です。今回の `data/classical_pivot_cases.jsonl` は古文6題、各作品の参考文脈と古語→英語の用語集を含みます。

| 条件 | 内容 | API呼び出し／6題 |
|---|---|---:|
| A | 古文→日本語（直接翻訳） | 6 |
| B | 古文→英語→日本語（補助情報なし） | 12 |
| C | Bの第1段階に参考文脈を追加 | 12 |
| D | Bの第1段階に古語→英語の用語集を追加 | 12 |

端末Aで31Bモデルのサーバーを起動したまま、別の端末で以下を実行します（既存の `results/31b_pfml3.jsonl` は上書きしません）。

```bash
cd "$HOME/llm/plamo_translate_eval"
python3 scripts/run_classical_pivot.py --dry-run --conditions A B C D   --direct-source auto --expected-size 31b
python3 scripts/run_classical_pivot.py --expected-size 31b   --run-name 31b_Q4KM_vulkan_pivot --direct-source auto   --conditions A B C D --output results/31b_classical_pivot.jsonl --resume
python3 scripts/summarize_classical_pivot.py results/31b_classical_pivot.jsonl   --out-dir results/pivot_comparison
```

出力される `results/*.jsonl`, `results/*_raw/`, `results/pivot_comparison/` は `.gitignore` でGit追跡の対象外です。公開する際は出典と生成物のライセンス、個人情報を別途点検してください。

## 成果物と公開時の留意事項

`results/*.jsonl`は原文・訳文・送信リクエスト・APIの応答・経過時間などを含みます。`results/*.csv`は集計用です。翻訳品質の自動採点は実装していません。`exact_copy` / `similarity`は原文との一致率の簡易指標であり、意味の正確性を表しません。`generated_tokens_per_second`はHTTP要求全体の経過時間から計算する参考値で、純粋なデコード速度ではありません。

**公開する場合は** `PUBLICATION_CHECKLIST.md` と `THIRD_PARTY_NOTICES.md` を確認してください。特にPLaMoの生成結果を記事やリポジトリに掲載する場合は、PLaMo生成物であることの明記とライセンス条項を確認する必要があります。

```bash
python3 -m unittest discover -s tests -v
```

GitHubに公開する場合は、このZIPを**空のリポジトリ**へ展開して公開し、モデル本体・実行ログ・秘密情報を加えないことを推奨します。このリポジトリのソースコードはMIT Licenseですが、PFNのモデルには適用されません。
