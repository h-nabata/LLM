# PLaMo 3 Translate 検証用課題集

**英語6題**は本パッケージで新規作成した文章です。**古文6題**は著作権保護期間が満了した古典作品の原文（校訂や表記の差に留意）から採りました。現代語訳を他サイトから転載していません。

## en_01_chemistry｜触媒反応の速度論と熱力学（新規作成英文）

**原文**

Two catalysts were tested for the same hypothetical oxidation reaction. Catalyst A had a calculated activation barrier of 84 kJ/mol, while catalyst B had a barrier of 91 kJ/mol. It would be tempting to conclude that A must always produce more product. That conclusion does not follow. At high coverage, a strongly adsorbed intermediate can occupy active sites and slow the overall reaction. Moreover, the lowest barrier on a proposed pathway need not control the observed rate if an earlier step is much slower. The calculations also neglect solvent effects, which may change the relative stability of the intermediates. The researchers therefore reported the two barriers as model predictions, not as experimentally measured rate constants. They recommended comparing the full reaction networks under a common set of conditions before choosing a catalyst.

**評価点**

- 84と91 kJ/molを取り違えない
- 障壁が低いことを生成量の多さと断定しない
- 吸着中間体の被覆と活性点阻害の因果関係を維持する
- 計算予測と実測速度定数を区別する

## en_02_bank｜銀行と川岸、代名詞の指示対象（新規作成英文）

**原文**

The town had two banks, but only one of them handled money. The other was a narrow strip of land beside the river, where children skipped stones after school. When the financial bank announced that it would close its branch, the mayor said the decision would leave the community stranded. The newspaper quoted her without explaining that the only bridge to the neighboring town had also been closed for repairs. A visitor reading the article assumed that customers could simply cross the river to another branch. The locals knew otherwise: the ferry ran only on Saturdays, and the nearest cash machine was inside a hospital that did not admit visitors after six. By the time the bridge reopened, the bank had already converted the branch into a library.

**評価点**

- banksが金融機関と川岸を指すことを正しく区別
- strandedに物理的なアクセスの問題も含まれる
- フェリーの運航日は土曜のみ
- 支店の跡が図書館になった順序を維持

## en_03_conditionals｜複雑な条件文と否定のスコープ（新規作成英文）

**原文**

The controller must not start the pump unless both temperature sensors agree within 0.2 degrees Celsius. If either sensor stops responding, the system records a fault even when the remaining sensor reports a normal value. A technician may reset the fault only after verifying that the communication link is working; a reset alone does not authorize the pump to restart. During a scheduled inspection, the controller can be placed in test mode, but only the warning light—not the pump—is allowed to operate. This rule applies even if the operator believes the water temperature is safe. The report should distinguish between an observed sensor disagreement and a sensor that returned no data at all.

**評価点**

- 両センサーの一致条件0.2℃を維持
- いずれか無応答のとき異常記録
- リセットだけでは再起動できない
- 試験モードでは警告灯のみ動作しポンプは動作しない

## en_04_counterfactual｜反実仮想と時間順序（新規作成英文）

**原文**

Had Mira opened the envelope on Tuesday, the expedition might never have left the harbor. But the letter lay beneath a broken clock, and she did not find it until Thursday evening. By then the research vessel had departed, taking with it the only instrument capable of measuring the faint signal described in the letter. Mira had once dismissed that signal as noise. Now she wondered whether what she had called an error was, in fact, the first hint of something new. Her colleague insisted that uncertainty was no reason to rewrite the past. “We can change tomorrow’s plan,” he said, “but we cannot change what Tuesday meant to us on Tuesday.” She put the letter back in its envelope, not because she agreed, but because she needed another hour to think.

**評価点**

- 火曜日に開封したわけではない反実仮想を保持
- 発見は木曜夕方で出航後
- ノイズと新現象の兆候の区別が不確実
- 封筒に戻したのは同意ではなく考える時間が欲しかったため

## en_05_review｜審査コメントの慎重な評価表現（新規作成英文）

**原文**

The review panel did not reject the proposal outright. It agreed that the underlying question was worth investigating, but found the evidence too limited to support the authors’ strongest claim. In particular, the reported improvement was smaller than the uncertainty estimated from repeated measurements. The panel requested an independent replication and a clear statement of which parameters had been selected after inspecting the results. Until those analyses are available, the claim should be described as preliminary rather than disproven. The panel also emphasized that a negative replication would not, by itself, prove the entire research program misguided; it would instead narrow the range of explanations consistent with the data.

**評価点**

- 全面却下ではない
- 改善量が繰返し測定の不確かさより小さい
- 事後選択したパラメータの開示を求める
- 追試不成功でも全研究計画の誤りの証明にはならない

## en_06_poetry｜詩の比喩と改行（新規作成英文）

**原文**

At dawn the railway kept its promises,
though none of its passengers knew to whom.
A timetable hung beside the empty gate,
precise about hours, silent about arrivals.
The city woke one window at a time;
a single light stayed on for someone who had left.

**評価点**

- 比喩「鉄道は約束を守った」を説明的に消し過ぎない
- 誰に対する約束かを勝手に確定しない
- 時刻表の時間と到着の対比を保持
- 最後の光と去った人物の関係を推測で確定しない

## old_01_makura｜枕草子・春と夏（季節描写）

原文出典：https://ja.wikisource.org/wiki/枕草子_(Wikisource)/第一段

**原文**

春はあけぼの。やうやう白くなりゆく山ぎは少し明りて紫だちたる雲の細くたなびきたる。夏は夜。月の頃はさらなり。闇もなほ螢の多く飛び違ひたる。

**評価点**

- 「春はあけぼの」を春の夜明けごろと解釈
- 山ぎはを山麓ではなく山と空の境目と捉える
- 夏は夜、月のある夜は言うまでもないという評価を保持
- 蛍の光の情景を訳す

## old_02_tsurezure｜徒然草・序段（心理描写）

原文出典：https://ja.wikisource.org/wiki/徒然草_(國文大觀)

**原文**

つれづれなるまゝに、日ぐらし硯にむかひて、心にうつりゆくよしなしごとを、そこはかとなく書きつくれば、あやしうこそものぐるほしけれ。

**評価点**

- 日ぐらしを夕暮れと誤訳しない
- することがないことと書き記す行動の関係を保持
- あやしうこそものぐるほしけれの心理表現を単なる喜びに変えない

## old_03_hojoki｜方丈記・冒頭（無常観と比喩）

原文出典：https://yatanavi.org/text/daifukuhojoki

**原文**

ゆく河の流れは絶えずして、しかももとの水にあらず。よどみにうかぶうたかたはかつ消えかつ結びて、久しくとどまりたるためしなし。世中にある人と栖と又かくのごとし。

**評価点**

- 流れは続くが同じ水ではないという対比
- 泡の生成消滅を保つ
- 最後の世の人と住まいへの比喩を落とさない

## old_04_genji｜源氏物語・桐壺（敬語と身分）

原文出典：https://ja.wikisource.org/wiki/源氏物語/桐壺

**原文**

いづれの御時にか、女御、更衣あまたさぶらひたまひけるなかに、いとやむごとなき際にはあらぬが、すぐれて時めきたまふありけり。はじめより我はと思ひ上がりたまへる御方がた、めざましきものにおとしめ嫉みたまふ。

**評価点**

- 身分が最高位ではない妃が特に寵愛された
- 高位の妃たちの嫉妬を適切な主体に割り当てる
- 敬語の対象を取り違えない
- めざましきを単なる素晴らしいと誤解しない

## old_05_taketori｜竹取物語・発見（説話と敬語）

原文出典：https://ja.wikisource.org/wiki/竹取物語_(國民文庫)

**原文**

今は昔竹取の翁といふものありけり。野山にまじりて、竹をとりつゝ、萬の事につかひけり。名をば讃岐造麿となんいひける。その竹の中に、本光る竹ひとすぢありけり。怪しがりて寄りて見るに、筒の中ひかりたり。それを見れば、三寸ばかりなる人いと美しうて居たり。

**評価点**

- 翁の生活描写を含む
- 名は讃岐造麿
- 光る竹から小さな人物を発見
- 三寸の大きさを消さない
- 美しうの古語の意味を文脈で判断

## old_06_basho｜おくのほそ道・冒頭（漢文訓読と旅）

原文出典：https://www.aozora.gr.jp/cards/002240/files/61619_78128.html

**原文**

月日は百代の過客にして、行きかふ年も又旅人也。舟の上に生涯をうかべ、馬の口とらへて老をむかふる物は、日々旅にして旅を栖とす。古人も多く旅に死せるあり。

**評価点**

- 月日・行き交う年を旅人にたとえる
- 舟に生涯を浮かべる人と馬の口を取る人を描く
- 日々の旅をすみかとする比喩を維持
- 古人が旅で死んだという結びを保持

