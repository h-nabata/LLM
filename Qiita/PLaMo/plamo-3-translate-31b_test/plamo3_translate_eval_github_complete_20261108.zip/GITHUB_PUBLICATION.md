# GitHub公開用チェック

この配布ZIPは**作成済みのスクリプトとサンプルデータのみ**を収録している。`vendor/llama.cpp`は含まれず、初回セットアップ時に公式GitHubから取得する。GGUFモデル、認証情報、計測結果、ローカルAPIの生ログは収録していない。

## 公開前に点検すること

1. 新規の空リポジトリに、このZIPの内容だけを展開する。過去の作業ディレクトリやGit履歴を持ち込まない。
2. `git status --short` と `git diff --cached --name-only` に `vendor/`、`.venv/`、`models/`、`results/`、秘密鍵、認証情報、ローカルログがないことを確認する。
3. `git config --get user.name` および `git config --get user.email` で公開されるコミット作者情報を確認する。GitHubのnoreplyメールも利用できる。
4. `bash -n scripts/*.sh` と `python3 -m unittest discover -s tests -v` を実行し、実際のLinux環境での起動も再確認する。
5. 原文の採用底本・校訂・再配布条件を確認する。`LICENSE`のMITはオリジナルのコードに適用し、第三者の文献やモデルには適用しない。
6. 将来`data/`や`docs/`に私的な文章を加える際は、`.gitignore`だけに依存しないで内容を点検する。

## セキュリティと再現性の制約

- `start_server.sh`は `--host 127.0.0.1` を設定し、外部ネットワークへ直接公開しない。接続先は通常ローカルAPIである。
- `setup_ubuntu.sh`は `sudo apt-get` を実行し、上流の `llama.cpp` とPyPIの `huggingface_hub` を取得する。上流の更新・依存関係に関する一般的なサプライチェーンリスクは残る。必要に応じてコミット・パッケージのバージョンを固定する。
- ダウンロード済みのGGUFファイルは存在とサイズのみを確認し、ハッシュ検証をしていない。厳密な再現実験にはファイルハッシュの記録が必要である。
- この配布物は簡易的な静的監査とオフラインテストを通過したが、脆弱性診断や完全な情報漏洩防止を保証するものではない。

## 推奨公開操作

```bash
cd /path/to/new/empty-repo
python3 -m unittest discover -s tests -v
bash -n scripts/*.sh
git init
git add README.md LICENSE .gitattributes .gitignore \
  PUBLICATION_CHECKLIST.md THIRD_PARTY_NOTICES.md GITHUB_PUBLICATION.md \
  scripts/ data/ tests/ docs/ results/.keep
git diff --cached --name-only
git diff --cached --check
```

`git diff --cached --name-only`で差分の一覧を見てからコミットする。
