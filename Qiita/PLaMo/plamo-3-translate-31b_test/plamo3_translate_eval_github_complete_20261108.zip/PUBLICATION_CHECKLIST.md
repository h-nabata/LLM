# GitHub/Qiita公開前チェック（日本語）

- [ ] **検証実績**: 実機で成功した作業、未検証作業、失敗例を区別。CMakeエラーの解決を確認する前に「解決済み」と断定しない。
- [ ] **個人情報**: ホームディレクトリのユーザー名、メールアドレス、ホスト名、SSH鍵、アクセストークン、HF認証キャッシュ、写真のEXIFを含めない。
- [ ] **Git履歴**: `git log --format=fuller`で作者名・メールを確認し、必要ならGitHub noreplyメールを利用。過去に機密をコミットした場合は.gitignoreだけでは消えない。
- [ ] **Git対象**: `git status --short`と`git ls-files`を確認。`vendor/`, `.venv/`, `results/`, `models/`, `*.gguf`, `.env`を含めない。
- [ ] **実験条件**: Ubuntu版、GPU、ドライバ、Vulkan、llama.cpp commit、GGUF量子化形式、文脈長、生成パラメータ、実行モデルを記録。
- [ ] **性能**: 翻訳品質の人手採点と推論時間を区別。自動の原文一致率は翻訳品質スコアではない。HTTP全体所要時間から求めたtokens/sはデコード専用速度ではない。
- [ ] **法的事項**: モデル本体は配布しない。PFNコミュニティライセンスを参照し、PLaMo出力を公開する場合は規約第4・5条を確認。
- [ ] **資料の権利**: 英文は評価用に新規作成したテキスト。古文は原典の公開状況・採用底本・校訂者の権利を再確認。近現代の現代語訳は転載しない。
- [ ] **スクリーンショット**: ターミナルのプロンプト、絶対パス、ユーザー名、ホスト名、GitHubトークン、隣接する別プロジェクトを隠す。
- [ ] **結果の公開**: JSONLには元テキスト・訳文・生APIレスポンスが含まれるため、データを追加した場合は内容を点検。

## 公開前の最低限のコマンド

```bash
python3 -m unittest discover -s tests -v
bash -n scripts/*.sh
# .gitignoreの対象も意図通りか確認
git status --short
# 初回commit前にファイル一覧とdiffを確認
git diff --cached --name-only
git diff --cached --check
# 追跡対象の本文からパスや認証情報を検索（目視確認も必要）
git grep -n -I -E '(/home/[^/]+/|/Users/[^/]+/|BEGIN .*PRIVATE KEY|hf_[A-Za-z0-9]{20,}|github_pat_)' -- ':!PUBLICATION_CHECKLIST.md' || true
```

GitHubへ公開する場合、初回は**新規の空リポジトリ**にこの配布物だけを入れてください。過去のローカル作業ディレクトリを `git add .` で一括投入しない方が安全です。
