#!/usr/bin/env python3
"""Summarize local results; similarity is a diagnostic, NOT translation quality."""
import argparse
import csv
import difflib
import json
import re
import statistics
from pathlib import Path


def normalize(text):
    return re.sub(r"[\s、。,.！!？?「」『』\"'（）()]+", "", text or "")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("results", type=Path)
    args = p.parse_args()
    rows = [json.loads(s) for s in args.results.read_text(encoding="utf-8").splitlines() if s.strip()]
    if not rows:
        raise SystemExit("No records")
    csv_file = args.results.with_suffix(".csv")
    fields = ["run_name", "id", "kind", "mode", "condition", "translation", "elapsed_seconds",
              "generated_tokens_per_second", "finish_reason", "prompt_tokens", "completion_tokens",
              "exact_copy", "similarity", "error"]
    csv_rows = []
    for row in rows:
        original, rendered = normalize(row["source_text"]), normalize(row.get("translation"))
        ratio = difflib.SequenceMatcher(None, original, rendered, autojunk=False).ratio() if original or rendered else 1.0
        csv_rows.append({
            "run_name": row.get("run_name", ""), "id": row["id"], "kind": row["kind"],
            "mode": row["mode"], "condition": row["condition"], "translation": row.get("translation", ""),
            "elapsed_seconds": row.get("elapsed_seconds"),
            "generated_tokens_per_second": row.get("generated_tokens_per_second"),
            "finish_reason": row.get("finish_reason"),
            "prompt_tokens": row.get("usage", {}).get("prompt_tokens"),
            "completion_tokens": row.get("usage", {}).get("completion_tokens"),
            "exact_copy": original == rendered,
            "similarity": round(ratio, 3), "error": row.get("error") or "",
        })
    with csv_file.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(csv_rows)
    print(f"Results: {len(rows)} | CSV: {csv_file}")
    for kind in ("english", "classical"):
        sample = [x for x in csv_rows if x["kind"] == kind]
        if not sample:
            continue
        successful = [x for x in sample if not x["error"]]
        times = [x["elapsed_seconds"] for x in successful if x["elapsed_seconds"] is not None]
        copies = [x for x in successful if x["exact_copy"]]
        print(f"{kind}: runs={len(sample)}, ok={len(successful)}, exact source copies={len(copies)}, "
              f"median elapsed={statistics.median(times):.2f}s" if times else f"{kind}: no successful runs")
    print("NOTE: exact copy / similarity is NOT an automatic quality metric. Inspect each translation manually.")


if __name__ == "__main__":
    main()
