#!/usr/bin/env python3
"""Export the four-condition experiment JSONL to CSV, Markdown, and review sheets."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

CONDITIONS = ("A", "B", "C", "D")
LABELS = {
    "A": "直接：古文→現代日本語",
    "B": "ピボット：古文→英語→現代日本語",
    "C": "ピボット＋参考文脈（第1段階のみ）",
    "D": "ピボット＋古語→英語の用語集（第1段階のみ）",
}


def read_records(paths: list[Path]) -> list[dict]:
    records = []
    for path in paths:
        with path.open(encoding="utf-8") as fp:
            for n, line in enumerate(fp, 1):
                if not line.strip():
                    continue
                try:
                    r = json.loads(line)
                except ValueError as exc:
                    raise ValueError(f"{path}:{n}: {exc}") from exc
                if r.get("case_id") and r.get("condition") in CONDITIONS:
                    records.append(r)
    if not records:
        raise ValueError("No classical-pivot experiment records found")
    return records


def latest_by_key(records: list[dict]) -> list[dict]:
    # The latest record for a unique run+model+case+condition+signature is shown;
    # failed attempts cannot silently override an earlier success for that signature.
    chosen: dict[tuple, dict] = {}
    for rec in records:
        key = (rec.get("run_name"), rec.get("server_model_filename"),
               rec.get("case_id"), rec.get("condition"), rec.get("signature"))
        if key not in chosen or rec.get("status") == "ok" or chosen[key].get("status") != "ok":
            chosen[key] = rec
    return sorted(chosen.values(), key=lambda r: (r.get("run_name") or "",
                      r.get("case_id") or "", CONDITIONS.index(r["condition"])))


def flatten(rec: dict) -> dict:
    stages = rec.get("stages") or []
    ja_to_en = stages[0] if rec.get("condition") != "A" and stages else None
    final_stage = stages[-1] if stages else None
    usage = [s.get("usage") or {} for s in stages]
    prompt_tokens = sum(u.get("prompt_tokens") or 0 for u in usage)
    completion_tokens = sum(u.get("completion_tokens") or 0 for u in usage)
    return {
        "run_name": rec.get("run_name"),
        "model_filename": rec.get("server_model_filename"),
        "case_id": rec.get("case_id"),
        "title": rec.get("title"),
        "condition": rec.get("condition"),
        "condition_label": LABELS[rec["condition"]],
        "status": rec.get("status"),
        "source_text": rec.get("source_text"),
        "intermediate_english": rec.get("intermediate_english"),
        "final_japanese": rec.get("final_japanese"),
        "stage1_seconds": stages[0].get("elapsed_seconds") if stages else None,
        "stage2_seconds": stages[1].get("elapsed_seconds") if len(stages) > 1 else None,
        "total_elapsed_seconds": rec.get("total_elapsed_seconds"),
        "total_prompt_tokens": prompt_tokens,
        "total_completion_tokens": completion_tokens,
        "first_stage_finish_reason": ja_to_en.get("finish_reason") if ja_to_en else None,
        "final_finish_reason": final_stage.get("finish_reason") if final_stage else None,
        "evaluation_points": " / ".join(rec.get("evaluation_points") or []),
        "error": rec.get("error"),
        "signature": rec.get("signature"),
        "source_url": rec.get("source_url"),
    }


def safe_code_fence(s: str) -> str:
    if not s:
        return "（出力なし）"
    n = 4
    while "`" * n in s:
        n += 1
    fence = "`" * n
    return f"{fence}text\n{s}\n{fence}"


def make_markdown(records: list[dict]) -> str:
    grouped: dict[tuple, list[dict]] = defaultdict(list)
    for r in records:
        grouped[(r.get("run_name"), r.get("server_model_filename"), r["case_id"])].append(r)
    out = ["# 古文→現代日本語：4条件の出力比較", "",
           "生成文はPLaMo 3 Translateによるものです（Built with PLaMo）。",
           "人手による正確性の採点は未実施です。出力が自然でも解釈の誤りはあり得ます。",
           "CとDの補助情報は英訳段階にのみ与え、英語→日本語段階では与えていません。", ""]
    for (run, model, case_id), items in sorted(grouped.items()):
        first = items[0]
        out += [f"## {run} / {case_id} — {first.get('title') or ''}", "",
                f"- モデルファイル: `{model or 'unknown'}`", "",
                "**原文**", "", safe_code_fence(first.get("source_text") or ""), ""]
        if first.get("source_url"):
            out += [f"原文の出典：{first['source_url']}", ""]
        for cond in CONDITIONS:
            matches = [r for r in items if r["condition"] == cond]
            if not matches:
                out += [f"### {cond}. {LABELS[cond]}", "", "未実行", ""]
                continue
            r = matches[-1]
            out += [f"### {cond}. {LABELS[cond]}", "",
                    f"結果：**{r.get('status') or 'unknown'}**、処理時間：{r.get('total_elapsed_seconds')}秒", ""]
            if cond != "A":
                out += ["中間英文：", "", safe_code_fence(r.get("intermediate_english") or ""), ""]
            out += ["現代日本語訳：", "", safe_code_fence(r.get("final_japanese") or ""), ""]
            if r.get("error"):
                out += [f"エラー：`{str(r['error']).replace('`', '')}`", ""]
        out += ["**人手評価の着眼点**", ""]
        for point in first.get("evaluation_points") or []:
            out.append(f"- {point}")
        out += [""]
    return "\n".join(out) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("files", type=Path, nargs="+", help="Result JSONL from one or both model sizes")
    ap.add_argument("--out-dir", type=Path, help="Output directory (default: first input parent/comparison)")
    args = ap.parse_args(argv)
    out = args.out_dir or args.files[0].parent / "comparison"
    out.mkdir(parents=True, exist_ok=True)
    records = latest_by_key(read_records(args.files))
    rows = [flatten(r) for r in records]
    csv_path = out / "classical_pivot_results.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    md_path = out / "classical_pivot_comparison.md"
    md_path.write_text(make_markdown(records), encoding="utf-8")
    template_path = out / "human_review_template.csv"
    with template_path.open("w", encoding="utf-8-sig", newline="") as fp:
        cols = ["run_name", "case_id", "condition", "status", "semantic_fidelity_0_to_3",
                "classical_grammar_0_to_3", "referents_honorifics_0_to_3",
                "fluency_0_to_3", "unjustified_additions_0_to_3", "reviewer_notes"]
        writer = csv.DictWriter(fp, fieldnames=cols)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k) for k in ("run_name", "case_id", "condition", "status")})
    summary = Counter((r.get("run_name"), r.get("condition"), r.get("status")) for r in records)
    print("Results by run / condition / status:")
    for (run, cond, status), count in sorted(summary.items()):
        print(f"  {run} / {cond} / {status}: {count}")
    print("Created:")
    for p in [csv_path, md_path, template_path]:
        print(f"  {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
