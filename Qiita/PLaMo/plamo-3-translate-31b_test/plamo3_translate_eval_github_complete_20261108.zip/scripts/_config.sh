#!/usr/bin/env bash
# Portable paths for Ubuntu/Linux: the project is the directory containing scripts/.
# Override the model base with PLAMO_MODELS_BASE if necessary.
set -euo pipefail
SCRIPT_PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
PROJECT_DIR="${PLAMO_WORKDIR:-$SCRIPT_PROJECT_DIR}"
if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "ERROR: project directory does not exist: $PROJECT_DIR" >&2
  exit 2
fi
PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd -P)"
if [[ "$SCRIPT_PROJECT_DIR" != "$PROJECT_DIR" ]]; then
  echo "ERROR: scripts are installed under $SCRIPT_PROJECT_DIR" >&2
  echo "       PLAMO_WORKDIR resolves to $PROJECT_DIR" >&2
  echo 'Run scripts from this unpacked project, or set PLAMO_WORKDIR to that directory.' >&2
  exit 2
fi
MODELS_BASE="${PLAMO_MODELS_BASE:-$HOME/models}"
LLAMA_SOURCE="$PROJECT_DIR/vendor/llama.cpp"
LLAMA_BUILD="$LLAMA_SOURCE/build-plamo-vulkan"
LLAMA_SERVER_DEFAULT="$LLAMA_BUILD/bin/llama-server"
VENV_DIR="$PROJECT_DIR/.venv"
model_dir() {
  case "$1" in
    8b|31b) printf '%s/plamo-3-translate-%s-GGUF\n' "$MODELS_BASE" "$1" ;;
    *) echo "Only 8b and 31b are supported by this evaluation kit" >&2; return 2 ;;
  esac
}
model_filename() { printf 'plamo-3-translate-%s-Q4_K_M.gguf\n' "$1"; }
