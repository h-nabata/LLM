#!/usr/bin/env python3
"""Four-way classical Japanese evaluation with PLaMo 3 Translate via llama.cpp.

A: old Japanese -> modern Japanese (unsupported same-language translation)
B: old Japanese -> English -> modern Japanese
C: as B, with non-answer context ONLY on Japanese->English stage
D: as B, with Japanese->English glossary ONLY on Japanese->English stage

Pure Python standard library. Output is JSONL with each request/response preserved.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CASES = ROOT / "data" / "classical_pivot_cases.jsonl"
TAG, MSG, KEY, VAL = "<|plamo:tag|>", "<|plamo:msg|>", "<|plamo:key|>", "<|plamo:val|>"
INDEX, ITEM = "<|plamo:index|>", "<|plamo:item|>"
TOKENS = (TAG, MSG, KEY, VAL, INDEX, ITEM, "<|plamo:bos|>")
STOP = [TAG, "<|plamo:bos|>"]
CONDITIONS = ("A", "B", "C", "D")
VALID_ID = re.compile(r"^[A-Za-z0-9_-]+$")


def json_string(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: object) -> str:
    return hashlib.sha256(json_string(value).encode("utf-8")).hexdigest()


def checked_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a nonempty string")
    for token in TOKENS:
        if token in value:
            raise ValueError(f"{label} contains reserved PFML3 token {token}")
    return value


def load_cases(path: Path) -> list[dict]:
    found, seen = [], set()
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        obj = json.loads(line)
        name = obj.get("id")
        if not isinstance(name, str) or not VALID_ID.fullmatch(name) or name in seen:
            raise ValueError(f"{path.name}:{number}: invalid or duplicate case id {name!r}")
        seen.add(name)
        checked_text(obj.get("source_text"), f"{name}.source_text")
        if obj.get("pivot_context"):
            checked_text(obj["pivot_context"], f"{name}.pivot_context")
        glossary = obj.get("pivot_glossary", [])
        if not isinstance(glossary, list):
            raise ValueError(f"{name}.pivot_glossary must be a list")
        for entry in glossary:
            if not isinstance(entry, dict):
                raise ValueError(f"{name}.pivot_glossary entries must be objects")
            checked_text(entry.get("source"), f"{name}.glossary source")
            checked_text(entry.get("target"), f"{name}.glossary target")
        found.append(obj)
    if not found:
        raise ValueError(f"No cases in {path}")
    return found


def build_pfml3(text: str, target: str, *, source: str | None = None,
                context: str | None = None, glossary: list[dict] | None = None,
                style: str | None = None) -> str:
    """Follow PFN's explicit PFML3 format (no <|plamo:bos|>; llama.cpp inserts BOS)."""
    checked_text(text, "input")
    if target not in {"ja", "en"} or source not in {None, "ja", "en"}:
        raise ValueError("Expected language codes ja or en")
    if style not in (None, "plain", "polite") or (style and target != "ja"):
        raise ValueError("The output style is only specified for Japanese")
    out = TAG + "dataset" + MSG + "translation"
    if context:
        out += TAG + "context" + MSG + checked_text(context, "context")
    if glossary:
        out += TAG + "glossary"
        for pair in glossary:
            out += INDEX + checked_text(pair["source"], "glossary source")
            out += ITEM + checked_text(pair["target"], "glossary target")
    out += TAG + "input"
    if source:
        out += KEY + "lang" + VAL + source
    out += MSG + text
    out += TAG + "output" + KEY + "lang" + VAL + target
    if style:
        out += KEY + "form" + VAL + style
    out += MSG
    return out


def plan_first_stage(case: dict, condition: str, direct_source: str) -> dict:
    if condition not in CONDITIONS:
        raise ValueError(condition)
    if condition == "A":
        source = None if direct_source == "auto" else "ja"
        return {"stage": "direct", "source_lang": source, "target_lang": "ja",
                "prompt": build_pfml3(case["source_text"], "ja", source=source, style="plain")}
    context = case.get("pivot_context") if condition == "C" else None
    glossary = case.get("pivot_glossary") if condition == "D" else None
    return {"stage": "ja_to_en", "source_lang": "ja", "target_lang": "en",
            "prompt": build_pfml3(case["source_text"], "en", source="ja",
                                  context=context, glossary=glossary)}


def plan_second_stage(english: str) -> dict:
    return {"stage": "en_to_ja", "source_lang": "en", "target_lang": "ja",
            "prompt": build_pfml3(english, "ja", source="en", style="plain")}


def payload(prompt: str, model: str, *, max_tokens: int, seed: int) -> dict:
    return {"model": model, "prompt": prompt, "temperature": 0,
            "max_tokens": max_tokens, "seed": seed, "stop": STOP, "stream": False}


def request_json(url: str, *, data: dict | None = None, timeout: float = 600) -> dict:
    body = None if data is None else json.dumps(data, ensure_ascii=False).encode("utf-8")
    req = Request(url, data=body,
                  headers={"Content-Type": "application/json"} if body is not None else {},
                  method="POST" if body is not None else "GET")
    try:
        with urlopen(req, timeout=timeout) as res:
            result = json.loads(res.read().decode("utf-8"))
    except HTTPError as exc:
        details = exc.read(2500).decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {details}") from exc
    except (URLError, TimeoutError) as exc:
        raise RuntimeError(f"Connection failed: {exc}") from exc
    if not isinstance(result, dict):
        raise RuntimeError("Expected an API JSON object")
    if result.get("error"):
        raise RuntimeError(f"API error: {result['error']}")
    return result


def check_server(base_url: str, size: str | None, timeout: float) -> dict:
    """Use read-only GET /props to verify 8B/31B even if --alias is identical."""
    info = request_json(base_url.rstrip("/") + "/props", timeout=min(30, timeout))
    full_path = str(info.get("model_path") or "")
    basename = Path(full_path).name  # Never persist users' private paths.
    if size and f"plamo-3-translate-{size}-" not in basename.lower():
        raise RuntimeError(f"Expected {size} model but /props reports {basename or '(no model_path)'}; "
                           "check the running server before evaluation")
    return {"model_filename": basename, "build_info": info.get("build_info")}


def run_stage(base_url: str, step: dict, *, model: str, max_tokens: int,
              seed: int, timeout: float, raw_folder: Path, raw_stem: str) -> dict:
    req = payload(step["prompt"], model, max_tokens=max_tokens, seed=seed)
    result = {"stage": step["stage"], "source_lang": step["source_lang"],
              "target_lang": step["target_lang"], "request": req, "status": "error",
              "response_text_raw": None, "text": None, "finish_reason": None,
              "usage": {}, "elapsed_seconds": None, "raw_response_file": None, "error": None}
    started = time.perf_counter()
    try:
        data = request_json(base_url.rstrip("/") + "/v1/completions", data=req, timeout=timeout)
        raw_file = raw_folder / f"{raw_stem}_{step['stage']}.json"
        raw_file.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        result["raw_response_file"] = str(raw_file.relative_to(ROOT)) if raw_file.is_relative_to(ROOT) else raw_file.name
        choice = data["choices"][0]
        raw = choice["text"]
        if not isinstance(raw, str):
            raise ValueError(f"Unexpected completion text type: {type(raw).__name__}")
        # Preserve raw output; strip only the explicit stop markup if returned at the end.
        clean = raw.strip()
        for tok in STOP:
            if clean.endswith(tok):
                clean = clean[:-len(tok)]
        clean = clean.strip()
        result.update(response_text_raw=raw, text=clean,
                      finish_reason=choice.get("finish_reason"), usage=data.get("usage", {}))
        if choice.get("finish_reason") == "length":
            raise ValueError("max_tokens reached; output may be truncated (increase --max-tokens)")
        if not clean:
            raise ValueError("Empty model output")
        result["status"] = "ok"
    except (ValueError, RuntimeError, KeyError, IndexError, TypeError, OSError) as exc:
        result["error"] = str(exc)
    result["elapsed_seconds"] = round(time.perf_counter() - started, 4)
    return result


def signature(case: dict, condition: str, args: argparse.Namespace) -> str:
    return digest({"version": VERSION, "case": case, "condition": condition,
                   "run_name": args.run_name, "model": args.model,
                   "expected_size": args.expected_size, "direct_source": args.direct_source,
                   "seed": args.seed, "max_tokens": args.max_tokens,
                   "url": args.url.rstrip("/")})


def done_signatures(path: Path) -> set[str]:
    done = set()
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = json.loads(line)
                if rec.get("status") == "ok" and rec.get("signature"):
                    done.add(rec["signature"])
    return done


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("--cases", type=Path, default=DEFAULT_CASES)
    p.add_argument("--ids", nargs="*", help="Optional subset, e.g. --ids old_01_makura")
    p.add_argument("--conditions", nargs="+", choices=CONDITIONS, default=list(CONDITIONS),
                   help="A=direct, B=pivot, C=pivot+context, D=pivot+glossary")
    p.add_argument("--url", default="http://127.0.0.1:8000")
    p.add_argument("--model", default="plamo-3-translate", help="llama-server --alias")
    p.add_argument("--expected-size", choices=("8b", "31b"),
                   help="Validate the loaded GGUF model filename via GET /props")
    p.add_argument("--run-name", default="manual", help="Name for backend/device/model run")
    p.add_argument("--direct-source", choices=("ja", "auto"), default="ja",
                   help="A only: explicit ja or omit source language")
    p.add_argument("--max-tokens", type=int, default=768)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--timeout", type=float, default=600)
    p.add_argument("--output", type=Path, default=ROOT / "results/classical_pivot.jsonl")
    p.add_argument("--resume", action="store_true", help="Skip only successful matching experiments")
    p.add_argument("--dry-run", action="store_true", help="Print requests; stage2 uses a placeholder")
    args = p.parse_args(argv)
    if args.max_tokens < 32 or args.timeout <= 0:
        p.error("--max-tokens must be >= 32 and --timeout must be > 0")
    if not VALID_ID.fullmatch(args.run_name):
        p.error("--run-name: only ASCII letters, digits, '_' and '-' are allowed")
    if not args.url.startswith(("http://127.0.0.1:", "http://localhost:", "http://[::1]:")):
        p.error("For safety this tool only accesses loopback llama-server; use an SSH tunnel for remote servers")
    if not args.cases.is_absolute():
        args.cases = ROOT / args.cases
    if not args.output.is_absolute():
        args.output = ROOT / args.output
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    cases = load_cases(args.cases)
    if args.ids:
        wanted = set(args.ids)
        missing = wanted.difference(c["id"] for c in cases)
        if missing:
            raise SystemExit(f"Unknown IDs: {sorted(missing)}")
        cases = [c for c in cases if c["id"] in wanted]
    conditions = list(dict.fromkeys(args.conditions))
    if args.dry_run:
        for case in cases:
            for cond in conditions:
                first = plan_first_stage(case, cond, args.direct_source)
                example = [payload(first["prompt"], args.model, max_tokens=args.max_tokens, seed=args.seed)]
                if cond != "A":
                    second = plan_second_stage("<ENGLISH_TRANSLATION_FROM_STAGE1>")
                    example.append(payload(second["prompt"], args.model,
                                           max_tokens=args.max_tokens, seed=args.seed))
                print(json.dumps({"id": case["id"], "condition": cond, "stages": example},
                                 ensure_ascii=False, indent=2))
        return 0
    server = check_server(args.url, args.expected_size, args.timeout)
    print(f"Server model: {server['model_filename']} | build: {server['build_info']}", flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    raw_folder = args.output.parent / (args.output.stem + "_raw")
    raw_folder.mkdir(parents=True, exist_ok=True)
    completed = done_signatures(args.output) if args.resume else set()
    ok, errors, skipped = 0, 0, 0
    for case in cases:
        for cond in conditions:
            sig = signature(case, cond, args)
            if sig in completed:
                skipped += 1
                print(f"SKIP {case['id']} {cond} (matching successful signature)", flush=True)
                continue
            print(f"RUN  {case['id']} {cond}", flush=True)
            first = plan_first_stage(case, cond, args.direct_source)
            raw_stem = f"{args.run_name}_{case['id']}_{cond}_{sig[:12]}"
            stage1 = run_stage(args.url, first, model=args.model, max_tokens=args.max_tokens,
                               seed=args.seed, timeout=args.timeout, raw_folder=raw_folder,
                               raw_stem=raw_stem)
            stage2 = None
            if cond != "A" and stage1["status"] == "ok":
                second = plan_second_stage(stage1["text"])
                stage2 = run_stage(args.url, second, model=args.model, max_tokens=args.max_tokens,
                                   seed=args.seed, timeout=args.timeout, raw_folder=raw_folder,
                                   raw_stem=raw_stem)
            final_stage = stage1 if cond == "A" else stage2
            status = "ok" if final_stage and final_stage["status"] == "ok" else "error"
            error = None
            if status != "ok":
                error = (stage2 or stage1)["error"] or "Intermediate translation failed"
            stages = [stage1] + ([stage2] if stage2 else [])
            rec = {
                "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "script_version": VERSION, "signature": sig,
                "run_name": args.run_name, "server_model_filename": server["model_filename"],
                "server_build_info": server["build_info"],
                "model": args.model, "expected_size": args.expected_size,
                "case_id": case["id"], "title": case.get("title"),
                "source_url": case.get("source_url"), "rights_note": case.get("rights_note"),
                "source_text": case["source_text"], "evaluation_points": case.get("evaluation_points", []),
                "condition": cond, "condition_note": {
                    "A": "Direct Japanese to Japanese, out of distribution",
                    "B": "Pivot ja->en->ja without aids",
                    "C": "Context only on first ja->en stage",
                    "D": "Japanese to English glossary only on first ja->en stage",
                }[cond],
                "direct_source": args.direct_source if cond == "A" else None,
                "pivot_context": case.get("pivot_context") if cond == "C" else None,
                "pivot_glossary": case.get("pivot_glossary") if cond == "D" else None,
                "stages": stages,
                "intermediate_english": stage1["text"] if cond != "A" else None,
                "final_japanese": final_stage["text"] if final_stage else None,
                "total_elapsed_seconds": round(sum(s["elapsed_seconds"] for s in stages), 4),
                "status": status, "error": error,
            }
            with args.output.open("a", encoding="utf-8") as fp:
                fp.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if status == "ok":
                ok += 1
            else:
                errors += 1
            print(f"{status.upper():5s} {case['id']} {cond} "
                  f"{rec['total_elapsed_seconds']}s "
                  f"final={((rec['final_japanese'] or '')[:70])!r} "
                  f"{error or ''}", flush=True)
    print(f"Finished: ok={ok}, errors={errors}, skipped={skipped}; output={args.output}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
