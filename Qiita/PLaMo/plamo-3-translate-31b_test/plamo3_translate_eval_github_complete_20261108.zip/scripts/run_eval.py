#!/usr/bin/env python3
"""Reproducible local PLaMo 3 Translate experiments using llama.cpp HTTP API.

Only Python standard library is needed. Translate to Japanese via documented PFML3
or the model card's chat template. Classical -> modern Japanese is an
UNSUPPORTED/OOD experiment, not an official capability.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STOP = ["<|plamo:tag|>", "<|plamo:bos|>"]
TAG = "<|plamo:tag|>"
MSG = "<|plamo:msg|>"
KEY = "<|plamo:key|>"
VAL = "<|plamo:val|>"


def build_pfml3(case: dict, condition: str = "baseline", classical_source: str = "auto") -> str:
    """Build a PFML3 prompt from the published model card; same-language use is experimental."""
    if condition not in {"baseline", "assisted"}:
        raise ValueError(condition)
    text = case["source_text"]
    if any(token in text for token in (TAG, MSG, KEY, VAL)):
        raise ValueError("Input contains reserved PLaMo markup")
    prompt = TAG + "dataset" + MSG + "translation"
    if condition == "assisted":
        context = case.get("context", "")
        if context:
            prompt += TAG + "context" + MSG + context
        glossary = case.get("glossary", [])
        if glossary:
            prompt += TAG + "glossary"
            for entry in glossary:
                prompt += "<|plamo:index|>" + entry["source"] + "<|plamo:item|>" + entry["target"]
    source = case.get("source_lang", "")
    tag_source = source == "en" or (source == "ja" and classical_source == "ja")
    prompt += TAG + "input"
    if tag_source:
        prompt += KEY + "lang" + VAL + source
    prompt += MSG + text
    # form can be selected by API; here the style is fixed for comparability.
    prompt += TAG + "output" + KEY + "lang" + VAL + "ja" + KEY + "form" + VAL + "plain" + MSG
    return prompt


def build_chat(case: dict, condition: str = "baseline", classical_source: str = "auto") -> dict:
    kwargs = {"target_lang": "ja", "form": "plain"}
    source = case.get("source_lang", "")
    if source == "en" or (source == "ja" and classical_source == "ja"):
        kwargs["source_lang"] = source
    if condition == "assisted":
        if case.get("context"):
            kwargs["context"] = case["context"]
        if case.get("glossary"):
            kwargs["glossary"] = case["glossary"]
    return {"messages": [{"role": "user", "content": case["source_text"]}],
            "chat_template_kwargs": kwargs}


def http_json(url: str, payload: dict, timeout: float) -> dict:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def load_cases(path: Path) -> list[dict]:
    cases, seen = [], set()
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        case = json.loads(line)
        for field in ("id", "kind", "source_text", "source_lang"):
            if not case.get(field):
                raise ValueError(f"Line {line_number}: missing {field}")
        if case["id"] in seen:
            raise ValueError(f"Duplicate case ID: {case['id']}")
        seen.add(case["id"])
        cases.append(case)
    return cases


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cases", type=Path, default=PROJECT_ROOT / "data/cases.jsonl")
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--model", default="plamo-3-translate")
    ap.add_argument("--run-name", default="local_test", help="Identifies the MODEL/BACKEND combination")
    ap.add_argument("--modes", choices=["pfml3", "chat", "both"], default="pfml3")
    ap.add_argument("--conditions", choices=["baseline", "assisted", "both"], default="both")
    ap.add_argument("--classical-source", choices=["auto", "ja"], default="auto",
                    help="auto = omit source_lang for classical text; ja = explicitly set ja (experimental)")
    ap.add_argument("--ids", nargs="*", help="Only process these case IDs")
    ap.add_argument("--output", type=Path, default=PROJECT_ROOT / "results/experiment.jsonl")
    ap.add_argument("--max-tokens", type=int, default=768)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--timeout", type=float, default=600)
    ap.add_argument("--resume", action="store_true", help="Skip records already in output")
    ap.add_argument("--dry-run", action="store_true", help="Show request examples without contacting server")
    args = ap.parse_args()
    # Resolve relative paths against the project, not the caller's CWD.
    if not args.cases.is_absolute():
        args.cases = PROJECT_ROOT / args.cases
    if not args.output.is_absolute():
        args.output = PROJECT_ROOT / args.output

    cases = load_cases(args.cases)
    if args.ids:
        selection = set(args.ids)
        unknown = selection - {c["id"] for c in cases}
        if unknown:
            ap.error(f"Unknown IDs: {sorted(unknown)}")
        cases = [case for case in cases if case["id"] in selection]
    modes = ["pfml3", "chat"] if args.modes == "both" else [args.modes]
    conditions = ["baseline", "assisted"] if args.conditions == "both" else [args.conditions]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    raw_dir = args.output.parent / (args.output.stem + "_raw")
    if not args.dry_run:
        raw_dir.mkdir(parents=True, exist_ok=True)
    done = set()
    if args.resume and args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = json.loads(line)
                # Only skip successful entries from the same named experiment.
                if rec.get("run_name") == args.run_name and rec.get("error") is None:
                    done.add((rec["id"], rec["mode"], rec["condition"], rec.get("classical_source")))

    successes, failures = 0, 0
    for case in cases:
        for mode in modes:
            for condition in conditions:
                key = (case["id"], mode, condition, args.classical_source)
                if key in done:
                    print(f"SKIP {case['id']} {mode} {condition}", flush=True)
                    continue
                request = {
                    "model": args.model,
                    "temperature": 0,
                    "seed": args.seed,
                    "max_tokens": args.max_tokens,
                    "stop": STOP,
                    "stream": False,
                }
                if mode == "pfml3":
                    request["prompt"] = build_pfml3(case, condition, args.classical_source)
                    endpoint = "/v1/completions"
                else:
                    request.update(build_chat(case, condition, args.classical_source))
                    endpoint = "/v1/chat/completions"
                if args.dry_run:
                    print(json.dumps({"id": case["id"], "mode": mode, "condition": condition,
                                      "request": request}, ensure_ascii=False, indent=2))
                    continue

                print(f"RUN  {case['id']} {mode} {condition}", flush=True)
                started = time.perf_counter()
                response, error = None, None
                try:
                    response = http_json(args.url.rstrip("/") + endpoint, request, args.timeout)
                    if response.get("error"):
                        raise RuntimeError(str(response["error"]))
                    choice = response["choices"][0]
                    translation = (choice.get("text") if mode == "pfml3"
                                   else choice.get("message", {}).get("content"))
                    if not isinstance(translation, str):
                        raise TypeError(f"Unexpected translation payload: {choice}")
                    successes += 1
                except (HTTPError, URLError, TimeoutError, RuntimeError, ValueError, TypeError,
                        KeyError, IndexError) as ex:
                    extra = ""
                    if isinstance(ex, HTTPError):
                        extra = " body=" + ex.read(2000).decode("utf-8", errors="replace")
                    error = str(ex) + extra
                    translation = ""
                    failures += 1
                elapsed = round(time.perf_counter() - started, 4)
                raw_path = None
                if response is not None:
                    filename = f"{case['id']}__{mode}__{condition}__{args.classical_source}.json"
                    path = raw_dir / filename
                    path.write_text(json.dumps(response, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                    raw_path = str(path)
                usage = response.get("usage", {}) if isinstance(response, dict) else {}
                completion_tokens = usage.get("completion_tokens")
                rec = {
                    "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "run_name": args.run_name, "id": case["id"], "kind": case["kind"],
                    "title": case.get("title", ""), "source_url": case.get("source_url"),
                    "source_text": case["source_text"], "source_sha256": hashlib.sha256(case["source_text"].encode()).hexdigest(),
                    "mode": mode, "condition": condition, "classical_source": args.classical_source,
                    "endpoint": endpoint, "model": args.model, "request": request,
                    "translation": translation, "finish_reason": response["choices"][0].get("finish_reason")
                    if (response and response.get("choices")) else None,
                    "usage": usage, "elapsed_seconds": elapsed,
                    "generated_tokens_per_second": round(completion_tokens / elapsed, 3)
                    if (isinstance(completion_tokens, (int, float)) and elapsed > 0) else None,
                    "raw_response_path": raw_path, "evaluation_points": case.get("evaluation_points", []),
                    "error": error,
                }
                with args.output.open("a", encoding="utf-8") as fp:
                    fp.write(json.dumps(rec, ensure_ascii=False) + "\n")
                status = "OK" if error is None else "ERROR"
                print(f"{status}  {case['id']} {elapsed:.2f}s | {translation[:90]!r} {error or ''}", flush=True)
    if args.dry_run:
        return 0
    print(f"Completed: successful={successes}, failed={failures}; results={args.output}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
