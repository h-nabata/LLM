#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_config.sh"
SIZE="${1:-}"
DEVICE="${2:-}"
PORT="${3:-8000}"
case "$SIZE" in
  8b|31b) ;;
  *) echo 'Usage: bash scripts/start_server.sh {8b|31b} {Vulkan0|Vulkan1|cpu} [port]' >&2; exit 2 ;;
esac
if [[ -z "$DEVICE" ]]; then
  echo 'ERROR: specify a GPU DEVICE reported by --list-devices or cpu.' >&2
  exit 2
fi
if ! [[ "$PORT" =~ ^[0-9]+$ ]] || (( PORT < 1 || PORT > 65535 )); then
  echo "ERROR: invalid port: $PORT" >&2
  exit 2
fi

MODEL_DIR="$(model_dir "$SIZE")"
MODEL="$MODEL_DIR/$(model_filename "$SIZE")"
TEMPLATE="$MODEL_DIR/chat_template.jinja"
SERVER="${LLAMA_SERVER:-$LLAMA_SERVER_DEFAULT}"
for f in "$MODEL" "$TEMPLATE"; do
  if [[ ! -s "$f" ]]; then
    echo "ERROR: required model file missing: $f" >&2
    echo "Run: bash scripts/download_model.sh $SIZE" >&2
    exit 1
  fi
done
if [[ ! -x "$SERVER" ]]; then
  echo "ERROR: llama-server not executable: $SERVER" >&2
  echo 'Run: bash scripts/setup_ubuntu.sh' >&2
  exit 1
fi

args=( -m "$MODEL" -c "${CTX:-8192}" -t "${THREADS:-8}"
       -tb "${THREADS_BATCH:-8}" --host 127.0.0.1 --port "$PORT"
       --alias plamo-3-translate --jinja --chat-template-file "$TEMPLATE"
       --no-prefill-assistant --parallel "${PARALLEL:-1}" )
if [[ "$DEVICE" == cpu ]]; then
  args+=( --device none -ngl 0 )
else
  args+=( --device "$DEVICE" -ngl "${GPU_LAYERS:-999}" )
fi
printf 'Work directory: %s\nModel: %s\nTemplate: %s\nDevice: %s\nServer: %s\n' \
  "$PROJECT_DIR" "$MODEL" "$TEMPLATE" "$DEVICE" "$SERVER"
echo 'Local API: http://127.0.0.1:'"$PORT"
exec "$SERVER" "${args[@]}"
