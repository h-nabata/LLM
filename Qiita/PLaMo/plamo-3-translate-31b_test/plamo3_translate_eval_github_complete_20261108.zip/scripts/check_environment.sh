#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_config.sh"
printf 'Project directory: %s\nModel base: %s\nPython venv: %s\nllama-server: %s\n' \
  "$PROJECT_DIR" "$MODELS_BASE" "$VENV_DIR" "$LLAMA_SERVER_DEFAULT"
[[ -x "$VENV_DIR/bin/hf" ]] && echo '[OK] HF CLI' || echo '[MISSING] HF CLI (run setup_ubuntu.sh)'
[[ -x "$LLAMA_SERVER_DEFAULT" ]] && echo '[OK] llama-server' || echo '[MISSING] llama-server (run setup_ubuntu.sh)'
for size in 8b 31b; do
  dir="$(model_dir "$size")"
  echo "$size directory: $dir"
  [[ -s "$dir/$(model_filename "$size")" ]] && echo '  [OK] Q4_K_M GGUF' || echo '  [MISSING] Q4_K_M GGUF'
  [[ -s "$dir/chat_template.jinja" ]] && echo '  [OK] chat_template.jinja' || echo '  [MISSING] chat_template.jinja'
done
if [[ -x "$LLAMA_SERVER_DEFAULT" ]]; then
  echo '===== Available llama.cpp devices ====='
  "$LLAMA_SERVER_DEFAULT" --list-devices || echo '[WARN] Failed to enumerate Vulkan devices.'
fi
