#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_config.sh"
SIZE="${1:-}"
case "$SIZE" in
  8b|31b) ;;
  *) echo 'Usage: bash scripts/download_model.sh {8b|31b}' >&2; exit 2 ;;
esac

HF="$VENV_DIR/bin/hf"
if [[ ! -x "$HF" ]]; then
  echo "ERROR: HF CLI not found at $HF" >&2
  echo 'Run: bash scripts/setup_ubuntu.sh' >&2
  exit 1
fi
MODEL_DIR="$(model_dir "$SIZE")"
MODEL_NAME="$(model_filename "$SIZE")"
WEIGHTS="$MODEL_DIR/$MODEL_NAME"
TEMPLATE="$MODEL_DIR/chat_template.jinja"
REPO="pfnet/plamo-3-translate-${SIZE}-GGUF"
mkdir -p "$MODEL_DIR"

if [[ -s "$WEIGHTS" ]]; then
  echo "EXISTING: $WEIGHTS"
  echo 'Skipping the GGUF weight download; existing file will not be changed.'
elif [[ -e "$WEIGHTS" ]]; then
  echo "ERROR: existing GGUF is empty or unreadable: $WEIGHTS" >&2
  echo 'Please inspect or rename this file before retrying (not deleting it automatically).' >&2
  exit 1
else
  echo "DOWNLOADING: $REPO / $MODEL_NAME"
  "$HF" download "$REPO" "$MODEL_NAME" --local-dir "$MODEL_DIR"
fi

# The current PFN GGUF model card requires an external Jinja template for chat.
# Even for an existing 31B GGUF, fetch ONLY the small missing template.
if [[ -s "$TEMPLATE" ]]; then
  echo "EXISTING: $TEMPLATE"
else
  echo "DOWNLOADING CHAT TEMPLATE: $REPO / chat_template.jinja"
  "$HF" download "$REPO" chat_template.jinja --local-dir "$MODEL_DIR"
fi

[[ -s "$WEIGHTS" ]] || { echo "ERROR: missing weights: $WEIGHTS" >&2; exit 1; }
[[ -s "$TEMPLATE" ]] || { echo "ERROR: missing template: $TEMPLATE" >&2; exit 1; }
printf '\nREADY (%s):\n  weights: %s\n  template: %s\n' "$SIZE" "$WEIGHTS" "$TEMPLATE"
ls -lh "$WEIGHTS" "$TEMPLATE"
