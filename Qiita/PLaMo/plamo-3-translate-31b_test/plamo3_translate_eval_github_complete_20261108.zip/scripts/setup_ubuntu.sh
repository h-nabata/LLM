#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_config.sh"

# All build files and Python environments live under PROJECT_DIR.
# This script never installs or modifies GPU drivers, oneAPI, CUDA, or PyTorch.
if [[ "${SKIP_APT:-0}" != "1" ]]; then
  sudo apt-get update
  sudo apt-get install -y git cmake ninja-build build-essential curl unzip jq \
    libvulkan-dev vulkan-tools glslc spirv-headers python3-venv python3-pip \
    libcurl4-openssl-dev
else
  echo 'SKIP_APT=1: skipping apt installation.'
fi
# llama.cpp's Vulkan backend calls find_package(SPIRV-Headers CONFIG REQUIRED).
# Without this package CMake stops before the Python virtual environment is set up.
# Ubuntu's spirv-headers package installs the following CMake config file.
if [[ ! -r /usr/share/cmake/SPIRV-Headers/SPIRV-HeadersConfig.cmake ]]; then
  echo 'ERROR: missing SPIRV-Headers CMake config.' >&2
  echo 'Fix: sudo apt-get install -y spirv-headers' >&2
  echo 'Then rerun: bash scripts/setup_ubuntu.sh' >&2
  exit 1
fi
if ! command -v vulkaninfo >/dev/null 2>&1; then
  echo 'ERROR: vulkaninfo not found. Install vulkan-tools or use a preinstalled Vulkan toolchain.' >&2
  exit 1
fi
if ! vulkaninfo --summary; then
  echo 'ERROR: Vulkan could not enumerate GPUs. GPU drivers are NOT changed by this kit.' >&2
  exit 1
fi

mkdir -p "$PROJECT_DIR/vendor" "$PROJECT_DIR/results" "$MODELS_BASE"
if [[ ! -e "$LLAMA_SOURCE" ]]; then
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git "$LLAMA_SOURCE"
elif [[ ! -d "$LLAMA_SOURCE/.git" ]]; then
  echo "ERROR: $LLAMA_SOURCE exists but is not a llama.cpp git checkout." >&2
  exit 1
else
  echo 'Existing llama.cpp checkout found; not pulling automatically.'
fi
echo "llama.cpp revision: $(git -C "$LLAMA_SOURCE" rev-parse HEAD)"
cmake -S "$LLAMA_SOURCE" -B "$LLAMA_BUILD" \
  -DGGML_VULKAN=ON -DCMAKE_BUILD_TYPE=Release
cmake --build "$LLAMA_BUILD" -j "${BUILD_JOBS:-8}" --target llama-server

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  python3 -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/python" -m pip install --upgrade pip huggingface_hub
printf '\nSETUP COMPLETE\nProject: %s\nllama-server: %s\nPython: %s\n' \
  "$PROJECT_DIR" "$LLAMA_SERVER_DEFAULT" "$VENV_DIR/bin/python"
"$LLAMA_SERVER_DEFAULT" --version
"$LLAMA_SERVER_DEFAULT" --list-devices
