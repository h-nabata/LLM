#!/usr/bin/env python3
from __future__ import annotations

import argparse
import dataclasses
import json
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from llmbench.backends.llama_cpp import LlamaCppBackend  # noqa: E402
from llmbench.hardware_monitor import HardwareMonitor  # noqa: E402
from llmbench.io_utils import append_jsonl, write_json_atomic  # noqa: E402
from llmbench.runner import classify_error  # noqa: E402
from llmbench.types import GenerationConfig, InferenceRequest  # noqa: E402


def describe(vals: list[float]) -> dict[str, Any]:
    if not vals:
        return {"n": 0, "mean": None, "median": None, "std": None, "min": None, "max": None}
    return {
        "n": len(vals), "mean": statistics.fmean(vals), "median": statistics.median(vals),
        "std": statistics.stdev(vals) if len(vals) > 1 else 0.0, "min": min(vals), "max": max(vals),
    }


def make_prompt(reps: int, nonce: str) -> str:
    # Unique marker prevents accidental prefix reuse.
    body = " data" * max(128, reps)
    return (
        f"BENCHMARK_NONCE={nonce}\n"
        "性能測定専用です。以下の冗長な資料を読み、資料の構成と情報の重複について詳細に分析してください。"
        "少なくとも800字程度を目安に説明してください。\n"
        + body
        + "\n分析:"
    )


def make_targeted_prompt(backend: LlamaCppBackend, ctx: int, nonce: str, effort: str | None, num_predict: int) -> tuple[str, int, int]:
    # Exercise a substantial fraction of the configured context while reserving
    # room for generation and template overhead.
    target = min(int(ctx * 0.75), ctx - num_predict - 512)
    target = max(512, target)
    reps = max(128, target)
    prompt = make_prompt(reps, nonce)
    count = backend.count_chat_tokens([{"role": "user", "content": prompt}], effort)
    for _ in range(6):
        if abs(count - target) <= max(32, int(target * 0.02)):
            break
        reps = max(128, int(reps * target / max(count, 1)))
        prompt = make_prompt(reps, nonce)
        count = backend.count_chat_tokens([{"role": "user", "content": prompt}], effort)
    return prompt, target, count


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--contexts", required=True)
    ap.add_argument("--server-context", type=int, required=True)
    ap.add_argument("--repeats", type=int, default=5)
    ap.add_argument("--warmups", type=int, default=2)
    ap.add_argument("--num-predict", type=int, default=256)
    ap.add_argument("--reasoning-effort", choices=["none", "low", "medium", "high"], default="medium")
    ap.add_argument("--monitor-interval", type=float, default=0.2)
    ap.add_argument("--output-dir", type=Path, required=True)
    a = ap.parse_args()
    contexts = [int(x) for x in a.contexts.split(",") if x.strip()]
    if any(ctx != a.server_context for ctx in contexts):
        raise SystemExit("system_probe cannot change llama-server context per request; restart server for separate profiles")
    a.output_dir.mkdir(parents=True, exist_ok=True)
    rows_path = a.output_dir / "system_results.jsonl"
    hw_path = a.output_dir / "hardware_samples.jsonl"
    rows: list[dict[str, Any]] = []
    errors = 0
    if rows_path.exists():
        for line in rows_path.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    completed = {
        (int(r.get("context")), int(r.get("repeat")))
        for r in rows
        if r.get("kind") == "measured" and isinstance(r.get("context"), int) and isinstance(r.get("repeat"), int)
    }
    effort = None if a.reasoning_effort == "none" else a.reasoning_effort
    backend = LlamaCppBackend(a.url, a.model, timeout_s=1800, server_context=a.server_context)
    mon = HardwareMonitor(hw_path, a.monitor_interval)
    mon.start()
    try:
        for ctx in contexts:
            gen = GenerationConfig(
                max_tokens=a.num_predict, context_size=ctx, temperature=0, top_p=1, top_k=0,
                min_p=0, repeat_penalty=1, seed=42, reasoning_effort=effort,  # type: ignore[arg-type]
            )
            for w in range(a.warmups):
                try:
                    prompt, _, _ = make_targeted_prompt(backend, ctx, f"warmup-{ctx}-{w}-{datetime.now(timezone.utc).timestamp()}", effort, a.num_predict)
                    backend.generate(InferenceRequest(f"warmup_{ctx}_{w}", [{"role": "user", "content": prompt}], gen))
                except Exception as exc:
                    append_jsonl(rows_path, {
                        "schema_version": "1.2.0", "kind": "warmup", "context": ctx, "status": "error",
                        "error_class": classify_error(exc), "error": str(exc),
                    })
                    errors += 1
                    break
            for rep in range(1, a.repeats + 1):
                if (ctx, rep) in completed:
                    continue
                label = f"ctx{ctx}_rep{rep}"
                mon.set_active_label(label)
                try:
                    prompt, target_prompt_tokens, counted_prompt_tokens = make_targeted_prompt(
                        backend, ctx, f"measure-{ctx}-{rep}-{datetime.now(timezone.utc).timestamp()}", effort, a.num_predict
                    )
                    req = InferenceRequest(label, [{"role": "user", "content": prompt}], gen)
                    r = backend.generate(req)
                    meta = r.raw_metadata.get("llama_cpp", {})
                    cached = int(meta.get("cached_prompt_tokens") or 0)
                    if cached != 0:
                        raise RuntimeError(f"benchmark-invalid prompt cache reuse: cached_tokens={cached}")
                    row = {
                        "schema_version": "1.2.0", "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                        "kind": "measured", "context": ctx, "repeat": rep, "status": "ok",
                        "generation": dataclasses.asdict(gen),
                        "target_prompt_tokens": target_prompt_tokens,
                        "counted_prompt_tokens_before_inference": counted_prompt_tokens,
                        "metrics": {
                            "wall_time_s": r.wall_time_s, "ttft_s": r.ttft_s,
                            "prompt_tokens": r.prompt_tokens, "completion_tokens": r.completion_tokens,
                            "prompt_tokens_per_s": r.prompt_tokens_per_s,
                            "completion_tokens_per_s": r.completion_tokens_per_s,
                            "prompt_ms": r.prompt_ms, "predicted_ms": r.predicted_ms,
                            "cached_prompt_tokens": cached, "finish_reason": r.finish_reason,
                        },
                        "hardware": mon.summarize(label),
                    }
                except Exception as exc:
                    row = {
                        "schema_version": "1.2.0", "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                        "kind": "measured", "context": ctx, "repeat": rep, "status": "error",
                        "error_class": classify_error(exc), "error": f"{type(exc).__name__}: {exc}",
                        "hardware": mon.summarize(label),
                    }
                    errors += 1
                finally:
                    mon.set_active_label(None)
                append_jsonl(rows_path, row)
                rows.append(row)
    finally:
        mon.stop()

    summary: dict[str, Any] = {"schema_version": "1.2.0", "errors": errors, "contexts": {}}
    for ctx in contexts:
        rr = [r for r in rows if r.get("context") == ctx and r.get("status") == "ok"]
        ms: dict[str, Any] = {}
        for key in [
            "wall_time_s", "prompt_tokens_per_s", "completion_tokens_per_s", "prompt_tokens",
            "completion_tokens", "prompt_ms", "predicted_ms", "cached_prompt_tokens",
        ]:
            ms[key] = describe([
                float(r["metrics"][key]) for r in rr if isinstance(r.get("metrics", {}).get(key), (int, float))
            ])
        gpu_max: dict[str, list[float]] = {}
        for r in rr:
            for g in r.get("hardware", {}).get("gpus", []) or []:
                v = g.get("memory_used_mib_max")
                name = str(g.get("name") or g.get("index"))
                if isinstance(v, (int, float)):
                    gpu_max.setdefault(name, []).append(float(v))
        ms["vram_mib_max_by_gpu"] = {k: describe(v) for k, v in gpu_max.items()}
        summary["contexts"][str(ctx)] = ms
    classes: dict[str, int] = {}
    for r in rows:
        if r.get("status") == "error":
            c = str(r.get("error_class") or "unknown")
            classes[c] = classes.get(c, 0) + 1
    summary["error_classes"] = classes
    write_json_atomic(a.output_dir / "system_summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 1 if any(classes.get(k, 0) for k in ("backend_error", "inference_error")) else 0


if __name__ == "__main__":
    raise SystemExit(main())
