#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from llmbench.config import cfg_get, load_config  # noqa: E402
from llmbench.dataset import validate_dataset  # noqa: E402
from llmbench.environment import capture_environment  # noqa: E402
from llmbench.io_utils import sha256_file, write_json_atomic  # noqa: E402


class Suite:
    def __init__(self, cfg_path: Path, mode: str):
        self.cfg_path = cfg_path.resolve()
        self.cfg = load_config(self.cfg_path)
        self.mode = mode
        self.results = ROOT / "results"
        self.logs = self.results / "logs"
        self.results.mkdir(exist_ok=True)
        self.logs.mkdir(exist_ok=True)

        self.model_name = str(cfg_get(self.cfg, "model.name"))
        model_override = os.environ.get("LLMJP_MODEL")
        self.model_path = Path(model_override or str(cfg_get(self.cfg, "model.path"))).expanduser().resolve()
        server_override = os.environ.get("LLMJP_LLAMA_SERVER")
        self.server_bin = Path(server_override or str(cfg_get(self.cfg, "server.binary"))).expanduser().resolve()
        repo_value = cfg_get(self.cfg, "server.repo")
        self.llama_repo = None if not repo_value else Path(str(repo_value)).expanduser().resolve()
        self.host = str(cfg_get(self.cfg, "server.host", "127.0.0.1"))
        self.port = int(cfg_get(self.cfg, "server.port", 8080))
        self.url = f"http://{self.host}:{self.port}"
        self.server_context = int(cfg_get(self.cfg, "server.context", 8192))
        self.proc: subprocess.Popen[str] | None = None
        self.server_log_handle = None
        self.pid_file = self.results / "benchmark_server.pid"
        self.server_log = self.logs / "llama_server.log"
        self.model_sha256: str | None = None
        self.gpus = self.discover_required_gpus()
        self.manifest: dict[str, Any] = {
            "schema_version": "1.3.1",
            "started_utc": datetime.now(timezone.utc).isoformat(),
            "mode": mode,
            "config": str(self.cfg_path.relative_to(ROOT)),
            "phases": [],
            "model": self.model_name,
            "model_path": str(self.model_path),
            "backend": "llama.cpp",
            "url": self.url,
        }

    def logphase(self, name: str, status: str, detail: Any = None) -> None:
        row: dict[str, Any] = {
            "name": name,
            "status": status,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        }
        if detail is not None:
            row["detail"] = detail
        self.manifest["phases"].append(row)
        write_json_atomic(self.results / "run_manifest.json", self.manifest)
        print(f"[{status}] {name}")

    def discover_required_gpus(self) -> list[dict[str, str]]:
        fake = os.getenv("LLMBENCH_FAKE_GPU_JSON")
        if fake:
            rows = json.loads(fake)
        else:
            exe = shutil.which("nvidia-smi")
            if not exe:
                raise RuntimeError("nvidia-smi not found; NVIDIA GPU environment is required")
            p = subprocess.run(
                [exe, "--query-gpu=index,uuid,name,memory.total,pci.bus_id", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, check=True, timeout=10,
            )
            rows = []
            for line in p.stdout.splitlines():
                parts = [x.strip() for x in line.split(",")]
                if len(parts) >= 5:
                    rows.append({
                        "index": parts[0], "uuid": parts[1], "name": parts[2],
                        "memory_total_mib": parts[3], "pci_bus_id": parts[4],
                    })
        required = list(cfg_get(self.cfg, "server.required_gpus", []))
        selected = []
        for req in required:
            matches = [r for r in rows if req.lower() in str(r.get("name", "")).lower()]
            if len(matches) != 1:
                raise RuntimeError(f"Required GPU {req!r}: expected exactly 1 match, found {len(matches)}. Detected={rows}")
            selected.append(matches[0])
        if len(selected) != 2:
            raise RuntimeError(f"This profile requires exactly two GPUs; configured {len(selected)}")
        return selected

    def validate_paths_and_model(self) -> None:
        if not self.server_bin.is_file() or not os.access(self.server_bin, os.X_OK):
            raise RuntimeError(
                f"llama-server not executable: {self.server_bin}. "
                "Set server.binary in config/user.yaml or LLMJP_LLAMA_SERVER."
            )
        if not self.model_path.is_file():
            raise RuntimeError(
                f"Model GGUF not found: {self.model_path}. "
                "Set model.path in config/user.yaml or LLMJP_MODEL."
            )
        expected = str(cfg_get(self.cfg, "model.expected_sha256", "") or "").lower()
        verify = bool(cfg_get(self.cfg, "model.verify_sha256", True))
        if verify:
            print(f"[setup] Verifying model SHA256 ({self.model_path.name})")
            self.model_sha256 = sha256_file(self.model_path)
            if expected and self.model_sha256.lower() != expected:
                raise RuntimeError(f"Model SHA256 mismatch: expected={expected}, actual={self.model_sha256}")
        else:
            self.model_sha256 = None
        self.logphase("model_validation", "PASS", {
            "path": str(self.model_path),
            "size_bytes": self.model_path.stat().st_size,
            "sha256": self.model_sha256,
        })

    def port_open(self) -> bool:
        with socket.socket() as s:
            s.settimeout(0.3)
            return s.connect_ex((self.host, self.port)) == 0

    def kill_stale_owned_server(self) -> None:
        if not self.pid_file.exists():
            return
        try:
            pid = int(self.pid_file.read_text().strip())
            cmdline = Path(f"/proc/{pid}/cmdline")
            text = cmdline.read_bytes().replace(b"\x00", b" ").decode(errors="ignore") if cmdline.exists() else ""
            if "llama-server" in text:
                try:
                    os.killpg(pid, signal.SIGTERM)
                except (ProcessLookupError, PermissionError):
                    pass
                time.sleep(0.5)
        except Exception:
            pass
        self.pid_file.unlink(missing_ok=True)

    def stop_server(self) -> None:
        if self.proc is not None:
            try:
                os.killpg(self.proc.pid, signal.SIGTERM)
                self.proc.wait(timeout=15)
            except Exception:
                try:
                    os.killpg(self.proc.pid, signal.SIGKILL)
                except Exception:
                    pass
            self.proc = None
        if self.server_log_handle is not None:
            try:
                self.server_log_handle.close()
            except Exception:
                pass
            self.server_log_handle = None
        self.pid_file.unlink(missing_ok=True)

    def server_command(self) -> list[str]:
        c = self.cfg["server"]
        cmd = [str(self.server_bin), "--model", str(self.model_path)]
        if c.get("jinja", True):
            cmd.append("--jinja")
        if c.get("reasoning", True):
            cmd += ["-rea", "on"]
        cmd += ["--flash-attn", "on" if c.get("flash_attention", True) else "off"]
        cmd += ["-fit", "on" if c.get("fit_enabled", False) else "off"]
        cmd += ["--split-mode", str(c.get("split_mode", "layer"))]
        cmd += ["--tensor-split", str(c.get("tensor_split", "16,7"))]
        cmd += ["-ngl", str(c.get("n_gpu_layers", "all"))]
        cmd += ["--ctx-size", str(c.get("context", 8192))]
        cmd += ["--parallel", str(c.get("parallel", 1))]
        cmd += ["--cache-type-k", str(c.get("cache_type_k", "f16"))]
        cmd += ["--cache-type-v", str(c.get("cache_type_v", "f16"))]
        cmd += ["--cache-ram", str(c.get("cache_ram_mib", 0))]
        cmd += ["-lv", str(c.get("log_verbosity", 3))]
        cmd += ["--host", self.host, "--port", str(self.port)]
        return cmd

    def start_server(self) -> None:
        if os.getenv("LLMBENCH_SKIP_SERVER") == "1":
            return
        self.stop_server()
        self.kill_stale_owned_server()
        if self.port_open():
            raise RuntimeError(
                f"Benchmark port {self.port} is already in use. Stop the existing process or change server.port."
            )
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(cfg_get(self.cfg, "server.cuda_visible_devices", "0,1"))
        self.server_log_handle = self.server_log.open("w", encoding="utf-8")
        cmd = self.server_command()
        print("[server] " + " ".join(cmd))
        self.proc = subprocess.Popen(
            cmd, cwd=ROOT, env=env, stdout=self.server_log_handle, stderr=subprocess.STDOUT,
            text=True, start_new_session=True,
        )
        self.pid_file.write_text(str(self.proc.pid) + "\n")
        timeout_s = int(cfg_get(self.cfg, "server.startup_timeout_s", 240))
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            try:
                r = requests.get(self.url + "/health", timeout=1)
                if r.ok and isinstance(r.json(), dict) and r.json().get("status") == "ok":
                    self.server_log_handle.flush()
                    self.verify_server_build_log()
                    return
            except Exception:
                pass
            if self.proc.poll() is not None:
                raise RuntimeError(
                    f"llama-server exited with code {self.proc.returncode}; see {self.server_log.relative_to(ROOT)}"
                )
            time.sleep(0.5)
        raise RuntimeError(f"llama-server did not become ready within {timeout_s} seconds")

    def verify_server_build_log(self) -> None:
        # The child process writes directly to the inherited file descriptor; allow a short
        # grace period for the startup lines to become visible after /health turns ready.
        required_gpus = [str(x) for x in cfg_get(self.cfg, "server.required_gpus", [])]
        require_cublas = bool(cfg_get(self.cfg, "server.require_force_cublas", True))
        text = ""
        for _ in range(30):
            text = self.server_log.read_text(encoding="utf-8", errors="replace") if self.server_log.exists() else ""
            cublas_ok = (not require_cublas) or ("FORCE_CUBLAS = 1" in text)
            gpu_ok = all(x in text for x in required_gpus)
            if cublas_ok and gpu_ok:
                return
            time.sleep(0.1)
        if require_cublas and "FORCE_CUBLAS = 1" not in text:
            raise RuntimeError(
                "Canonical profile requires a llama.cpp build with GGML_CUDA_FORCE_CUBLAS=ON, "
                "but FORCE_CUBLAS = 1 was not found in the server startup log."
            )
        for required in required_gpus:
            if required not in text:
                raise RuntimeError(f"Required GPU {required!r} was not found in llama-server device log")

    def cmd(self, name: str, cmd: list[str], fatal: bool = False) -> bool:
        log_path = self.logs / f"{name}.log"
        print(f"[RUN] {name}")
        with log_path.open("w", encoding="utf-8") as log:
            p = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, text=True)
        if p.returncode == 0:
            self.logphase(name, "PASS", {"log": str(log_path.relative_to(ROOT))})
            return True
        self.logphase(name, "FAIL", {"exit_code": p.returncode, "log": str(log_path.relative_to(ROOT))})
        if fatal:
            raise RuntimeError(f"Fatal phase {name} failed; see {log_path}")
        return False

    def python(self, *parts: str) -> list[str]:
        return [sys.executable, *parts]

    def validate_sealed_dataset(self, dataset_path: Path, manifest_path: Path, phase_name: str) -> dict[str, Any]:
        info = validate_dataset(dataset_path)
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        expected_hash = str(manifest["sha256"])
        actual_hash = sha256_file(dataset_path)
        if actual_hash != expected_hash:
            raise RuntimeError(
                f"Dataset SHA256 mismatch for {dataset_path.name}: manifest={expected_hash}, actual={actual_hash}"
            )
        if int(manifest.get("items", info["items"])) != int(info["items"]):
            raise RuntimeError(f"Dataset item count disagrees with manifest for {dataset_path.name}")
        detail = info | {"sha256": actual_hash, "manifest": str(manifest_path.relative_to(ROOT))}
        self.logphase(phase_name, "PASS", detail)
        return detail

    def report_command(self, core_ds: Path, challenge_ds: Path) -> list[str]:
        return self.python(
            "analysis/build_report.py", "--results", str(self.results),
            "--dataset", str(core_ds), "--challenge-dataset", str(challenge_ds),
            "--output-dir", str(self.results / "report"),
        )

    def run(self) -> int:
        unexpected_fail = False
        try:
            core_ds = ROOT / str(cfg_get(self.cfg, "quality.dataset"))
            challenge_ds = ROOT / str(cfg_get(self.cfg, "challenge.dataset", "datasets/challenge_v1.1.0.jsonl"))
            self.validate_sealed_dataset(core_ds, ROOT / "datasets" / "MANIFEST.json", "core_dataset_validation")
            self.validate_sealed_dataset(
                challenge_ds, ROOT / "datasets" / "CHALLENGE_MANIFEST.json", "challenge_dataset_validation"
            )
            if not self.cmd("unit_tests", self.python("scripts/run_unit_tests.py"), fatal=True):
                unexpected_fail = True

            self.validate_paths_and_model()
            self.start_server()
            self.logphase("llama_cpp_server", "PASS", {
                "gpus": self.gpus,
                "command": self.server_command(),
                "cuda_visible_devices": cfg_get(self.cfg, "server.cuda_visible_devices"),
            })

            env = capture_environment(
                model_file=self.model_path,
                declared_model_sha256=str(cfg_get(self.cfg, "model.expected_sha256", "") or "") or None,
                verify_model_hash=False,
                llama_server_bin=str(self.server_bin),
                llama_repo=self.llama_repo,
            )
            env["model"]["verified_sha256"] = self.model_sha256
            env["benchmark_config"] = self.cfg
            env["selected_gpus"] = self.gpus
            env["server_command"] = self.server_command()
            env["server_url"] = self.url
            env["datasets"] = {
                "core": {"path": str(core_ds), "sha256": sha256_file(core_ds)},
                "challenge": {"path": str(challenge_ds), "sha256": sha256_file(challenge_ds)},
            }
            write_json_atomic(self.results / "environment.json", env)
            self.logphase("environment_capture", "PASS")

            pre = self.results / "preflight.json"
            self.cmd(
                "preflight",
                self.python(
                    "scripts/preflight_llamacpp.py", "--url", self.url, "--model", self.model_name,
                    "--context", str(self.server_context), "--output", str(pre),
                ),
                fatal=True,
            )
            pdata = json.loads(pre.read_text())
            caps = pdata.get("capabilities", {})
            effort_verified = bool(caps.get("reasoning_effort_template_labels_verified"))
            core_effort = "medium"

            if self.mode == "quick":
                self.manifest["completed_utc"] = datetime.now(timezone.utc).isoformat()
                write_json_atomic(self.results / "run_manifest.json", self.manifest)
                return 0

            q = cfg_get(self.cfg, "quality", {})
            if int(q["context"]) != self.server_context:
                raise RuntimeError("quality.context must equal the fixed server.context in canonical profile")

            run_core_track = self.mode in {"full", "core"}
            run_challenge_track = self.mode in {"full", "challenge"} and bool(cfg_get(self.cfg, "challenge.enabled", True))

            if run_core_track:
                core_dir = self.results / f"core_{core_effort}_ctx{q['context']}"
                core_cmd = self.python(
                    "src/run_benchmark.py", "--url", self.url, "--model", self.model_name,
                    "--dataset", str(core_ds), "--run-dir", str(core_dir),
                    "--reasoning-effort", core_effort, "--context", str(q["context"]),
                    "--server-context", str(self.server_context), "--max-tokens", str(q["max_tokens"]),
                    "--temperature", str(q["temperature"]), "--top-p", str(q["top_p"]),
                    "--top-k", str(q["top_k"]), "--min-p", str(q["min_p"]),
                    "--repeat-penalty", str(q["repeat_penalty"]), "--seed", str(q["seed"]),
                    "--timeout", str(q["timeout_s"]),
                    "--monitor-interval", str(cfg_get(self.cfg, "performance.monitor_interval_s", 0.2)),
                )
                if not self.cmd("core_128", core_cmd):
                    unexpected_fail = True

                if cfg_get(self.cfg, "reasoning.enabled", True) and effort_verified:
                    for eff in ("low", "high"):
                        rd = self.results / f"reasoning_{eff}_ctx{q['context']}"
                        c = self.python(
                            "src/run_benchmark.py", "--url", self.url, "--model", self.model_name,
                            "--dataset", str(core_ds), "--run-dir", str(rd), "--reasoning-effort", eff,
                            "--only-reasoning-subset", "--context", str(q["context"]),
                            "--server-context", str(self.server_context), "--max-tokens", str(q["max_tokens"]),
                            "--temperature", "0", "--top-p", "1", "--top-k", "0", "--min-p", "0",
                            "--repeat-penalty", "1", "--seed", str(q["seed"]), "--timeout", str(q["timeout_s"]),
                        )
                        if not self.cmd(f"reasoning_{eff}", c):
                            unexpected_fail = True
                    self.logphase("reasoning_medium", "PASS", {"source": "Core run frozen reasoning subset"})
                else:
                    self.logphase(
                        "reasoning_effort_comparison", "SKIP",
                        {"reason": "LLM-jp Jinja low/medium/high labels were not verified by /apply-template"},
                    )

            if run_challenge_track:
                ch = cfg_get(self.cfg, "challenge", {})
                ch_ctx = int(ch.get("context", q["context"]))
                if ch_ctx != self.server_context:
                    raise RuntimeError("challenge.context must equal the fixed server.context in canonical profile")
                ch_effort = str(ch.get("reasoning_effort", "medium"))
                ch_dir = self.results / f"challenge_{ch_effort}_ctx{ch_ctx}"
                challenge_cmd = self.python(
                    "src/run_benchmark.py", "--url", self.url, "--model", self.model_name,
                    "--dataset", str(challenge_ds), "--run-dir", str(ch_dir),
                    "--reasoning-effort", ch_effort, "--context", str(ch_ctx),
                    "--server-context", str(self.server_context), "--max-tokens", str(ch.get("max_tokens", q["max_tokens"])),
                    "--temperature", str(q["temperature"]), "--top-p", str(q["top_p"]),
                    "--top-k", str(q["top_k"]), "--min-p", str(q["min_p"]),
                    "--repeat-penalty", str(q["repeat_penalty"]), "--seed", str(q["seed"]),
                    "--timeout", str(q["timeout_s"]),
                    "--monitor-interval", str(cfg_get(self.cfg, "performance.monitor_interval_s", 0.2)),
                )
                if not self.cmd("challenge_80", challenge_cmd):
                    unexpected_fail = True
            elif self.mode == "challenge":
                self.logphase("challenge_80", "SKIP", {"reason": "challenge.enabled=false"})

            # Performance and synthetic long-context tracks are deliberately skipped by challenge-only mode.
            if run_core_track:
                perf = cfg_get(self.cfg, "performance", {})
                if perf.get("enabled", True):
                    contexts = [int(x) for x in perf.get("contexts", [self.server_context])]
                    if any(x != self.server_context for x in contexts):
                        raise RuntimeError(
                            "Canonical run uses one fixed llama-server context. performance.contexts must contain only server.context."
                        )
                    if not self.cmd(
                        "context_performance",
                        self.python(
                            "scripts/system_probe.py", "--url", self.url, "--model", self.model_name,
                            "--contexts", ",".join(map(str, contexts)), "--server-context", str(self.server_context),
                            "--warmups", str(perf["warmups"]), "--repeats", str(perf["repeats"]),
                            "--num-predict", str(perf["num_predict"]), "--reasoning-effort", core_effort,
                            "--monitor-interval", str(perf["monitor_interval_s"]),
                            "--output-dir", str(self.results / "context_performance"),
                        ),
                    ):
                        unexpected_fail = True

                lc = cfg_get(self.cfg, "long_context", {})
                if lc.get("enabled", True):
                    contexts = [int(x) for x in lc.get("contexts", [self.server_context])]
                    if any(x != self.server_context for x in contexts):
                        raise RuntimeError("Canonical long-context phase must use the fixed 8K server context")
                    if not self.cmd(
                        "long_context_accuracy",
                        self.python(
                            "scripts/long_context_benchmark.py", "--url", self.url, "--model", self.model_name,
                            "--contexts", ",".join(map(str, contexts)), "--server-context", str(self.server_context),
                            "--items-per-context", str(lc["items_per_context"]), "--max-tokens", str(lc["max_tokens"]),
                            "--reasoning-effort", core_effort,
                            "--output-dir", str(self.results / "long_context_accuracy"),
                        ),
                    ):
                        unexpected_fail = True

                if cfg_get(self.cfg, "vram_margin_sweep.enabled", False):
                    self.logphase(
                        "vram_margin_sweep", "SKIP",
                        {"reason": "Ollama fit-target sweep is not part of the canonical fixed llama.cpp profile"},
                    )

            self.stop_server()
            if not self.cmd("report", self.report_command(core_ds, challenge_ds)):
                unexpected_fail = True
            self.manifest["completed_utc"] = datetime.now(timezone.utc).isoformat()
            self.manifest["unexpected_failures"] = unexpected_fail
            write_json_atomic(self.results / "run_manifest.json", self.manifest)
            return 1 if unexpected_fail else 0
        finally:
            self.stop_server()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "mode", nargs="?", choices=["full", "core", "challenge", "quick", "report", "validate"], default="full"
    )
    ap.add_argument("--config", type=Path, default=ROOT / "config" / "user.yaml")
    a = ap.parse_args()
    if a.mode == "validate":
        cfg = load_config(a.config)
        core_ds = ROOT / str(cfg_get(cfg, "quality.dataset"))
        challenge_ds = ROOT / str(cfg_get(cfg, "challenge.dataset", "datasets/challenge_v1.1.0.jsonl"))
        core_manifest = json.loads((ROOT / "datasets" / "MANIFEST.json").read_text(encoding="utf-8"))
        challenge_manifest = json.loads((ROOT / "datasets" / "CHALLENGE_MANIFEST.json").read_text(encoding="utf-8"))
        core_hash = sha256_file(core_ds)
        challenge_hash = sha256_file(challenge_ds)
        if core_hash != str(core_manifest["sha256"]):
            raise RuntimeError(f"Core dataset SHA256 mismatch: {core_hash}")
        if challenge_hash != str(challenge_manifest["sha256"]):
            raise RuntimeError(f"Challenge dataset SHA256 mismatch: {challenge_hash}")
        out = {
            "core": validate_dataset(core_ds) | {"sha256": core_hash, "sealed": True},
            "challenge": validate_dataset(challenge_ds) | {"sha256": challenge_hash, "sealed": True},
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0
    if a.mode == "report":
        cfg = load_config(a.config)
        core_ds = ROOT / str(cfg_get(cfg, "quality.dataset"))
        challenge_ds = ROOT / str(cfg_get(cfg, "challenge.dataset", "datasets/challenge_v1.1.0.jsonl"))
        return subprocess.run([
            sys.executable, "analysis/build_report.py", "--results", str(ROOT / "results"),
            "--dataset", str(core_ds), "--challenge-dataset", str(challenge_ds),
            "--output-dir", str(ROOT / "results" / "report"),
        ], cwd=ROOT).returncode
    try:
        return Suite(a.config, a.mode).run()
    except KeyboardInterrupt:
        print("\nInterrupted; partial JSONL results are retained and completed items resume independently.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"FATAL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
