#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from llmbench.backends.llama_cpp import LlamaCppBackend  # noqa: E402
from llmbench.io_utils import write_json_atomic  # noqa: E402
from llmbench.types import GenerationConfig, InferenceRequest  # noqa: E402


def get_json(session: requests.Session, url: str, timeout: float = 15.0) -> Any:
    r = session.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def apply_template(session: requests.Session, base: str, effort: str) -> dict[str, Any]:
    payload = {
        "messages": [{"role": "user", "content": "template check"}],
        "chat_template_kwargs": {"reasoning_effort": effort},
    }
    try:
        r = session.post(f"{base}/apply-template", json=payload, timeout=30)
        r.raise_for_status()
        d = r.json()
        prompt = d.get("prompt", "") if isinstance(d, dict) else ""
        return {
            "accepted": True,
            "contains_expected_reasoning_label": f"Reasoning: {effort}" in prompt,
            "prompt_excerpt": prompt[:800],
        }
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}


def inference_check(base: str, model: str, context: int, effort: str) -> dict[str, Any]:
    backend = LlamaCppBackend(base, model, timeout_s=600, server_context=context)
    gen = GenerationConfig(
        max_tokens=512,
        context_size=context,
        temperature=0,
        top_p=1,
        top_k=0,
        min_p=0,
        repeat_penalty=1,
        seed=42,
        reasoning_effort=effort,  # type: ignore[arg-type]
    )
    try:
        r = backend.generate(InferenceRequest(
            sample_id=f"preflight_{effort}",
            messages=[{"role": "user", "content": "91を7で割った商を求めてください。最後の行に答えだけを書いてください。"}],
            generation=gen,
        ))
        cached = r.raw_metadata.get("llama_cpp", {}).get("cached_prompt_tokens")
        return {
            "accepted": True,
            "content": r.content,
            "reasoning_present": bool(r.reasoning_content and r.reasoning_content.strip()),
            "reasoning_chars": 0 if r.reasoning_content is None else len(r.reasoning_content),
            "prompt_tokens": r.prompt_tokens,
            "completion_tokens": r.completion_tokens,
            "cached_prompt_tokens": cached,
            "prompt_tokens_per_s": r.prompt_tokens_per_s,
            "completion_tokens_per_s": r.completion_tokens_per_s,
            "finish_reason": r.finish_reason,
            "correct": "13" in r.content,
        }
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--context", type=int, default=8192)
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    base = a.url.rstrip("/")
    s = requests.Session()
    out: dict[str, Any] = {
        "schema_version": "1.3.1",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "url": base,
        "model": a.model,
        "checks": {},
        "template_efforts": {},
        "inference_efforts": {},
        "warnings": [],
    }
    try:
        out["checks"]["health"] = get_json(s, f"{base}/health", 10)
        out["checks"]["props"] = get_json(s, f"{base}/props", 20)
        out["checks"]["models"] = get_json(s, f"{base}/v1/models", 20)
    except Exception as exc:
        out["fatal_error"] = f"Server metadata check failed: {type(exc).__name__}: {exc}"
        write_json_atomic(a.output, out)
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 2

    props = out["checks"].get("props") if isinstance(out["checks"], dict) else None
    if isinstance(props, dict):
        n_ctx = (((props.get("default_generation_settings") or {}).get("n_ctx"))
                 if isinstance(props.get("default_generation_settings"), dict) else None)
        if n_ctx is not None and int(n_ctx) != a.context:
            out["fatal_error"] = f"Server context mismatch: expected {a.context}, /props reports {n_ctx}"
            write_json_atomic(a.output, out)
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return 2

    for effort in ("low", "medium", "high"):
        out["template_efforts"][effort] = apply_template(s, base, effort)
        out["inference_efforts"][effort] = inference_check(base, a.model, a.context, effort)

    baseline = out["inference_efforts"]["medium"]
    fatal_reasons: list[str] = []
    if not baseline.get("accepted"):
        fatal_reasons.append("medium preflight inference was rejected")
    if not str(baseline.get("content") or "").strip():
        fatal_reasons.append("final answer is empty")
    if int(baseline.get("completion_tokens") or 0) <= 1:
        fatal_reasons.append("completion token count <= 1")
    if not baseline.get("reasoning_present"):
        fatal_reasons.append("reasoning_content is empty")
    if not baseline.get("correct"):
        fatal_reasons.append("smoke-test arithmetic answer is not 13")
    if int(baseline.get("cached_prompt_tokens") or 0) != 0:
        fatal_reasons.append("prompt cache reuse was observed despite cache_prompt=false")
    if baseline.get("finish_reason") == "length":
        fatal_reasons.append("preflight hit the generation token limit")

    template_labels_ok = all(
        bool(out["template_efforts"][e].get("contains_expected_reasoning_label"))
        for e in ("low", "medium", "high")
    )
    levels_accepted = all(bool(out["inference_efforts"][e].get("accepted")) for e in ("low", "medium", "high"))
    out["capabilities"] = {
        "reasoning_content_present": bool(baseline.get("reasoning_present")),
        "reasoning_effort_template_labels_verified": template_labels_ok,
        "reasoning_effort_requests_accepted": levels_accepted,
        "prompt_cache_reuse_disabled": int(baseline.get("cached_prompt_tokens") or 0) == 0,
    }
    if levels_accepted and not template_labels_ok:
        out["warnings"].append(
            "low/medium/high requests were accepted, but /apply-template did not prove that the Jinja prompt changed. "
            "Reasoning-effort comparison will be skipped rather than assumed valid."
        )
    if template_labels_ok:
        out["warnings"].append(
            "The rendered template distinguishes low/medium/high. This verifies the control signal, not that every item will consume materially different reasoning budgets."
        )

    if fatal_reasons:
        out["fatal_error"] = "; ".join(fatal_reasons)
        write_json_atomic(a.output, out)
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 2

    write_json_atomic(a.output, out)
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
