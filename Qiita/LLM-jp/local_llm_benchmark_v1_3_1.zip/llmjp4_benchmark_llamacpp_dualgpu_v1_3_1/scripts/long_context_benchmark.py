#!/usr/bin/env python3
from __future__ import annotations
import argparse, dataclasses, json, sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from llmbench.backends.llama_cpp import LlamaCppBackend  # noqa:E402
from llmbench.hardware_monitor import HardwareMonitor  # noqa:E402
from llmbench.io_utils import append_jsonl, write_json_atomic  # noqa:E402
from llmbench.scoring import score_answer  # noqa:E402
from llmbench.runner import classify_error  # noqa:E402
from llmbench.types import GenerationConfig, InferenceRequest  # noqa:E402


def filler(n:int)->str:
    base="背景資料では、測定条件、解析手順、対象群、例外条件を区別して記録する。結論は個々の記述を照合した後にのみ導く。"
    return (base*((n//len(base))+1))[:n]

def build_prompt_chars(n_chars:int,variant:int)->tuple[str,dict]:
    n=max(2000,n_chars); a=filler(n//4);b=filler(n//4);c=filler(n//4);d=filler(n//4)
    if variant==0:
        facts=("試料K-17の校正係数は1.375である。","最終測定ロットの有効試料数は84である。")
        prompt=f"{a}\n重要記録A:{facts[0]}\n{b}\n{c}\n重要記録B:{facts[1]}\n{d}\n校正係数と有効試料数をJSONで返せ。キーはcalibration,samples。"
        exp={"calibration":1.375,"samples":84}
    elif variant==1:
        prompt=f"{a}\n記録:装置Pの閾値は42、装置Qの閾値は57。\n{b}\n{c}\n追記:採用規則は閾値が50未満の装置だけを採用する。\n{d}\n採用装置をJSON {{\"selected\":[...]}}で返せ。"
        exp={"selected":["P"]}
    elif variant==2:
        prompt=f"{a}\n第1報:反応Aの収率は72.5%。\n{b}\n第2報:反応Bの収率は68.0%。\n{c}\n第3報:Aは後処理で5.0ポイント低下、Bは変化なし。\n{d}\n後処理後に高収率なのはどちらか。JSON {{\"winner\":\"A or B\",\"yield\":数値}}。"
        exp={"winner":"B","yield":68.0}
    else:
        prompt=f"{a}\n規則1:区分Rは温度300K以上かつ圧力2bar未満で有効。\n{b}\n測定:Rの温度315K。\n{c}\n測定:Rの圧力1.6bar。\n{d}\nRが有効かJSON {{\"valid\":true/false}}で返せ。"
        exp={"valid":True}
    return prompt,exp


def build_targeted_prompt(backend:LlamaCppBackend,ctx:int,variant:int,effort:str|None,max_tokens:int)->tuple[str,dict,int,int]:
    target=min(int(ctx*.80),ctx-max_tokens-256)
    target=max(1024,target)
    n_chars=max(2000,target*2)
    prompt,exp=build_prompt_chars(n_chars,variant)
    count=backend.count_chat_tokens([{"role":"user","content":prompt}],effort)
    for _ in range(8):
        if abs(count-target)<=max(48,int(target*.02)):
            break
        n_chars=max(2000,int(n_chars*target/max(count,1)))
        prompt,exp=build_prompt_chars(n_chars,variant)
        count=backend.count_chat_tokens([{"role":"user","content":prompt}],effort)
    return prompt,exp,target,count

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--model',required=True);ap.add_argument('--contexts',required=True);ap.add_argument('--server-context',type=int,required=True);ap.add_argument('--items-per-context',type=int,default=4);ap.add_argument('--max-tokens',type=int,default=768);ap.add_argument('--reasoning-effort',choices=['none','low','medium','high'],default='none');ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    effort=None if a.reasoning_effort=='none' else a.reasoning_effort;backend=LlamaCppBackend(a.url,a.model,timeout_s=1800,server_context=a.server_context);out=a.output_dir/'results.jsonl';hw=a.output_dir/'hardware_samples.jsonl';existing=[]
    if out.exists():
        for line in out.read_text(encoding='utf-8').splitlines():
            try: existing.append(json.loads(line))
            except json.JSONDecodeError: pass
    completed={(int(r.get('context')),int(r.get('item'))) for r in existing if isinstance(r.get('context'),int) and isinstance(r.get('item'),int)}
    mon=HardwareMonitor(hw,.2);mon.start();tot=ok=err=0
    try:
      for ctx in [int(x) for x in a.contexts.split(',') if x]:
       for i in range(a.items_per_context):
        tot+=1
        if (ctx,i) in completed:
            continue
        prompt,exp,target_prompt_tokens,counted_prompt_tokens=build_targeted_prompt(backend,ctx,i%4,effort,a.max_tokens);label=f"long_ctx{ctx}_{i}";mon.set_active_label(label)
        gen=GenerationConfig(max_tokens=a.max_tokens,context_size=ctx,temperature=0,seed=42,reasoning_effort=effort) # type:ignore[arg-type]
        try:
            r=backend.generate(InferenceRequest(label,[{"role":"user","content":prompt}],gen));sc=score_answer(r.content,{"type":"json_exact","expected":exp});row={"schema_version":"1.2.0","timestamp_utc":datetime.now(timezone.utc).isoformat(),"status":"ok","context":ctx,"item":i,"expected":exp,"response":r.content,"score":dataclasses.asdict(sc),"target_prompt_tokens":target_prompt_tokens,"counted_prompt_tokens_before_inference":counted_prompt_tokens,"metrics":{"prompt_tokens":r.prompt_tokens,"completion_tokens":r.completion_tokens,"prompt_tokens_per_s":r.prompt_tokens_per_s,"completion_tokens_per_s":r.completion_tokens_per_s,"ttft_s":r.ttft_s,"wall_time_s":r.wall_time_s},"hardware":mon.summarize(label)};ok+=int(sc.passed)
        except Exception as exc:
            row={"schema_version":"1.2.0","timestamp_utc":datetime.now(timezone.utc).isoformat(),"status":"error","context":ctx,"item":i,"error_class":classify_error(exc),"error":f"{type(exc).__name__}: {exc}"};err+=1
        finally:mon.set_active_label(None)
        append_jsonl(out,row)
    finally:mon.stop()
    all_rows=[]
    if out.exists():
        for line in out.read_text(encoding='utf-8').splitlines():
            try: all_rows.append(json.loads(line))
            except json.JSONDecodeError: pass
    passed=sum(1 for r in all_rows if r.get('status')=='ok' and r.get('score',{}).get('passed'))
    errors=sum(1 for r in all_rows if r.get('status')=='error')
    classes={}
    for r in all_rows:
        if r.get('status')=='error':
            c=str(r.get('error_class') or 'unknown');classes[c]=classes.get(c,0)+1
    summary={"total":tot,"completed_rows":len(all_rows),"passed":passed,"errors":errors,"error_classes":classes,"accuracy_over_target":passed/tot if tot else None};write_json_atomic(a.output_dir/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
    return 1 if any(classes.get(k,0) for k in ('backend_error','inference_error')) else 0
if __name__=='__main__':raise SystemExit(main())
