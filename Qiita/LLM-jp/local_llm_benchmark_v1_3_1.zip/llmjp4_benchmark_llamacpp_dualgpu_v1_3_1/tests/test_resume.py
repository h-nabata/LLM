from __future__ import annotations

import json
import tempfile
import time
import unittest
from pathlib import Path

from llmbench.backends.base import InferenceBackend
from llmbench.runner import run_benchmark
from llmbench.types import GenerationConfig, InferenceRequest, InferenceResult


class FakeBackend(InferenceBackend):
    def __init__(self) -> None:
        self.calls = 0

    def generate(self, request: InferenceRequest) -> InferenceResult:
        self.calls += 1
        time.sleep(0.03)
        return InferenceResult(content="A", reasoning_content="test", wall_time_s=0.03, ttft_s=0.01)


class ResumeTests(unittest.TestCase):
    def test_completed_samples_are_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            dataset = root / "one.jsonl"
            dataset.write_text(json.dumps({
                "id": "x", "category": "logic", "difficulty": "hard", "prompt": "p",
                "grader": {"type": "choice", "expected": "A", "choices": ["A", "B"]}
            }, ensure_ascii=False) + "\n", encoding="utf-8")
            backend = FakeBackend()
            cfg = GenerationConfig(reasoning_effort="medium")
            first = run_benchmark(backend, dataset, root / "run", cfg, "fake", monitor_interval_s=0.01)
            second = run_benchmark(backend, dataset, root / "run", cfg, "fake", monitor_interval_s=0.01)
            self.assertEqual(first["ok"], 1)
            self.assertEqual(second["skipped_existing"], 1)
            self.assertEqual(backend.calls, 1)


if __name__ == "__main__":
    unittest.main()
