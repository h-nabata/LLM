from __future__ import annotations

import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from llmbench.backends.llama_cpp import LlamaCppBackend
from llmbench.types import GenerationConfig, InferenceRequest


class _Handler(BaseHTTPRequestHandler):
    last_body = None

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length) or b"{}")
        type(self).last_body = body
        if self.path == "/v1/chat/completions/input_tokens":
            data = json.dumps({"object": "response.input_tokens", "input_tokens": 123}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path != "/v1/chat/completions":
            self.send_response(404)
            self.end_headers()
            return
        payload = {
            "choices": [{
                "finish_reason": "stop", "index": 0,
                "message": {"role": "assistant", "content": "391", "reasoning_content": "17*23=391"},
            }],
            "model": "fake", "system_fingerprint": "fake-build",
            "usage": {
                "prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120,
                "prompt_tokens_details": {"cached_tokens": 0},
            },
            "timings": {
                "prompt_ms": 1000.0, "prompt_per_second": 100.0,
                "predicted_ms": 500.0, "predicted_per_second": 40.0,
            },
        }
        data = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format: str, *args: object) -> None:
        return


class LlamaCppBackendTests(unittest.TestCase):
    def test_openai_response_and_llama_extensions(self) -> None:
        server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            backend = LlamaCppBackend(
                f"http://127.0.0.1:{server.server_port}", "test-model", server_context=8192
            )
            result = backend.generate(InferenceRequest(
                "x", [{"role": "user", "content": "test"}],
                GenerationConfig(reasoning_effort="medium"),
            ))
            body = _Handler.last_body
            self.assertIsNotNone(body)
            self.assertFalse(body["cache_prompt"])
            self.assertEqual(body["chat_template_kwargs"]["reasoning_effort"], "medium")
            self.assertEqual(body["max_tokens"], 2048)
            self.assertEqual(result.reasoning_content, "17*23=391")
            self.assertEqual(result.content, "391")
            self.assertEqual(result.prompt_tokens, 100)
            self.assertEqual(result.completion_tokens, 20)
            self.assertEqual(result.raw_metadata["llama_cpp"]["cached_prompt_tokens"], 0)
            self.assertAlmostEqual(result.prompt_tokens_per_s or 0, 100.0)
            self.assertAlmostEqual(result.completion_tokens_per_s or 0, 40.0)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_count_chat_tokens(self) -> None:
        server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            backend = LlamaCppBackend(f"http://127.0.0.1:{server.server_port}", "test-model")
            self.assertEqual(backend.count_chat_tokens([{"role":"user","content":"hello"}], "medium"), 123)
        finally:
            server.shutdown(); server.server_close(); thread.join(timeout=2)

    def test_context_guard(self) -> None:
        backend = LlamaCppBackend("http://fake", "m", server_context=8192)
        with self.assertRaises(ValueError):
            backend.generate(InferenceRequest(
                "x", [{"role": "user", "content": "q"}], GenerationConfig(context_size=16384)
            ))


if __name__ == "__main__":
    unittest.main()
