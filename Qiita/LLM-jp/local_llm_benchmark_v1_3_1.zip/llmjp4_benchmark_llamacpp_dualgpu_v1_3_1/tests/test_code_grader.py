from __future__ import annotations
import unittest
from llmbench.scoring import score_answer
class CodeGraderTests(unittest.TestCase):
    def test_safe_code_passes(self):
        g={'type':'python_unit_test','entrypoint':'f','tests':[{'args':[[2,7,9,3,1]],'expected':12},{'args':[[-2]],'expected':0}]}
        a='''def f(nums):\n    prev2=prev1=0\n    for x in nums:\n        prev2,prev1=prev1,max(prev1,prev2+x)\n    return prev1\n'''
        r=score_answer(a,g);self.assertTrue(r.passed);self.assertEqual(r.score,1.0)
    def test_typing_import_allowed(self):
        g={'type':'python_unit_test','entrypoint':'f','tests':[{'args':[[1,2]],'expected':2}]}
        r=score_answer('from typing import List\ndef f(x: List[int]) -> int: return len(x)',g);self.assertTrue(r.passed)
    def test_future_import_allowed(self):
        g={'type':'python_unit_test','entrypoint':'f','tests':[{'args':[],'expected':1}]}
        r=score_answer('from __future__ import annotations\ndef f(): return 1',g);self.assertTrue(r.passed)
    def test_forbidden_import_fails(self):
        g={'type':'python_unit_test','entrypoint':'f','tests':[{'args':[],'expected':1}]}
        r=score_answer('import os\ndef f(): return 1',g);self.assertFalse(r.passed);self.assertIn('validation_errors',r.details)
    def test_json_fence(self):
        r=score_answer('```json\n{"x":1}\n```',{'type':'json_exact','expected':{'x':1}});self.assertTrue(r.passed)
    def test_numeric_final_line(self):
        r=score_answer('途中 2 と 3。\n最終回答: 6',{'type':'numeric','expected':6});self.assertTrue(r.passed)
if __name__=='__main__':unittest.main()
