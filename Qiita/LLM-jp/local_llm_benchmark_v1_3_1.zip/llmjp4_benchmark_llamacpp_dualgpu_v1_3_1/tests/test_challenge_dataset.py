from __future__ import annotations

import json
import unittest
from pathlib import Path

from llmbench.dataset import load_dataset, validate_dataset
from llmbench.io_utils import sha256_file

ROOT = Path(__file__).resolve().parents[1]


class ChallengeDatasetTests(unittest.TestCase):
    def test_challenge_shape_balance_and_hash(self):
        path = ROOT / "datasets" / "challenge_v1.1.0.jsonl"
        rows = load_dataset(path)
        self.assertEqual(len(rows), 80)
        self.assertEqual({x.difficulty for x in rows}, {"challenge"})
        self.assertEqual(sum(x.reasoning_effort_eval for x in rows), 0)
        v = validate_dataset(path)
        self.assertEqual(len(v["categories"]), 10)
        self.assertTrue(all(n == 8 for n in v["categories"].values()))
        self.assertEqual(v["graders"], {
            "choice": 21,
            "json_exact": 16,
            "numeric": 35,
            "python_unit_test": 8,
        })
        manifest = json.loads((ROOT / "datasets" / "CHALLENGE_MANIFEST.json").read_text())
        self.assertEqual(sha256_file(path), manifest["sha256"])
        self.assertEqual(manifest["items"], 80)

    def test_challenge_ids_are_namespaced(self):
        path = ROOT / "datasets" / "challenge_v1.1.0.jsonl"
        rows = load_dataset(path)
        self.assertTrue(all(x.id.startswith("C") for x in rows))
        self.assertEqual(len({x.id for x in rows}), 80)


if __name__ == "__main__":
    unittest.main()
