import unittest
from llmbench.runner import classify_error
class ErrorTests(unittest.TestCase):
    def test_oom(self): self.assertEqual(classify_error(RuntimeError('CUDA out of memory')),'resource_limit')
    def test_timeout(self): self.assertEqual(classify_error(TimeoutError('timed out')),'timeout')
if __name__=='__main__':unittest.main()
