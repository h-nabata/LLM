from __future__ import annotations
import importlib.util,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('build_report',ROOT/'analysis'/'build_report.py');assert SPEC and SPEC.loader
MOD=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(MOD)
class StatisticsTests(unittest.TestCase):
    def test_wilson_bounds(self):
        lo,hi=MOD.wilson(8,10);assert lo is not None and hi is not None;self.assertLess(lo,.8);self.assertGreater(hi,.8);self.assertGreaterEqual(lo,0);self.assertLessEqual(hi,1)
if __name__=='__main__':unittest.main()
