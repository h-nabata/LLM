from __future__ import annotations

import unittest

from llmbench.scoring import score_answer


class ScoringTests(unittest.TestCase):
    def test_normalized_exact(self) -> None:
        self.assertTrue(score_answer("ＣＡＢＤ。", {"type": "normalized_exact", "expected": "CABD"}).passed)

    def test_choice_verbose_single_choice(self) -> None:
        result = score_answer("したがって A です。", {"type": "choice", "expected": "A", "choices": ["A", "B", "C"]})
        self.assertTrue(result.passed)

    def test_choice_ambiguous_fails(self) -> None:
        result = score_answer("A ではなく B", {"type": "choice", "expected": "B", "choices": ["A", "B", "C"]})
        self.assertFalse(result.passed)

    def test_numeric(self) -> None:
        self.assertTrue(score_answer("30", {"type": "numeric", "expected": 30, "atol": 0, "rtol": 0}).passed)
        self.assertFalse(score_answer("30人中31人", {"type": "numeric", "expected": 30}).passed)

    def test_numeric_fraction(self) -> None:
        self.assertTrue(score_answer("最終回答: 8/3", {"type": "numeric", "expected": 8/3, "atol": 0, "rtol": 1e-12}).passed)

    def test_numeric_unicode_scientific(self) -> None:
        self.assertTrue(score_answer("最終回答: -2.54×10^3 J/mol", {"type": "numeric", "expected": -2540, "atol": 0, "rtol": 0}).passed)


if __name__ == "__main__":
    unittest.main()


def test_numeric_unicode_superscript_scientific_notation():
    r = score_answer("最終回答: -2.54 × 10³ J mol⁻¹", {"type": "numeric", "expected": -2540.0, "rtol": 1e-9, "atol": 1e-9})
    assert r.passed
    assert r.details["parsed"] == -2540.0


def test_numeric_unicode_negative_superscript_exponent():
    r = score_answer("最終回答: 8.18×10⁻³", {"type": "numeric", "expected": 0.00818, "rtol": 1e-12, "atol": 1e-12})
    assert r.passed
