from __future__ import annotations
import json, unittest
from pathlib import Path
from llmbench.dataset import load_dataset, validate_dataset
from llmbench.io_utils import sha256_file
ROOT=Path(__file__).resolve().parents[1]
class DatasetTests(unittest.TestCase):
    def test_core_shape_and_hash(self):
        path=ROOT/'datasets'/'core_v2.1.0.jsonl'; rows=load_dataset(path); self.assertEqual(len(rows),128);self.assertEqual({x.difficulty for x in rows},{'hard','expert'});self.assertEqual(sum(x.reasoning_effort_eval for x in rows),48)
        manifest=json.loads((ROOT/'datasets'/'MANIFEST.json').read_text());self.assertEqual(sha256_file(path),manifest['sha256'])
        v=validate_dataset(path);self.assertEqual(v['categories']['coding'],16)
if __name__=='__main__':unittest.main()
