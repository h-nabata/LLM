# Design specification — v1.3.1

## Goal

LLM-jp-4-33B-thinking Q4_K_M を、LLM-jp版 llama.cpp と固定デュアルGPU 8K条件で再現性高く評価し、**broad Core capability**, **high-difficulty Challenge capability**, **reasoning-effort behavior**, **system performance** を分離して保存する。

## Canonical hardware/runtime profile

- RTX 5070 Ti 16 GB + RTX 3070 Ti 8 GB
- LLM-jp llama.cpp
- CUDA build with `GGML_CUDA_FORCE_CUBLAS=ON`
- context 8192
- `--split-mode layer`
- `--tensor-split 16,7`
- `-ngl all`
- K/V cache f16
- Flash Attention on
- `-fit off`
- `--parallel 1`
- prompt-cache reuse disabled

この8K条件は全層GPU offloadが成立する。16KではCPU offloadまたはKV量子化が必要となるため、canonical capability runとは別profileとする。

## Core track

Core v2.1.0は固定128問。medium reasoningで全問を評価する。48問の固定subsetについて、Jinja `reasoning_effort` がlow/medium/highとしてrenderされることをpreflightで確認できた場合のみlow/highを追加測定する。

Coreは広い能力範囲と長期比較の安定性を優先し、Challenge追加後も変更しない。

## Challenge track

Challenge v1.0.0は固定80問。Coreと同じ10カテゴリに**各8問**を割り当て、カテゴリウェイトを完全に均等化する。

Challengeは長文化ではなく、以下によって天井効果を抑える。

- multi-step inference
- interacting constraints
- counterfactual / necessary-vs-sufficient distinctions
- causal-identification traps
- coding edge cases and stateful algorithms
- coupled scientific calculations
- epistemic discipline under incomplete/conflicting evidence
- exact structured output with cross-field consistency

Challengeはmedium reasoningのみで評価し、Coreと別スコアとして報告する。CoreとChallengeの恣意的な加重平均を標準スコアにはしない。

## Execution modes

- `./run.sh` / `./run.sh full`: Core + reasoning subset + Challenge + performance + long-context
- `./run.sh core`: Core + reasoning subset + performance + long-context; Challengeなし
- `./run.sh challenge`: Challengeのみ。Core/reasoning/performance/long-contextを再実行しない
- `./run.sh quick`: setup + preflight
- `./run.sh validate`: Core/Challenge dataset validation
- `./run.sh report`: existing resultsからreport再生成

## System performance

サーバcontextは起動時固定であり、request単位では変更しない。canonical runでは8Kのみを測定する。llama.cpp responseの `timings.prompt_per_second` と `timings.predicted_per_second` を一次計測値とし、CPU/RAM/GPU/VRAM/power/temperatureを約200 ms間隔で独立monitorする。

Performance requestではprefix-cache reuseを禁止し、responseのcached token countが0でない測定はinvalidとする。

## Failure semantics

- setup/dataset/hash/unit-test/preflight failure: fatal
- empty final answer / <=1 completion token in preflight: fatal
- prompt cache reuse in preflight/performance: fatal or measured error
- per-item inference error: record and continue
- OOM/resource limit: record as `resource_limit`
- reasoning effort template not verified: low/high comparison SKIP

## Resume semantics

各trackは sample ID + dataset SHA prefix + reasoning effort + context + seed をkeyとして完了済み結果をskipする。CoreとChallengeは独立したresults directoryを使うため、Challenge-only実行で既存Core推論を消費しない。

## Dataset governance

- Core seal: `datasets/MANIFEST.json`
- Challenge seal: `datasets/CHALLENGE_MANIFEST.json`

モデル結果を確認した後にChallenge問題を同一versionのまま「差がつくように」編集してはならない。将来のcalibration変更はChallenge dataset versionを上げ、新しいSHA256を発行する。

## Non-canonical stress profiles

16K/32K、CPU offload、K/V cache q8_0、異なるtensor split、`ngl`境界探索、MTP speculative decodingは重要なsystem experimentだがcanonical Core/Challenge quality runには混ぜない。
