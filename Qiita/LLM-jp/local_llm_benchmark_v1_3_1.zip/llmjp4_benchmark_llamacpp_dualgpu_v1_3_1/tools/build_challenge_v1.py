#!/usr/bin/env python3
from __future__ import annotations

import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "datasets" / "challenge_v1.1.0.jsonl"

NUMERIC_SUFFIX = (
    "\n計算過程は内部で行い、最終出力は `最終回答: 数値` の1行だけにしてください。"
    "特に指定がない限り有効数字4桁以上で答えてください。"
)
CHOICE_SUFFIX = "\n回答は選択肢の英字1文字だけを出力してください。"
CODE_SUFFIX = (
    "\n説明文は不要で、Pythonコードだけを出力してください。"
    " importを使う場合は math, statistics, itertools, collections, functools, heapq, bisect, operator, re, typing, __future__ のみ使用可能です。"
)

HALLUCINATION_GLOSSARY = """

分類ラベルの意味は次の通りです。
- status=supported: 与えられた情報だけで要求された主張を支持できる。
- status=partial: 関連する事実は支持されるが、要求された具体的主張までは支持できない。
- status=insufficient_information: 要求された値・事実を一意または検証可能に確定する情報が不足している。
- status=invalid_inference: 与えられた事実から要求された結論へ進む推論自体が不正。
- reason=source_not_provided: 検証対象を裏付ける一次資料・参照資料そのものがない。
- reason=missing_claim_evidence: 周辺事実はあるが、問われた具体的主張を裏付ける証拠がない。
- reason=correlation_not_causation: 相関・観察から因果を断定している。
- reason=non_unique: 条件を満たす答えが複数存在し、一意に定まらない。
- reason=unverified_attribution: 引用・発言・著者帰属を検証できない。
- reason=inconsistent_evidence: 同等の根拠が互いに矛盾している。
- reason=missing_base_rate: 条件付き確率に必要な事前確率・有病率がない。
- reason=unsupported_extrapolation: 観測範囲を大きく外れた外挿を正当化するモデルがない。
"""

rows: list[dict] = []


def add_choice(id: str, category: str, prompt: str, expected: str, tags: list[str] | None = None):
    rows.append({
        "id": id, "category": category, "difficulty": "challenge",
        "prompt": prompt + CHOICE_SUFFIX,
        "grader": {"type": "choice", "expected": expected, "choices": ["A", "B", "C", "D"]},
        "tags": tags or [], "reasoning_effort_eval": False,
        "metadata": {"track": "challenge", "dataset_version": "1.1.0"},
    })


def add_numeric(id: str, category: str, prompt: str, expected: float, *, atol: float = 1e-6, rtol: float = 5e-4, tags: list[str] | None = None):
    rows.append({
        "id": id, "category": category, "difficulty": "challenge",
        "prompt": prompt + NUMERIC_SUFFIX,
        "grader": {"type": "numeric", "expected": float(expected), "atol": atol, "rtol": rtol},
        "tags": tags or [], "reasoning_effort_eval": False,
        "metadata": {"track": "challenge", "dataset_version": "1.1.0"},
    })


def add_code(id: str, prompt: str, entrypoint: str, tests: list[dict], tags: list[str] | None = None):
    rows.append({
        "id": id, "category": "coding", "difficulty": "challenge",
        "prompt": prompt + CODE_SUFFIX,
        "grader": {"type": "python_unit_test", "entrypoint": entrypoint, "tests": tests, "timeout_s": 5},
        "tags": tags or [], "reasoning_effort_eval": False,
        "metadata": {"track": "challenge", "dataset_version": "1.1.0"},
    })


def add_json(id: str, category: str, prompt: str, expected: dict, tags: list[str] | None = None):
    if category == "hallucination_resistance" and "分類ラベルの意味" not in prompt:
        marker = "\n外部検索は禁止。"
        prompt = prompt.replace(marker, HALLUCINATION_GLOSSARY + marker, 1) if marker in prompt else prompt + HALLUCINATION_GLOSSARY
    rows.append({
        "id": id, "category": category, "difficulty": "challenge",
        "prompt": prompt,
        "grader": {"type": "json_exact", "expected": expected},
        "tags": tags or [], "reasoning_effort_eval": False,
        "metadata": {"track": "challenge", "dataset_version": "1.1.0"},
    })

# ---------------------------------------------------------------------------
# 1. Advanced Japanese comprehension: scope, counterfactuals, causality, argument structure
# ---------------------------------------------------------------------------
add_choice("CJP01", "advanced_japanese", """
ある企業は「問い合わせへの平均応答時間」を主要KPIにしたところ、平均値は大幅に改善した。しかし、担当者が難しい案件を別窓口へ移す行動が増え、解決までの総時間はほぼ変わらなかった。経営陣は、KPI改善をもって顧客対応能力が向上したと結論した。監査担当者は、この結論には追加の検証が必要だと述べた。
監査担当者の懸念を最も正確に表すものはどれか。
A. KPIは測定誤差を含むため、平均値を一切使うべきでない。
B. 指標への最適化が対象業務の実質的改善を表さない可能性がある。
C. 難しい案件は統計分析から常に除外すべきである。
D. 平均値ではなく中央値を使えば必ず問題が解消する。
""", "B", ["Goodhart", "measurement"])

add_choice("CJP02", "advanced_japanese", """
「新制度導入後に離職率が下がった。ただし同時期に景気が悪化し、転職市場全体も縮小している。したがって、新制度に離職抑制効果がなかったとは言えないが、観測された低下の全てを制度に帰属させることもできない。」
この記述が最も強く支持するものはどれか。
A. 新制度の因果効果はゼロである。
B. 景気悪化は新制度の効果を必ず過小評価する。
C. 適切な反実仮想がなければ制度の因果効果を観測差だけから同定できない。
D. 離職率は景気と無関係なので制度効果を直接読める。
""", "C", ["counterfactual", "causality"])

add_choice("CJP03", "advanced_japanese", """
規程には「機密資料は原則として社外持出し禁止。ただし、部門長が必要性を認め、かつ情報管理責任者が安全措置を確認した場合に限り例外を認める」とある。ある社員は部門長の承認のみを得て資料を持ち出した。
規程の文言だけから最も妥当な評価はどれか。
A. 「原則」なので部門長承認だけで例外になる。
B. 二つの条件は選言的なのでどちらか一方でよい。
C. 例外要件は累積的であり、情報管理責任者の確認がないため要件を満たさない。
D. 社員の目的が正当なら文言上の要件は不要である。
""", "C", ["scope", "necessary_conditions"])

add_choice("CJP04", "advanced_japanese", """
「調査で不正の証拠が見つからなかった」という報告に対し、委員Aは「したがって不正は存在しなかった」と述べ、委員Bは「調査感度が十分高かったかを確認しない限り、その結論は強すぎる」と反論した。
委員Bの論点として最も適切なのはどれか。
A. 証拠がないことは、検出能力に依存せず不在の証拠になる。
B. 陰性結果の証拠価値は、存在した場合に検出できる確率に依存する。
C. 不正の有無は統計的に検討できない。
D. 調査で一つでも証拠が見つかれば必ず全ての不正が証明される。
""", "B", ["absence_of_evidence", "bayesian_reasoning"])

add_choice("CJP05", "advanced_japanese", """
「研修参加者は非参加者より成績が高かった。参加者はもともと学習意欲が高い傾向もあった。意欲を統制すると差は小さくなったが残った。したがって、研修には効果がある」とする報告がある。
この報告について最も慎重で妥当な評価はどれか。
A. 意欲を統制したので未観測交絡は存在しないことが証明された。
B. 差が残ったため研修効果は必ず因果的である。
C. 観測された意欲による交絡は一部説明されたが、残差交絡の可能性は残る。
D. 統制後に差が小さくなったので研修は逆効果である。
""", "C", ["confounding", "causal_inference"])

add_choice("CJP06", "advanced_japanese", """
ある臨床研究は重症患者を除外して治療効果を高精度に推定した。研究者は「内部妥当性は高い」と述べた一方、「実診療の全患者に同じ効果があるとは限らない」と付記した。
後半の留保が主に指している問題はどれか。
A. 測定尺度の信頼性
B. 外的妥当性・対象集団への一般化可能性
C. 帰無仮説の設定
D. 多重比較補正
""", "B", ["external_validity"])

add_choice("CJP07", "advanced_japanese", """
「透明性は信頼の必要条件である。しかし透明性が高い組織が常に信頼されるわけではない。透明に公開された情報そのものが重大な失敗を示すこともある。」
この段落と論理的に両立するものはどれか。
A. 透明性があれば信頼は必ず生じる。
B. 信頼があれば透明性は不要である。
C. 透明性が欠ければ信頼成立に必要な条件を欠くが、透明性だけでは信頼を保証しない。
D. 透明性と信頼には何の関係もない。
""", "C", ["necessary_sufficient"])

add_choice("CJP08", "advanced_japanese", """
政策評価報告は「導入地域では犯罪件数が減少したが、非導入地域でも同程度に減少した」と述べている。その直後に「導入地域の減少だけを根拠に政策成功を主張することはできない」と結論している。
この結論の推論上の中心はどれか。
A. 導入地域の事前値だけを比較すべきだという主張
B. 同時期の共通変化を差し引く比較対照の必要性
C. 犯罪件数は政策評価に使用できないという主張
D. 非導入地域のデータは常にバイアスを生むという主張
""", "B", ["difference_in_differences", "comparison_group"])

# ---------------------------------------------------------------------------
# 2. Analytical reasoning
# ---------------------------------------------------------------------------
p = 0.12 * 0.90 * 0.85
q = 0.88 * 0.08 * 0.20
add_numeric("CAR01", "analytical_reasoning", """
疾患Dの事前確率は0.12。第1検査の感度0.90、偽陽性率0.08。第1検査が陽性だった条件下で、第2検査の陽性確率はDありなら0.85、Dなしなら0.20である（第2検査は第1検査と条件付き独立とは仮定しない）。2回とも陽性だったときP(D|++)を求めよ。
""", p/(p+q), tags=["bayes", "dependent_tests"])

add_numeric("CAR02", "analytical_reasoning", """
2台の同一並列機械で非プリエンプティブに処理する。処理時間はA=3, B=2, C=4, D=3, E=2。先行制約はA→C, A→D, B→D, C→E, D→E。時刻0から開始するとき最小メイクスパンを求めよ。
""", 9.0, tags=["scheduling", "precedence"])

add_choice("CAR03", "analytical_reasoning", """
治療A/Bの成功数が次の通りだった。軽症: A 81/90, B 234/270。重症: A 192/263, B 55/80。全体ではAの成功率がBより高いが、軽症・重症の各層ではBの成功率がAより高い。
この現象の説明として最も適切なのはどれか。
A. 各層の比較と全体比較の方向が交絡する層構成比によって反転するSimpsonのパラドックス
B. 標本数が異なると成功率の比較は数学的に不可能になる
C. 全体成功率だけが因果効果を必ず表す
D. 層別成功率が異なる場合はデータ入力ミスである
""", "A", ["Simpson_paradox"])

add_numeric("CAR04", "analytical_reasoning", """
2部品A,Bからなる直列システムがある。確率0.02で共通ショックが起き、その場合は必ずシステム故障。ショックが起きない場合、Aの故障確率0.05、Bの故障確率0.10で両者は独立。システム故障確率を求めよ。
""", 1 - 0.98 * 0.95 * 0.90, tags=["reliability", "common_cause"])

add_numeric("CAR05", "analytical_reasoning", """
状態Good/Badの確率は0.4/0.6。行動Aの利得は(100,0)、行動Bは(60,50)。状態を知らずに最適行動を選ぶ場合と、完全情報を得てから最適行動を選べる場合を比較し、完全情報の期待価値EVPIを求めよ。
""", 16.0, tags=["decision_theory", "EVPI"])

add_choice("CAR06", "analytical_reasoning", """
DAGは Z→X, Z→Y, X→M→Y, X→Y である。XのYに対する総因果効果をバックドア調整で推定したい。最も適切な調整集合はどれか。
A. {Z}
B. {M}
C. {Z,M}
D. 空集合
""", "A", ["causal_graph", "backdoor"])

add_choice("CAR07", "analytical_reasoning", """
3状態S1,S2,S3に対する3行動の損失が A=(2,8,4), B=(5,4,6), C=(9,1,3) である。状態確率は不明で、minimax regret基準を使う。選ぶべき行動はどれか。
A. A
B. B
C. C
D. AとCが同率
""", "B", ["minimax_regret"])

add_numeric("CAR08", "analytical_reasoning", """
箱Aには赤2青1、箱Bには赤1青2の球が入り、箱は等確率で選ばれる。1個目を無作為に引いて赤だった。戻さずに2個目を引くとき、2個目も赤である条件付き確率を求めよ。
""", 1/3, tags=["bayes", "without_replacement"])

# ---------------------------------------------------------------------------
# 3. Mathematics / statistics
# ---------------------------------------------------------------------------
add_numeric("CMS01", "mathematics_statistics", """
マルコフ連鎖の遷移行列が P=[[0.5,0.5,0],[0.25,0.5,0.25],[0,0.5,0.5]] である。定常分布π=(π1,π2,π3)のπ2を求めよ。
""", 0.5, tags=["markov_chain", "stationary_distribution"])

add_numeric("CMS02", "mathematics_statistics", """
Var(X)=4, Var(Y)=9, Cov(X,Y)=3 とする。Z=2X-Y の分散Var(Z)を求めよ。
""", 13.0, tags=["covariance", "linear_transform"])

add_numeric("CMS03", "mathematics_statistics", """
Bernoulli成功確率pに事前分布Beta(2,3)を置く。10回観測して成功7、失敗3だった。事後分布の下で、次の2試行が両方成功する事後予測確率を求めよ。
""", (9/15)*(10/16), tags=["bayesian_statistics", "posterior_predictive"])

# CRT solution
crt = next(n for n in range(1, 5*7*9+1) if n % 5 == 2 and n % 7 == 3 and n % 9 == 4)
add_numeric("CMS04", "mathematics_statistics", """
正の整数nが n≡2 (mod 5), n≡3 (mod 7), n≡4 (mod 9) を同時に満たす。最小のnを求めよ。
""", float(crt), tags=["number_theory", "CRT"])

add_numeric("CMS05", "mathematics_statistics", """
x,y,z>0 かつ x+2y+3z=12 の制約下で xyz の最大値を求めよ。
""", 32/3, tags=["optimization", "lagrange_multiplier"])

# Hypergeometric conditional probability: draw 3 from 5 red 4 blue, given at least 1 blue, prob exactly 2 red (= 2R1B)
num = math.comb(5,2)*math.comb(4,1)
den = math.comb(9,3)-math.comb(5,3)
add_numeric("CMS06", "mathematics_statistics", """
赤5個・青4個から同時に3個を無作為抽出する。「少なくとも青1個を含む」という条件の下で、赤がちょうど2個である条件付き確率を求めよ。
""", num/den, tags=["conditional_probability", "hypergeometric"])

add_choice("CMS07", "mathematics_statistics", """
実対称行列Aについて正しいものを1つ選べ。
A. 固有値は必ず正である。
B. 異なる固有値に属する固有ベクトルは直交する。
C. Aが特異なら固有ベクトルを持たない。
D. Aの固有値は一般に複素共役対になるが実数とは限らない。
""", "B", ["linear_algebra", "spectral_theorem"])

add_numeric("CMS08", "mathematics_statistics", """
2人零和ゲームで行プレイヤーの利得行列が [[3,0],[0,2]]。混合戦略均衡で第1行を選ぶ確率pを求めよ。
""", 0.4, tags=["game_theory", "mixed_equilibrium"])

# ---------------------------------------------------------------------------
# 4. Coding
# ---------------------------------------------------------------------------
add_code("CCD01", """
関数 `shortest_path_one_free_edge(n: int, edges: list[list[int]], s: int, t: int) -> int` を実装せよ。0..n-1の無向グラフで各辺は[u,v,w]、w>=0。経路上で高々1本だけ辺コストを0としてよい。sからtへの最小コストを返し、到達不能なら-1。
""", "shortest_path_one_free_edge", [
    {"args": [4, [[0,1,5],[1,3,5],[0,2,2],[2,3,10]], 0, 3], "expected": 2},
    {"args": [3, [[0,1,7],[1,2,4]], 0, 2], "expected": 4},
    {"args": [3, [[0,1,1]], 0, 2], "expected": -1},
    {"args": [1, [], 0, 0], "expected": 0},
], ["dijkstra", "state_graph"])

add_code("CCD02", """
関数 `weighted_interval_schedule(intervals: list[list[int]]) -> int` を実装せよ。各要素は[start,end,weight]でstart<end。2区間は前者のend<=後者のstartなら両方選べる。互いに重ならない区間集合のweight合計最大値を返せ。入力順は任意。
""", "weighted_interval_schedule", [
    {"args": [[[1,3,5],[2,5,6],[4,6,5],[6,7,4],[5,8,11],[7,9,2]]], "expected": 17},
    {"args": [[[1,2,5],[2,3,6],[3,4,7]]], "expected": 18},
    {"args": [[]], "expected": 0},
    {"args": [[[0,10,100],[0,3,40],[3,6,40],[6,10,40]]], "expected": 120},
], ["dynamic_programming", "binary_search"])

add_code("CCD03", """
関数 `min_window(s: str, t: str) -> str` を実装せよ。s中の部分文字列で、tの各文字を重複度込みで全て含む最短のものを返す。同じ最短長が複数なら開始位置が最小のもの。存在しなければ空文字列。
""", "min_window", [
    {"args": ["ADOBECODEBANC", "ABC"], "expected": "BANC"},
    {"args": ["aaabdabcefaecbef", "abc"], "expected": "abc"},
    {"args": ["a", "aa"], "expected": ""},
    {"args": ["bbaa", "aba"], "expected": "baa"},
], ["sliding_window", "multiset"])

add_code("CCD04", """
関数 `decode_brackets(s: str) -> str` を実装せよ。入力は非負ではなく正の整数kと角括弧からなる形式 `k[substring]` を含み、入れ子と複数桁kを許す。例 `3[a2[c]] -> accaccacc`。入力は妥当と仮定する。
""", "decode_brackets", [
    {"args": ["3[a2[c]]"], "expected": "accaccacc"},
    {"args": ["2[abc]3[cd]ef"], "expected": "abcabccdcdcdef"},
    {"args": ["10[x]"], "expected": "xxxxxxxxxx"},
    {"args": ["2[a3[b2[c]]]"], "expected": "abccbccbccabccbccbcc"},
], ["parsing", "stack"])

add_code("CCD05", """
関数 `count_islands_after_additions(m: int, n: int, positions: list[list[int]]) -> list[int]` を実装せよ。初期は全て水のm×n格子。各[r,c]を順に陸へ変えた直後の4近傍連結な島数を返す。同じ位置が再度指定された場合は状態を変えない。
""", "count_islands_after_additions", [
    {"args": [3,3,[[0,0],[0,1],[1,2],[2,1],[1,1]]], "expected": [1,1,2,3,1]},
    {"args": [1,2,[[0,0],[0,0],[0,1]]], "expected": [1,1,1]},
    {"args": [2,2,[[0,0],[1,1],[0,1],[1,0]]], "expected": [1,2,1,1]},
], ["union_find", "dynamic_connectivity"])

add_code("CCD06", """
関数 `kth_smallest_pair_distance(nums: list[int], k: int) -> int` を実装せよ。i<jの全組について|nums[i]-nums[j]|を考え、小さい順でk番目（1-indexed）を返す。
""", "kth_smallest_pair_distance", [
    {"args": [[1,3,1], 1], "expected": 0},
    {"args": [[1,6,1], 3], "expected": 5},
    {"args": [[0,2,4,7], 4], "expected": 4},
    {"args": [[5,5,5,5], 6], "expected": 0},
], ["binary_search", "two_pointers"])

add_code("CCD07", """
関数 `min_cost_grid(grid: list[list[int]]) -> int` を実装せよ。左上から右下へ上下左右に移動でき、セルに入るたびそのセル値をコストとして支払う。開始セルの値も支払う。全値は非負。最小総コストを返せ。
""", "min_cost_grid", [
    {"args": [[[1,9,1],[1,9,1],[1,1,1]]], "expected": 5},
    {"args": [[[7]]], "expected": 7},
    {"args": [[[1,2,3],[4,8,2],[1,5,3]]], "expected": 11},
    {"args": [[[0,100,0],[0,100,0],[0,0,0]]], "expected": 0},
], ["dijkstra", "grid"])

add_code("CCD08", """
関数 `longest_subarray_limit(nums: list[int], limit: int) -> int` を実装せよ。連続部分配列の最大値と最小値の差がlimit以下となる部分配列の最大長を返す。numsは空でもよい。
""", "longest_subarray_limit", [
    {"args": [[8,2,4,7],4], "expected": 2},
    {"args": [[10,1,2,4,7,2],5], "expected": 4},
    {"args": [[4,2,2,2,4,4,2,2],0], "expected": 3},
    {"args": [[],3], "expected": 0},
], ["monotonic_queue", "sliding_window"])

# ---------------------------------------------------------------------------
# 5. Physics / engineering
# ---------------------------------------------------------------------------
# two-stage RC
v10 = 10 * (1 - math.exp(-10e-3/10e-3))
v30 = 4 + (v10 - 4) * math.exp(-20e-3/20e-3)
add_numeric("CPH01", "physics_engineering", """
コンデンサ電圧は初期0V。0<=t<10msでは10V電源に接続され時定数10msで充電される。t=10msで回路を切替え、以後は4Vへ時定数20msで指数緩和する。電圧は切替時に連続とする。t=30msでの電圧[V]を求めよ。
""", v30, tags=["RC_transient", "piecewise_system"])

add_numeric("CPH02", "physics_engineering", """
定常サイクル装置が600Kの熱源から1200Jを受け取り、300Kの熱浴へ800Jを捨て、残りを仕事として出す。熱源・熱浴を含む全体系の1サイクルあたりエントロピー生成量[J/K]を求めよ。
""", -1200/600 + 800/300, tags=["thermodynamics", "entropy_generation"])

add_numeric("CPH03", "physics_engineering", """
同じ静止質量mの粒子2個が一次元で完全非弾性衝突する。一方は実験室系で速度0.8c、他方は静止している。衝突後の複合系の速度をc単位で求めよ（放射なし）。
""", 0.5, tags=["relativity", "four_momentum"])

add_numeric("CPH04", "physics_engineering", """
直列RLC回路でR=20Ω, L=50mH, C=100µF、角周波数ω=200rad/s。力率の絶対値 |cosφ| を求めよ。
""", 20/math.sqrt(20**2 + (200*0.05 - 1/(200*100e-6))**2), tags=["AC_circuit", "power_factor"])

# composite thermal resistance; A=0.02m2, layers 0.02/0.5 and .01/.2, h1=10,h2=25, deltaT=60
Rth = 1/(10*0.02) + 0.02/(0.5*0.02) + 0.01/(0.2*0.02) + 1/(25*0.02)
add_numeric("CPH05", "physics_engineering", """
面積0.020m^2の平板を通る定常一次元熱伝導。高温側対流h1=10W/m^2K、層1は厚さ0.020m,k=0.50、層2は厚さ0.010m,k=0.20、低温側対流h2=25。両側流体温度差60K、接触熱抵抗なし。熱流量[W]を求めよ。
""", 60/Rth, tags=["heat_transfer", "thermal_resistance"])

# reflection coefficient magnitude
zl = complex(100,-50); z0=50
add_numeric("CPH06", "physics_engineering", """
特性インピーダンスZ0=50Ωの損失なし伝送線路に負荷ZL=100-j50Ωを接続した。負荷での電圧反射係数Γ=(ZL-Z0)/(ZL+Z0)の絶対値|Γ|を求めよ。
""", abs((zl-z0)/(zl+z0)), tags=["transmission_line"])

add_choice("CPH07", "physics_engineering", """
連続時間LTI系の特性多項式が s^3+2s^2+s+2 である。安定性について正しいものはどれか。
A. 全極が左半平面にあり漸近安定
B. 右半平面極を1個持つ
C. 虚軸上の極を持ち漸近安定ではない
D. 原点に3重極を持つ
""", "C", ["control", "stability"])

add_choice("CPH08", "physics_engineering", """
理想的な無散逸LC回路で、初期にコンデンサだけが帯電し電流は0とする。四分の一周期後に正しいものはどれか。
A. エネルギーは全て抵抗熱になっている
B. コンデンサ電圧は最大で電流は0
C. コンデンサの電場エネルギーが最小となり、インダクタの磁場エネルギーが最大となる
D. 総エネルギーは初期値の半分になる
""", "C", ["LC_oscillation", "energy"])

# ---------------------------------------------------------------------------
# 6. Chemistry / materials
# ---------------------------------------------------------------------------
H=1e-5; ka1=1e-4; ka2=1e-6
alpha_ha = ka1*H/(H*H + ka1*H + ka1*ka2)
add_numeric("CCH01", "chemistry_materials", """
二塩基酸H2AのpKa1=4.00, pKa2=6.00。活量係数を1としpH=5.00のとき、全酸濃度に対するHA^-のモル分率を求めよ。
""", alpha_ha, tags=["acid_base", "speciation"])

add_numeric("CCH02", "chemistry_materials", """
逐次一次反応 A→B→C で k1=0.20 min^-1, k2=0.050 min^-1、初期はAのみ。B濃度が最大となる時刻[min]を求めよ。
""", math.log(0.20/0.05)/(0.20-0.05), tags=["kinetics", "consecutive_reaction"])

add_numeric("CCH03", "chemistry_materials", """
A,Bが同一サイトへ競争Langmuir吸着する。KA=2.0 bar^-1, KB=5.0 bar^-1, PA=0.30bar, PB=0.10bar。θA=KAPA/(1+KAPA+KBPB)としてAの被覆率を求めよ。
""", 0.6/2.1, tags=["surface_chemistry", "Langmuir"])

R=8.314; T=298.0; F=96485.0; eta=0.120; i0=2.0
x=0.5*F*eta/(R*T)
add_numeric("CCH04", "chemistry_materials", """
298K、対称係数α=0.5、交換電流密度i0=2.0mA/cm^2の電極反応を考える。濃度過電圧を無視し、Butler-Volmer式 i=i0[exp(αFη/RT)-exp(-(1-α)Fη/RT)] を用いる。η=0.120Vでの電流密度[mA/cm^2]を求めよ。R=8.314,F=96485。
""", i0*(math.exp(x)-math.exp(-x)), tags=["electrochemistry", "Butler_Volmer"])

lam=0.154 # nm
a=0.400
d=a/math.sqrt(3)
twotheta=2*math.degrees(math.asin(lam/(2*d)))
add_numeric("CCH05", "chemistry_materials", """
立方晶で格子定数a=0.400nm。Cu Kαをλ=0.154nmとし、(111)面の1次Bragg反射について2θ[deg]を求めよ。d111=a/sqrt(3)、2d sinθ=λを用いる。
""", twotheta, atol=1e-3, tags=["crystallography", "XRD"])

kB=8.617333262e-5
add_numeric("CCH06", "chemistry_materials", """
Schottky欠陥対の形成エネルギーが2.00eVで、単純化して各副格子の空孔分率x≈exp[-Ef/(2kBT)]とする。T=1000Kでxを求めよ。kB=8.617333262×10^-5 eV/K。
""", math.exp(-2.0/(2*kB*1000)), atol=1e-9, tags=["defects", "thermodynamics"])

add_choice("CCH07", "chemistry_materials", """
表面反応で速度式が r=k KA PA/(1+KAPA+KBPB)^2 と観測された。PAを十分大きくしてKAPAが他項より支配的な極限で、PAに対する見かけ反応次数はどれか。
A. +1
B. 0
C. -1
D. -2
""", "C", ["surface_kinetics", "asymptotic_order"])

add_numeric("CCH08", "chemistry_materials", """
二相領域でα相組成xα=0.20、β相組成xβ=0.80、全組成x0=0.35。レバー則でβ相のモル分率を求めよ。
""", 0.25, tags=["phase_diagram", "lever_rule"])

# ---------------------------------------------------------------------------
# 7. Life science / information science
# ---------------------------------------------------------------------------
add_numeric("CLI01", "life_information", """
ある遺伝的保因者の事前確率は0.020。保因者検査の感度0.90、特異度0.95。検査が陰性だったときの保因者事後確率を求めよ。
""", 0.02*0.10/(0.02*0.10 + 0.98*0.95), tags=["genetic_testing", "bayes"])

add_numeric("CLI02", "life_information", """
Hardy-Weinberg集団で対立遺伝子aの頻度q=0.20。選択前の適応度をAA=1, Aa=1, aa=0.5とする。1世代の viability selection 後、繁殖個体群におけるaの頻度q'を求めよ（ランダム交配前）。
""", (0.5*(2*0.8*0.2)*1 + (0.2**2)*0.5)/(0.8**2 + 2*0.8*0.2 + 0.2**2*0.5), tags=["population_genetics", "selection"])

# qPCR relative initial template with same threshold: N0A/N0B = E_B^CtB/E_A^CtA
add_numeric("CLI03", "life_information", """
同一蛍光閾値を用いるqPCRで、試料Aの1cycle当たり増幅倍率EA=1.90, CtA=20、試料BはEB=2.00, CtB=22。閾値到達量が同一として、初期鋳型量比N0,A/N0,Bを求めよ。
""", (2.0**22)/(1.9**20), tags=["qPCR", "exponential_growth"])

p_err=0.1
H2=-(p_err*math.log2(p_err)+(1-p_err)*math.log2(1-p_err))
add_numeric("CLI04", "life_information", """
入力0/1が等確率のbinary symmetric channelでビット反転確率p=0.10。1使用あたりの相互情報量I(X;Y)[bit]を求めよ。
""", 1-H2, tags=["information_theory", "mutual_information"])

m=10000;n=1000;k=7
add_numeric("CLI05", "life_information", """
Bloom filterでビット数m=10000、挿入要素数n=1000、独立ハッシュ数k=7。標準近似 p_fp=(1-exp(-kn/m))^k による偽陽性率を求めよ。
""", (1-math.exp(-k*n/m))**k, tags=["data_structures", "bloom_filter"])

add_numeric("CLI06", "life_information", """
混合阻害の単純速度式 v=Vmax[S]/(αKm+α'[S]) を用いる。Vmax=120, Km=5, [S]=10, [I]=4, Ki=2, Ki'=4。α=1+[I]/Ki, α'=1+[I]/Ki'としてvを求めよ。
""", 120*10/((1+4/2)*5 + (1+4/4)*10), tags=["enzyme_kinetics", "mixed_inhibition"])

# Poisson branching extinction q=e^{R(q-1)} nontrivial root
R0=1.5
qext=0.4
for _ in range(100):
    qext=math.exp(R0*(qext-1))
add_numeric("CLI07", "life_information", """
Galton-Watson分枝過程で1個体あたり子孫数が平均1.5のPoisson分布に従う。絶滅確率qはq=exp(1.5(q-1))の[0,1)にある非自明解である。qを数値で求めよ。
""", qext, atol=1e-5, tags=["branching_process", "fixed_point"])

add_choice("CLI08", "life_information", """
GWASで祖先集団構造が疾患頻度とアレル頻度の双方に関連しているのに補正しなかった。最も直接的に懸念されるものはどれか。
A. population stratificationによる偽関連
B. PCR増幅効率が必ず2倍になる
C. Mendel分離比そのものが破れる
D. 連鎖不平衡が全ゲノムで消失する
""", "A", ["GWAS", "confounding"])

# ---------------------------------------------------------------------------
# 8. Humanities / social science / economics
# ---------------------------------------------------------------------------
add_numeric("CHS01", "humanities_social_economics", """
Difference-in-Differences。処置群の平均アウトカムは介入前50、介入後62。対照群は介入前45、介入後53。平行トレンドを仮定したDiD推定量を求めよ。
""", 4.0, tags=["econometrics", "DiD"])

add_choice("CHS02", "humanities_social_economics", """
二値操作変数Zについて独立性・排除制約・単調性が成立し、treatment uptakeにcomplier/always-taker/never-takerがいる。Wald推定量が識別する効果として最も適切なのはどれか。
A. 全母集団のATEを常に識別する
B. compliersに対する局所平均処置効果LATE
C. always-takersだけの効果
D. 処置を受けた全員のATTを必ず識別する
""", "B", ["instrumental_variable", "LATE"])

add_numeric("CHS03", "humanities_social_economics", """
同質財Cournot複占。逆需要P=100-Q、各企業の限界費用は一定20、固定費0。対称Nash均衡での市場総生産量Qを求めよ。
""", 160/3, tags=["microeconomics", "Cournot"])

add_numeric("CHS04", "humanities_social_economics", """
額面100、年1回クーポン5、残存2年の債券を考える。満期利回り4%（年複利）のとき理論価格を求めよ。
""", 5/1.04 + 105/(1.04**2), tags=["finance", "bond_pricing"])

add_choice("CHS05", "humanities_social_economics", """
3有権者の選好が 1:A>B>C, 2:B>C>A, 3:C>A>B である。単純多数決のペア比較について正しいものはどれか。
A. AがB,Cの両方に勝つCondorcet winner
B. BがA,Cの両方に勝つCondorcet winner
C. A>B, B>C, C>Aという多数決循環が生じる
D. 全てのペアが同数になる
""", "C", ["social_choice", "Condorcet_cycle"])

add_choice("CHS06", "humanities_social_economics", """
ある倫理原則Pについて「Pを守ることは正当な行為であるために必要だが十分ではない」とする立場と論理的に両立するものはどれか。
A. Pを守れば他の条件に関係なく必ず正当である。
B. 正当な行為はPを守るが、Pを守る不正当な行為もあり得る。
C. Pを守らない正当な行為が必ず存在する。
D. Pと正当性には論理的関係がない。
""", "B", ["ethics", "necessary_sufficient"])

add_choice("CHS07", "humanities_social_economics", """
会話で「何人かの学生は合格した」と発話したとき、文脈上特別な事情がなければ「全員が合格したわけではない」という含意が生じやすい。しかし話者が「実際には全員だった」と続けても論理矛盾にはならない。この性質の説明として最も適切なのはどれか。
A. 「何人か」は論理的に「全員ではない」を含意する
B. 「全員ではない」は取消可能な尺度含意である
C. 「何人か」は常に0人を意味する
D. これは統語的性一致の現象である
""", "B", ["linguistics", "scalar_implicature"])

add_choice("CHS08", "humanities_social_economics", """
歴史家が政策決定者の日記1冊だけから「国民全体が政策を支持していた」と推論した。最も直接的な方法論上の問題はどれか。
A. 一次史料は二次史料より常に信頼できない
B. 個人の記録から母集団全体の態度へ一般化する根拠が不足している
C. 日記は年代測定できないため史料にならない
D. 政策決定者の記録は必ず虚偽である
""", "B", ["historical_method", "generalization"])

# ---------------------------------------------------------------------------
# 9. Hallucination / epistemic discipline
# ---------------------------------------------------------------------------
HALL_SCHEMA = (
    "\n外部検索は禁止。次のJSONだけを出力してください。キーは `status`, `reason` の2つだけ。"
    " `status` は `supported`, `partial`, `insufficient_information`, `invalid_inference` のいずれか。"
    " `reason` は `source_not_provided`, `missing_claim_evidence`, `correlation_not_causation`, `non_unique`,"
    " `unverified_attribution`, `inconsistent_evidence`, `missing_base_rate`, `unsupported_extrapolation` のいずれか。"
)
add_json("CHL01", "hallucination_resistance", """
DOI `10.9999/abc.2099.77` の論文の著者、掲載誌、ページを正確に答えるよう求められたが、この質問文以外に資料はない。捏造せず状況を分類せよ。
""" + HALL_SCHEMA, {"status":"insufficient_information","reason":"source_not_provided"}, ["source_grounding"])

add_json("CHL02", "hallucination_resistance", """
与えられた抄録には「触媒Xで収率が42%から71%へ上昇した」とだけ書かれている。質問は「Xが遷移状態の電荷分離を安定化したことが収率向上の原因か」と断定を求めている。抄録には機構解析の記述はない。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"partial","reason":"missing_claim_evidence"}, ["mechanistic_claim"])

add_json("CHL03", "hallucination_resistance", """
観察研究でコーヒー摂取量と試験点数に正の相関があった。交絡調整や介入は行われていない。「コーヒーを増やせば点数が上がる」と結論してよいかを分類せよ。
""" + HALL_SCHEMA, {"status":"invalid_inference","reason":"correlation_not_causation"}, ["causal_overclaim"])

add_json("CHL04", "hallucination_resistance", """
x+y=10 という情報だけからxの数値を一意に答えるよう求められた。x,yは実数で追加条件はない。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"insufficient_information","reason":"non_unique"}, ["underdetermined"])

add_json("CHL05", "hallucination_resistance", """
「Einsteinが1931年の京都講演で『量子計算は21世紀の錬金術になる』と述べた」という引用の真偽を、この質問文だけを根拠に断定するよう求められた。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"insufficient_information","reason":"unverified_attribution"}, ["quotation_attribution"])

add_json("CHL06", "hallucination_resistance", """
同じ試料の濃度について、同一条件の一次資料Aは「2.0±0.1 M」、一次資料Bは「5.0±0.1 M」と報告し、どちらを優先すべきかの情報はない。「真の濃度を4桁で答えよ」と求められた。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"insufficient_information","reason":"inconsistent_evidence"}, ["conflicting_sources"])

add_json("CHL07", "hallucination_resistance", """
検査の感度99%、特異度99%だけが与えられ、「陽性者が本当に疾患を持つ確率」を数値で答えるよう求められた。対象集団の有病率は与えられていない。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"insufficient_information","reason":"missing_base_rate"}, ["base_rate"])

add_json("CHL08", "hallucination_resistance", """
材料強度が温度300,350,400Kでそれぞれ100,96,91MPaと測定された。この3点だけから1000Kでの強度を高精度に断定するよう求められ、物理モデルも相転移情報もない。状況を分類せよ。
""" + HALL_SCHEMA, {"status":"invalid_inference","reason":"unsupported_extrapolation"}, ["extrapolation"])

# ---------------------------------------------------------------------------
# 10. Instruction following: multiple simultaneous constraints, exact JSON
# ---------------------------------------------------------------------------
add_json("CIF01", "instruction_following", """
記録は A:(score=8,group=x), B:(6,y), C:(8,y), D:(9,x), E:(6,y)。score>=7だけ残し、score降順・同点はID昇順で並べる。`ids`にID配列、`scores`に対応するscore配列、`count`に件数を入れよ。キー順はids,scores,count。説明なしのJSONだけを出力せよ。
""", {"ids":["D","A","C"],"scores":[9,8,8],"count":3}, ["filter", "stable_constraints"])

add_json("CIF02", "instruction_following", """
直接依存関係: A:なし, B:A, C:A, D:BとC, E:C, F:DとE。タスクFを実行するために必要なF以外の全祖先タスクを重複なく辞書順に並べ、`ancestors`へ入れる。`count`も入れる。説明なしのJSONだけを出力せよ。
""", {"ancestors":["A","B","C","D","E"],"count":5}, ["dependency", "transitive_closure"])

add_json("CIF03", "instruction_following", """
閉区間[0,20]から、禁止区間[2,5], [4,8], [12,15], [15,17]を除く。禁止区間は重なり・接触を結合してから除き、残る区間を端点共有なしの実数区間として `allowed` に [[start,end],...] の形で昇順格納せよ。境界0,20は含め、禁止区間の端点は除外されるため、ここでは区間端点の開閉情報を `open_left`,`open_right` の真偽配列で別に表現する。出力キーはallowed,open_left,open_right。説明なしのJSONだけ。
""", {"allowed":[[0,2],[8,12],[17,20]],"open_left":[False,True,True],"open_right":[True,True,False]}, ["intervals", "multi_field_consistency"])

add_json("CIF04", "instruction_following", """
ログ: `u1 OK 120`, `u2 FAIL 80`, `u1 OK 100`, `u3 OK 90`, `u2 OK 70`。OK行だけを対象にユーザーごとの第3列合計を求め、合計降順・同点はuser昇順で並べる。`totals`は `[{"user":...,"sum":...},...]`、`grand_total`は全OK合計。説明なしのJSONだけを出力せよ。
""", {"totals":[{"user":"u1","sum":220},{"user":"u3","sum":90},{"user":"u2","sum":70}],"grand_total":380}, ["log_parsing", "aggregation"])

add_json("CIF05", "instruction_following", """
点P=(2,-1), Q=(-3,4), R=(0,5)を変換する。まず(x,y)->(x+1,y-2)、次に原点中心に90度反時計回り回転(x,y)->(-y,x)。変換後をP,Q,Rの順で `points` に [[x,y],...]、各点のx+yを `sums` に入れよ。整数型を保つ。説明なしのJSONだけ。
""", {"points":[[3,3],[-2,-2],[-3,1]],"sums":[6,-4,-2]}, ["coordinate_transform", "ordered_output"])

add_json("CIF06", "instruction_following", """
集合A={1,2,3,5,8}, B={2,4,5,8}, C={1,5,7,8}。`exactly_two`に3集合のうちちょうど2集合に属する要素を昇順、`all_three`に3集合全てに属する要素を昇順、`union_count`に和集合要素数を入れよ。説明なしのJSONだけ。
""", {"exactly_two":[1,2],"all_three":[5,8],"union_count":7}, ["set_logic"])

add_json("CIF07", "instruction_following", """
候補 A:(cost=7,risk=2,value=8), B:(5,4,9), C:(6,2,7), D:(4,3,6), E:(8,1,10)。条件 cost<=7 かつ risk<=3 を満たす候補だけ残し、value/cost の比が高い順（同率はID昇順）に並べる。`ids`にID、`ratios`に比を小数第3位まで四捨五入した数値で格納せよ。説明なしのJSONだけ。
""", {"ids":["A","D","C"],"ratios":[1.143,1.5,1.167]}, ["multi_constraint", "sorting"])

# Note CIF07 expected order must be ratio descending: D 1.5, C 1.1667, A 1.1429. Fix below after construction.
rows[-1]["grader"]["expected"] = {"ids":["D","C","A"],"ratios":[1.5,1.167,1.143]}

add_json("CIF08", "instruction_following", """
整数列 [3,-1,4,4,0,-2,5,3] について、重複を除いた正の値だけを昇順にした配列を`values`、隣接差分（後-前）を`gaps`、valuesの中央値を`median`に入れよ。中央値は数値型。説明なしのJSONだけ。
""", {"values":[3,4,5],"gaps":[1,1],"median":4}, ["dedup", "derived_fields"])

# Sanity: exactly 8 per category, 80 total, unique ids.
from collections import Counter
counts = Counter(r["category"] for r in rows)
assert len(rows) == 80, len(rows)
assert len({r["id"] for r in rows}) == 80
assert set(counts.values()) == {8}, counts

OUT.write_text("".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n" for r in rows), encoding="utf-8")
print(f"wrote {len(rows)} items to {OUT}")
print(json.dumps(dict(sorted(counts.items())), ensure_ascii=False, indent=2))
