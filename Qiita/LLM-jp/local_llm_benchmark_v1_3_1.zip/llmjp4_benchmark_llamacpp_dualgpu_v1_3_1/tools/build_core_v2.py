#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "datasets" / "core_v2.1.0.jsonl"
VERSION = "2.1.0"
items: list[dict[str, Any]] = []


def add(id: str, category: str, difficulty: str, prompt: str, grader: dict[str, Any], tags: list[str], reasoning: bool=False, metadata: dict[str, Any]|None=None) -> None:
    items.append({
        "id": id, "category": category, "difficulty": difficulty,
        "prompt": prompt.strip(), "grader": grader, "tags": tags,
        "reasoning_effort_eval": reasoning, "metadata": metadata or {"original": True, "benchmark_version": VERSION},
    })


def choice(id, cat, diff, prompt, expected, tags, reasoning=False):
    add(id, cat, diff, prompt + "\n回答は選択肢の英字1文字だけを出力してください。", {"type":"choice","expected":expected,"choices":["A","B","C","D"]}, tags, reasoning)


def numeric(id, cat, diff, prompt, expected, tags, reasoning=False, atol=1e-8, rtol=5e-4):
    add(
        id, cat, diff,
        prompt + "\n計算過程は内部で行い、最終出力は `最終回答: 数値` の1行だけにしてください。"
                 "数値は小数または科学表記を推奨し、特に指定がない限り有効数字4桁以上で答えてください。",
        {"type":"numeric","expected":float(expected),"atol":atol,"rtol":rtol}, tags, reasoning,
    )


def json_exact(id, cat, diff, prompt, expected, tags, reasoning=False):
    add(id, cat, diff, prompt + "\n出力は説明なしのJSONだけにしてください。", {"type":"json_exact","expected":expected}, tags, reasoning)

# ---------------------------------------------------------------------------
# 1. Advanced Japanese reading (16) — inference, scope, modality, argumentation
# ---------------------------------------------------------------------------
J="advanced_japanese"
passages = [
("JP01", "expert", """
ある研究組織では、実験の再現性を高めるため、解析コードと生データの公開を原則化した。ただし、公開によって再同定の危険が生じる人由来データは例外とし、第三者機関による管理下アクセスを認める。ところが運用開始後、研究者の一部は「原則公開なのだから、管理下アクセスは再現性を損なう」と批判した。責任者は、再現性とは無条件の公開と同義ではなく、独立した研究者が同一手続きを検証できる制度設計まで含む、と応答した。
この文章から最も妥当に導けるものはどれか。
A. 責任者は人由来データの第三者検証を禁止している。
B. 責任者は公開範囲よりも検証可能性を再現性の本質とみなしている。
C. 批判者は解析コードの非公開を要求している。
D. 管理下アクセスでは独立検証が原理的に不可能である。""", "B", ["argumentation","research_methodology"]),
("JP02", "hard", """
自治体は渋滞対策として中心市街地への流入課金を導入した。導入後、中心部の自動車交通量は減少したが、周辺道路の交通量は増えた。担当部署は「中心部の渋滞緩和という直接目的は達成した」と報告した。一方、評価委員会は、総移動時間と大気汚染の地域分布を確認しなければ政策全体の厚生効果は判断できないとした。
評価委員会の指摘が最も直接に問題としているものはどれか。
A. 目的変数の測定誤差
B. 政策効果の空間的な置換と評価範囲
C. 自動車交通量の季節調整
D. 課金額の法的根拠""", "B", ["policy_evaluation","scope"]),
("JP03", "expert", """
「AIによる論文要約は、専門家が読む時間を短縮する。しかし要約が正確であることと、読者が原論文の論証構造を理解したこととは別である。したがって、要約の導入によって理解が低下したという観察だけから、要約技術そのものが理解を阻害すると結論することはできない。利用者が原文を読む機会を減らしたという媒介経路もあり得るからだ。」
この段落の論証構造として最も適切なのはどれか。
A. 観察された相関から直接因果を確定している。
B. 技術の効果と利用行動による媒介を区別し、単純な因果帰属を退けている。
C. 要約精度が低いことを前提に理解低下を説明している。
D. 専門家は要約を使用すべきでないという規範命題を証明している。""", "B", ["causal_reasoning","argumentation"]),
("JP04", "hard", """
ある規程は「危険物を保管する部屋には、施錠設備および自動火災検知器を設けなければならない。ただし、常時有人監視され、かつ危険物を耐火保管庫に収納する部屋については、自動火災検知器の設置を免除できる」と定める。部屋Xは施錠され、常時有人監視されているが、危険物は通常の金属棚に保管されている。
規程だけから判断した結論として正しいものはどれか。
A. Xは検知器を免除できる。
B. Xは施錠設備も不要になる。
C. Xは検知器免除の条件を満たさない。
D. Xが危険物を少量しか置かないなら自動的に免除される。""", "C", ["deontic_logic","exception_scope"]),
("JP05", "expert", """
レビュー論文は「手法Aは平均誤差で手法Bを上回る」と述べる直後に、「ただし、評価集合の大半はAの学習分布に近く、分布外領域ではBが一貫して優位だった」と付記している。著者は結論で「現状の平均指標だけからAを汎用的に優れた手法と呼ぶのは時期尚早」とした。
著者が区別している概念として最も適切なのはどれか。
A. 統計的有意性と再現性
B. 補間性能と分布外一般化性能
C. 精度と計算量
D. 教師あり学習と強化学習""", "B", ["generalization","scientific_reading"]),
("JP06", "expert", """
「市場価格が情報を反映する」という命題から、「市場価格は常に正しい」とは導けない。価格が利用可能な情報を効率的に集約していても、その情報自体が不完全であり得るし、新情報によって価格が大きく改訂されることも整合的だからである。
この文章が否定している推論はどれか。
A. 情報集約性から無謬性を導くこと
B. 新情報が価格を変化させること
C. 市場参加者が異なる情報を持つこと
D. 価格が情報を一切含まないこと""", "A", ["economics","modal_scope"]),
("JP07", "hard", """
「装置の故障率は更新後に半減した。ただし更新と同時に保守点検の周期も半分になった。」という報告がある。更新ソフトウェアの効果を評価するうえで最も重要な追加情報はどれか。
A. 装置の外装色
B. 更新前後で保守点検頻度を統制した比較
C. 開発者の人数
D. 更新ソフトウェアのファイルサイズ""", "B", ["confounding","causal_inference"]),
("JP08", "expert", """
ある哲学者は「予測できることは説明できることの必要条件ではない」と主張する。例として、複雑なシミュレーションが高精度に結果を予測しても、どの機構が結果を生んだかを識別できない場合を挙げる。一方、粗い機構モデルは予測誤差が大きくても介入点を明示できるという。
この主張に最も整合するものはどれか。
A. 説明能力と予測能力は常に反比例する。
B. 高い予測精度だけでは機構的説明を保証しない。
C. 粗いモデルは必ず正しい。
D. シミュレーションは説明に利用できない。""", "B", ["philosophy_of_science","explanation"]),
("JP09", "expert", """
「全国平均では賃金が上昇したが、全ての地域で賃金が上昇したとは限らない。さらに、各地域で平均賃金が上昇していても、全労働者の実質所得が増えたとは限らない。」
この文が注意を促している二つの誤りの組合せとして最適なのはどれか。
A. 生態学的誤謬と平均値から個人への過度な一般化
B. 循環論法と後件肯定
C. サンプルサイズ不足と多重比較
D. 測定不変性と欠測補完""", "A", ["aggregation","statistics"]),
("JP10", "hard", """
契約書には「甲は納品後30日以内に検収を完了し、重大な瑕疵がある場合に限り受領を拒否できる」とある。納品物には軽微な表示崩れがあるが機能上の欠陥はない。契約文だけを前提とした場合、最も妥当なのはどれか。
A. 甲は任意の理由で拒否できる。
B. 軽微な表示崩れが重大な瑕疵に該当するかの評価が必要である。
C. 30日を過ぎても必ず拒否できる。
D. 機能上の欠陥がないので検収自体が不要である。""", "B", ["legal_reading","qualification"]),
("JP11", "expert", """
「ある薬剤群で観察研究上の死亡率が低かった」という結果に対し、著者は「処方される患者の重症度が群間で異なる可能性があり、治療選択がランダムでない以上、治療効果の推定には追加調整が必要」とする。
この懸念に最も近いものはどれか。
A. 選択バイアス／交絡
B. 出版バイアスのみ
C. 測定単位の不一致
D. 多重共線性が必ず生じること""", "A", ["epidemiology","confounding"]),
("JP12", "expert", """
「規模を2倍にしたとき計算時間が2倍になった」という1点の観察だけから、アルゴリズムが線形時間であるとは結論できない。定数項、キャッシュ効果、入力分布などによって限られた範囲では異なる漸近計算量でも線形に見えるからである。
この文章が要求している評価として最も適切なのはどれか。
A. 単一入力での最大メモリだけを測る。
B. 複数の入力規模と分布でスケーリングを測定する。
C. 実装言語を変更すれば漸近計算量が決まる。
D. 2倍化測定を一度だけ再実行する。""", "B", ["algorithm_analysis","empirical_scaling"]),
("JP13", "hard", """
「必要な安全率を満たす設計のうち、質量が最小のものを選ぶ」という設計方針について、候補PはQより軽いが安全率を満たさず、QとRは安全率を満たし、Qの方がRより軽い。
方針に従う選択はどれか。
A. P
B. Q
C. R
D. 情報不足""", "B", ["optimization","constraint_priority"]),
("JP14", "expert", """
「モデルCの誤差分散はモデルDより小さいが、系統誤差は大きい。用途が母平均の推定ならCが常に優れるとは言えない」とある。
この判断を直接支える概念はどれか。
A. バイアス・分散トレードオフ
B. 中心極限定理だけ
C. ベイズ因子だけ
D. モンテカルロ積分だけ""", "A", ["bias_variance","statistics"]),
("JP15", "expert", """
「データベースに記録がない」ことと「対象が存在しない」ことを同一視してはならない。データベースの収録範囲が限定されているなら、前者は後者の十分な証拠ではない。
最も適切な言い換えはどれか。
A. 不在の証拠と証拠の不在は常に同じである。
B. 検索系の網羅性を確認せず、未検出を不存在と断定すべきでない。
C. データベース検索は一切意味がない。
D. 記録があれば対象は必ず実在する。""", "B", ["evidence","information_retrieval"]),
("JP16", "hard", """
「規制導入後に事故件数は20%減ったが、走行距離は30%減った。」事故リスクの変化を判断するために最も直接的に比較すべき量はどれか。
A. 事故件数そのものだけ
B. 単位走行距離当たり事故件数
C. 車両価格
D. 規制文書のページ数""", "B", ["rate_normalization","policy"]),
]
for pid,diff,prompt,ans,tags in passages:
    choice(pid,J,diff,prompt,ans,tags,reasoning=pid in {"JP01","JP03","JP05","JP08"})

# ---------------------------------------------------------------------------
# 2. Analytical reasoning (16)
# ---------------------------------------------------------------------------
A="analytical_reasoning"
# decision theory
numeric("AR01",A,"expert","""ある診断で事前確率P(D)=0.08、感度0.90、特異度0.95である。陽性後に独立な同一性能の確認検査を行い、2回とも陽性だった。条件付き独立を仮定したときP(D|++)を求めよ。""", (0.08*0.9**2)/(0.08*0.9**2+0.92*0.05**2), ["bayes","diagnosis"], True, atol=1e-4)
numeric("AR02",A,"expert","""新製品A/Bの利益は景気Good/Badでそれぞれ A=(120,-40), B=(80,20) 万円。Goodの事前確率0.5。市場調査シグナルSの尤度はP(S|Good)=0.8, P(S|Bad)=0.3。Sを観測した。期待利益最大の製品を選んだときの期待利益（万円）を求めよ。""", max(120*((.8*.5)/(.8*.5+.3*.5))+(-40)*(1-(.8*.5)/(.8*.5+.3*.5)),80*((.8*.5)/(.8*.5+.3*.5))+20*(1-(.8*.5)/(.8*.5+.3*.5))), ["bayesian_decision"], True, atol=1e-4)
choice("AR03",A,"expert","""処置T、アウトカムY、未観測重症度Uがあり、U→T, U→Y。さらにT→M→Yという媒介経路がある。Tの総因果効果を推定したい。次の調整集合のうち最も不適切なのはどれか。
A. Uが観測可能ならUを調整する
B. Mだけを調整する
C. T以前の共変量でUの十分な代理を調整する
D. ランダム化によりTとUを独立にする""","B",["causal_inference","mediation"],True)
# LP optimum manually at intersections x+y<=8,2x+y<=10,x+3y<=15 max 5x+4y. intersections: (2,6) violates third 20; (5,0), (3,5) third18; 2x+y=10 & x+3y=15 => x=3,y=4 ->31. x+y=8 & x+3y=15 => y=3.5,x=4.5, 2x+y=12.5 violate. x+3y=15 with x-axis15? 2x+y constraint. vertices (0,5),(3,4),(5,0): max31.
numeric("AR04",A,"expert","""線形計画: x,y>=0, x+y<=8, 2x+y<=10, x+3y<=15 の下で 5x+4y を最大化する。最大値を求めよ。""",31,["linear_programming","optimization"],True)
choice("AR05",A,"hard","""4群の平均を同時比較した後、事前に定めていなかった全6対のt検定を各5%で行う。家族内第1種過誤を制御する最も直接的な修正はどれか。
A. Bonferroniで各検定の有意水準を0.05/6にする
B. 各検定の有意水準を0.30にする
C. サンプル平均を標準化しない
D. p値を平均する""","A",["multiple_testing","statistics"])
# schedule critical path
numeric("AR06",A,"hard","""作業A(3日)後にB(4日)とC(6日)が並行開始。D(5日)はBとCの両方完了後、E(2日)はB完了後に開始。プロジェクト完了はDとEの両方完了時。最短完了日数を求めよ。""",14,["critical_path","scheduling"],False)
# game mixed equilibrium: matching-ish payoff row: U against L,R 3,0; D 1,2. Column indifferent if p: col payoff L? give column payoffs U(L,R)=1,3 D=4,0. p such that L=4-3p R=3p =>p=2/3. Ask row prob.
numeric("AR07",A,"expert","""2人ゲームで列プレイヤーの利得は、行Uのとき(L,R)=(1,3)、行Dのとき(L,R)=(4,0)。完全混合ナッシュ均衡で列プレイヤーをLとRの間で無差別にする行プレイヤーのU選択確率pを求めよ。""",2/3,["game_theory","mixed_equilibrium"],True,atol=1e-5)
# experiment design power conceptual
choice("AR08",A,"expert","""同一被験者に処置前後測定を行い、個体間分散が大きく、前後相関が高い。平均変化を検出する検定の検出力を高める設計として最も合理的なのはどれか。
A. 前後を独立標本として扱う
B. 対応のある解析を用いる
C. 前測定を捨てる
D. 有意水準を事後的に上げる""","B",["experimental_design","paired_analysis"],False)
# DAG d-sep
choice("AR09",A,"expert","""DAG X→M→Y, X→Y, Z→M, Z→Y がある。XのYへの総効果を推定する際、ZはXの原因ではない。最も適切な説明はどれか。
A. Zは必ずX-Y交絡なので調整必須
B. Mを調整するとX→M→Yを遮断するため総効果には不適切
C. Yを調整すれば総効果が得られる
D. Xを調整集合に入れる""","B",["causal_graphs","d_separation"],True)
# reliability series-parallel: two parallel comp p=.9 each, in series with .95 => (1-.1^2)*.95=.9405
numeric("AR10",A,"hard","""独立な部品A,B（各信頼度0.90）が並列冗長を構成し、そのブロックが部品C（信頼度0.95）と直列接続されている。システム信頼度を求めよ。""",0.9405,["reliability","probability"],False,atol=1e-6)
# queueing M/M/1 W=1/(mu-lam)
numeric("AR11",A,"hard","""到着率λ=8件/時、サービス率μ=10件/時のM/M/1待ち行列を仮定する。系内平均滞在時間Wを時間単位で求めよ。""",0.5,["queueing","stochastic_process"],False)
# Bayesian expected value info
numeric("AR12",A,"expert","""状態H/Lの確率は0.4/0.6。行動aの利得はHで100,Lで-20、行動bは常に30。完全情報を得られる場合の期待価値EVPIを求めよ。""", (0.4*100+0.6*30)-max(0.4*100+0.6*(-20),30), ["decision_analysis","EVPI"],True)
# robust optimization
choice("AR13",A,"expert","""モデルAは3環境で損失(1,4,7)、モデルBは(3,3,5)、モデルCは(2,6,4)。最悪損失を最小化するminimax選択はどれか。
A. A
B. B
C. C
D. AとC""","B",["robust_optimization","minimax"],False)
# Simpson paradox
choice("AR14",A,"expert","""治療Tは軽症群・重症群の各層内では治療Cより成功率が高いが、全体集計ではTの成功率が低い。この現象を説明し得る条件として最も適切なのはどれか。
A. T群に重症患者が相対的に多い
B. 両群の重症度構成が完全に同じ
C. 各層の成功率が等しい
D. 成功率が確率でない""","A",["simpson_paradox","confounding"],True)
# posterior odds LR
numeric("AR15",A,"hard","""仮説H1:H0の事前オッズが1:4、観測データの尤度比P(data|H1)/P(data|H0)=6である。H1の事後確率を求めよ。""",1.5/2.5,["bayes_factor","odds"],False)
# Fermi/units combined
numeric("AR16",A,"expert","""装置は1試行あたり2.5秒、成功確率0.04。独立試行を直列実行する。少なくとも1回成功する確率を0.95以上にする最小試行回数Nを求め、その総実行時間を秒で答えよ。""", math.ceil(math.log(0.05)/math.log(0.96))*2.5,["geometric","planning"],True,atol=1e-9)

# ---------------------------------------------------------------------------
# 3. Mathematics & statistics (20)
# ---------------------------------------------------------------------------
M="mathematics_statistics"
# ridge regression beta=(XTX+lambda I)^-1 XTy
import numpy as np
X=np.array([[1.,0.],[1.,1.],[1.,2.]]) ; y=np.array([1.,2.,2.]); lam=1
beta=np.linalg.solve(X.T@X+lam*np.eye(2),X.T@y)
numeric("MS01",M,"expert",f"""リッジ回帰（切片も正則化する）で X=[[1,0],[1,1],[1,2]], y=[1,2,2]^T, λ=1 とする。β=(X^T X+λI)^(-1)X^Ty の第2成分β2を求めよ。""",beta[1],["linear_algebra","ridge_regression"],True,atol=1e-5)
# constrained max x*y subject x+2y=12 => x=6,y=3 product18
numeric("MS02",M,"hard","""x>0,y>0, x+2y=12 の制約下で f(x,y)=xy を最大化する。最大値を求めよ。""",18,["calculus","lagrange_multiplier"],False)
# bivar normal cond mean muY+rho sy/sx(x-mux)=1+0.6*3/2*(5-2)=3.7
numeric("MS03",M,"expert","""(X,Y)は二変量正規。μX=2, μY=1, σX=2, σY=3, 相関ρ=0.6。X=5のときの条件付き期待値E[Y|X=5]を求めよ。""",3.7,["probability","multivariate_normal"],True)
# beta-binomial predictive alpha=2 beta=3 observed 7 success 3 fail -> post 9,6 predictive=0.6
numeric("MS04",M,"hard","""Bernoulli成功確率pにBeta(2,3)事前分布を置く。10試行で7成功3失敗を観測した。次の1試行が成功する事後予測確率を求めよ。""",0.6,["bayesian_statistics","conjugate_prior"],False)
# Markov stationary 2-state P [[.8,.2],[.3,.7]], piA=.6
numeric("MS05",M,"hard","""2状態Markov連鎖の遷移行列が [[0.8,0.2],[0.3,0.7]]（行=現在、列=次）である。定常分布における状態1の確率を求めよ。""",0.6,["markov_chain","stationary_distribution"],False)
# entropy rate binary Markov stationary .6,.4 H=.6 H(.2)+.4 H(.3)
def H(p): return -p*math.log2(p)-(1-p)*math.log2(1-p)
numeric("MS06",M,"expert","""遷移行列 [[0.8,0.2],[0.3,0.7]] の定常2状態Markov情報源について、エントロピー率（bit/step）を求めよ。logは底2。""",0.6*H(.2)+0.4*H(.3),["information_theory","entropy_rate"],True,atol=1e-5)
# mutual information binary symmetric channel p crossover .1 with uniform input =1-H(.1)
numeric("MS07",M,"expert","""入力Xが一様Bernoulliで、交差確率0.1の二元対称通信路を通ってYが得られる。相互情報量I(X;Y) [bit] を求めよ。""",1-H(.1),["information_theory","mutual_information"],True,atol=1e-5)
# Newton step f=x^3-2x-5 x0=2 => 2-(8-4-5)/(12-2)=2.1
numeric("MS08",M,"hard","""f(x)=x^3-2x-5=0にNewton法を適用する。初期値x0=2から1回更新したx1を求めよ。""",2.1,["numerical_analysis","newton_method"],False)
# RK4 y'=y, h=0.2 from y0=1 -> approx
h=.2;k1=1;k2=1+h*k1/2;k3=1+h*k2/2;k4=1+h*k3;rk=1+h*(k1+2*k2+2*k3+k4)/6
numeric("MS09",M,"expert","""常微分方程式y'=y, y(0)=1を刻みh=0.2の古典的4次Runge-Kutta法で1ステップ進めたy(0.2)を求めよ。""",rk,["numerical_analysis","ODE"],True,atol=1e-6)
# Fourier coefficient of x on [-pi,pi], b_n=2(-1)^(n+1)/n, n=3 => 2/3
numeric("MS10",M,"expert","""f(x)=x (-π<x<π) の2π周期Fourier級数 f(x)=Σ b_n sin(nx) における b_3 を求めよ。""",2/3,["fourier_analysis"],True,atol=1e-6)
# inclusion-exclusion divisible by 2,3,5 among 1..300 union
N=300
cnt=sum(1 for i in range(1,N+1) if i%2==0 or i%3==0 or i%5==0)
numeric("MS11",M,"hard","""1から300までの整数のうち、2,3,5の少なくとも1つで割り切れる整数の個数を求めよ。""",cnt,["combinatorics","inclusion_exclusion"],False)
# PCA ratio eigenvalues covariance [[4,2],[2,3]] eig max ratio
vals=np.linalg.eigvalsh(np.array([[4.,2.],[2.,3.]])); ratio=vals[-1]/vals.sum()
numeric("MS12",M,"expert","""共分散行列 [[4,2],[2,3]] のPCAで、第1主成分の寄与率を求めよ。""",ratio,["linear_algebra","PCA"],True,atol=1e-5)
# conditional variance normal sy2(1-rho2)=9*.64=5.76
numeric("MS13",M,"hard","""二変量正規でσY=3, 相関ρ=0.6のとき、Var(Y|X)を求めよ。""",5.76,["probability","conditional_variance"],False)
# Poisson likelihood ratio lambda1=4 lambda0=2 observe k=3, LR=e^-2 *2^3
numeric("MS14",M,"expert","""1観測K=3について、Poisson(λ=4)対Poisson(λ=2)の尤度比 L(4)/L(2) を求めよ。""",math.exp(-2)*8,["likelihood_ratio","statistics"],True,atol=1e-6)
# sample size paired mean known sigma difference 5, delta2, alpha .05 two-sided z1.96 power .8 z.84 n=((2.8)*5/2)^2=49
numeric("MS15",M,"expert","""対応差の標準偏差を5、検出したい平均差を2とする。正規近似で両側α=0.05、検出力0.80（z0.975=1.96,z0.80=0.84）に必要な標本数 n≈((1.96+0.84)σ/δ)^2 を切り上げて求めよ。""",49,["power_analysis","experimental_design"],False)
# covariance transform det? Let Z=AX, cov I, A [[2,1],[1,3]], covariance AA^T det = det(A)^2=25
numeric("MS16",M,"expert","""Xの共分散行列がI_2、Z=AX、A=[[2,1],[1,3]] とする。Zの共分散行列の行列式を求めよ。""",25,["linear_algebra","covariance"],True)
# expected stopping geometric until 2 consecutive successes? p=.5 expected 6
numeric("MS17",M,"expert","""独立な公平コインを投げ、表が2回連続して初めて出た時点で停止する。停止までの投数の期待値を求めよ。""",6,["stochastic_process","stopping_time"],True)
# Jensen choice
choice("MS18",M,"expert","""正の確率変数XについてE[X]=2。次のうちJensenの不等式から必ず言えるものはどれか。
A. E[log X] >= log 2
B. E[log X] <= log 2
C. E[1/X] <= 1/2
D. Var(X)=0""","B",["probability","convexity"],False)
# F test? weighted mean variance inverse
numeric("MS19",M,"expert","""独立な不偏推定量A,Bの分散がそれぞれ4,9。線形結合wA+(1-w)Bを不偏のまま最小分散にするwを求めよ。""",9/13,["estimation","variance_weighting"],True,atol=1e-6)
# logistic odds ratio from coefficient .7 => exp .7
numeric("MS20",M,"hard","""ロジスティック回帰 logit P(Y=1)=β0+0.7x で、xが1増加したときのオッズ比を求めよ。""",math.exp(.7),["regression","logistic"],False,atol=1e-5)

# ---------------------------------------------------------------------------
# 4. Coding (16) hidden unit tests
# ---------------------------------------------------------------------------
C="coding"
def code(id,diff,prompt,entry,tests,tags,reasoning):
    add(
        id, C, diff,
        prompt.strip()
        + "\n説明文は不要で、Pythonコードだけを出力してください。"
          " importを使う場合は math, statistics, itertools, collections, functools, heapq, bisect, operator, re, typing, __future__ のみ使用可能です。",
        {"type":"python_unit_test","entrypoint":entry,"tests":tests,"timeout_s":5}, tags, reasoning,
    )
code("CD01","expert","""関数 `max_non_adjacent(nums: list[int]) -> int` を実装せよ。隣接要素を同時に選ばずに得られる和の最大値を返す。空集合を選んでもよいので全要素が負なら0。O(n)時間、O(1)追加空間を目標とする。""","max_non_adjacent",[
{"args":[[2,7,9,3,1]],"expected":12},{"args":[[-5,-1]],"expected":0},{"args":[[5]],"expected":5},{"args":[[4,1,1,4]],"expected":8}], ["dynamic_programming"],True)
code("CD02","expert","""関数 `toposort(n: int, edges: list[list[int]]) -> list[int]` を実装せよ。0..n-1のDAGの辺u→vが与えられる。辞書順最小のトポロジカル順序を返す。閉路があれば空リスト。""","toposort",[
{"args":[4,[[0,2],[1,2],[1,3]]],"expected":[0,1,2,3]},{"args":[3,[[0,1],[1,2],[2,0]]],"expected":[]},{"args":[5,[]],"expected":[0,1,2,3,4]}], ["graphs","heap"],True)
code("CD03","hard","""関数 `merge_intervals(intervals)` を実装せよ。各区間は[start,end]でstart<=end。接触する区間（例[1,2],[2,3]）も結合し、start昇順で返す。入力は変更しない。""","merge_intervals",[
{"args":[[[1,3],[2,6],[8,10],[10,12]]],"expected":[[1,6],[8,12]]},{"args":[[]],"expected":[]},{"args":[[[5,5],[1,2]]],"expected":[[1,2],[5,5]]}], ["intervals"],False)
code("CD04","expert","""関数 `longest_unique_substring(s: str) -> int` を実装せよ。Unicode文字列について重複文字を含まない最長連続部分文字列の長さをO(n)で返す。""","longest_unique_substring",[
{"args":["abcabcbb"],"expected":3},{"args":["こころここ"],"expected":2},{"args":[""],"expected":0},{"args":["abba"],"expected":2}], ["sliding_window","unicode"],True)
code("CD05","expert","""関数 `shortest_path(grid)` を実装せよ。0=通行可,1=壁の長方形格子で左上から右下まで上下左右に移動する最短手数を返す。到達不能なら-1。開始・終了が壁でも-1。""","shortest_path",[
{"args":[[[0,0,1],[1,0,0],[0,0,0]]],"expected":4},{"args":[[[0,1],[1,0]]],"expected":-1},{"args":[[[0]]],"expected":0},{"args":[[[1]]],"expected":-1}], ["BFS","graphs"],True)
code("CD06","expert","""関数 `edit_distance(a,b)` を実装せよ。挿入・削除・置換のコストをすべて1とするLevenshtein距離を返す。""","edit_distance",[
{"args":["kitten","sitting"],"expected":3},{"args":["化学","科学"],"expected":1},{"args":["", "abc"],"expected":3},{"args":["same","same"],"expected":0}], ["dynamic_programming","strings"],True)
code("CD07","hard","""関数 `rle_decode(s)` を実装せよ。形式は正整数の十進表記の直後に1文字が続く組（例`12a3b`）。全体を復号する。不正形式（0回、数だけで終わる、数なし文字）ではValueError。""","rle_decode",[
{"args":["3a2b1c"],"expected":"aaabbc"},{"args":["12x"],"expected":"xxxxxxxxxxxx"},{"args":["1あ2い"],"expected":"あいい"}], ["parsing","validation"],False)
code("CD08","expert","""関数 `weighted_interval_scheduling(jobs)` を実装せよ。各job=[start,end,value]、end<=次startなら両立。重ならないjob集合のvalue合計最大値を返す。""","weighted_interval_scheduling",[
{"args":[[[1,3,5],[2,5,6],[4,6,5],[6,7,4],[5,8,11],[7,9,2]]],"expected":17},{"args":[[]],"expected":0},{"args":[[[0,1,2],[1,2,3]]],"expected":5}], ["dynamic_programming","binary_search"],True)
code("CD09","expert","""関数 `count_islands(grid)` を実装せよ。`1`/`0`の長方形リストで、上下左右接続の1の連結成分数を返す。入力を変更しない。""","count_islands",[
{"args":[[[1,1,0],[0,1,0],[1,0,1]]],"expected":3},{"args":[[[0,0],[0,0]]],"expected":0},{"args":[[[1]]],"expected":1}], ["graphs","DFS"],False)
code("CD10","expert","""関数 `median_stream(nums)` を実装せよ。各要素を順に追加した直後の中央値をfloatのリストで返す。偶数個では中央2値の平均。""","median_stream",[
{"args":[[5,2,10,4]],"expected":[5.0,3.5,5.0,4.5]},{"args":[[-1,-2,-3]],"expected":[-1.0,-1.5,-2.0]},{"args":[[]],"expected":[]}], ["heaps","streaming"],True)
code("CD11","hard","""関数 `group_anagrams(words)` を実装せよ。Unicode文字の完全一致を基準にアナグラムをまとめ、各群内部は入力順、群の順序は各群の最初の出現順で返す。""","group_anagrams",[
{"args":[["eat","tea","tan","ate","nat","bat"]],"expected":[["eat","tea","ate"],["tan","nat"],["bat"]]},{"args":[["東京","京東","大阪"]],"expected":[["東京","京東"],["大阪"]]}], ["hashing","unicode"],False)
code("CD12","expert","""関数 `dijkstra(n, edges, source)` を実装せよ。無向グラフのedge=[u,v,w]、w>=0。sourceから各頂点への最短距離をリストで返し、到達不能はNone。""","dijkstra",[
{"args":[4,[[0,1,2],[1,2,3],[0,2,10]],0],"expected":[0,2,5,None]},{"args":[1,[],0],"expected":[0]},{"args":[3,[[0,1,0],[1,2,1]],0],"expected":[0,0,1]}], ["graphs","shortest_path"],True)
code("CD13","expert","""関数 `lis_length(nums)` を実装せよ。狭義単調増加部分列の最大長をO(n log n)で返す。""","lis_length",[
{"args":[[10,9,2,5,3,7,101,18]],"expected":4},{"args":[[2,2,2]],"expected":1},{"args":[[]],"expected":0},{"args":[[-3,-2,-1]],"expected":3}], ["binary_search","dynamic_programming"],True)
code("CD14","hard","""関数 `normalize_path(path)` を実装せよ。Unix風絶対パスのみを受け取り、連続`/`、`.`、`..`を正規化する。ルートより上の`..`はルートに留める。""","normalize_path",[
{"args":["/a//b/./c/../d"],"expected":"/a/b/d"},{"args":["/../../x"],"expected":"/x"},{"args":["/"],"expected":"/"}], ["parsing","stack"],False)
code("CD15","expert","""関数 `knapsack_01(weights, values, capacity)` を実装せよ。各品物は高々1回、総重量capacity以下で価値最大を返す。capacityは非負整数。""","knapsack_01",[
{"args":[[2,3,4,5],[3,4,5,8],5],"expected":8},{"args":[[1,2,3],[6,10,12],5],"expected":22},{"args":[[],[],10],"expected":0}], ["dynamic_programming","optimization"],True)
code("CD16","expert","""関数 `parse_formula(formula)` を実装せよ。元素記号は大文字+任意の小文字、直後の正整数は個数（省略=1）。括弧は1段以上ネスト可で直後に倍率を置ける。元素数の辞書を返す。例 `Ca(OH)2`。""","parse_formula",[
{"args":["Ca(OH)2"],"expected":{"Ca":1,"O":2,"H":2}},{"args":["Al2(SO4)3"],"expected":{"Al":2,"S":3,"O":12}},{"args":["K4(ON(SO3)2)2"],"expected":{"K":4,"O":14,"N":2,"S":4}}], ["parsing","stack","chemistry_notation"],True)

# ---------------------------------------------------------------------------
# 5. Physics & engineering (12)
# ---------------------------------------------------------------------------
P="physics_engineering"
# RLC series Q = w0 L/R, w0=1/sqrtLC
L=.02; Cc=2e-6; R=10; w=1/math.sqrt(L*Cc)
numeric("PH01",P,"expert","""直列RLC回路でR=10Ω, L=20mH, C=2.0µF。共振角周波数ω0とQ=ω0L/Rを用いて品質係数Qを求めよ。""",w*L/R,["circuits","resonance"],True,atol=1e-5)
# nodal: node V connected 12V via 6ohm, ground 3ohm, current source 1A from ground into node. (V-12)/6+V/3-1=0 =>3V-12-6=0 V=6
numeric("PH02",P,"expert","""節点Vは12V電源節点に6Ω、接地に3Ωで接続され、さらに接地から節点Vへ1Aの電流源が流れ込む。KCLからV[V]を求めよ。""",6,["circuits","nodal_analysis"],True)
# Carnot two engines T1 600, T2 400, T3 300, heat input 1000; W1=333.33, rejected666.67 into second W2=166.67 total500
numeric("PH03",P,"expert","""600K→400Kの可逆Carnot機関の排熱をすべて400K→300Kの可逆Carnot機関へ入力する。第1機関への熱入力が1000Jのとき、2機関の総仕事[J]を求めよ。""",500,["thermodynamics","carnot"],True)
# particle box E~n2; transition 3->2 energy 5 E1; E1 h2/8mL2 for electron L1nm in eV
hplan=6.62607015e-34; me=9.1093837015e-31; Lbox=1e-9; ev=1.602176634e-19; E1=hplan**2/(8*me*Lbox**2)/ev
numeric("PH04",P,"expert","""幅1.00nmの1次元無限深井戸中の電子がn=3からn=2へ遷移する。放出光子エネルギー[eV]を求めよ。h=6.62607015e-34 J s, m_e=9.1093837e-31 kg, 1eV=1.602176634e-19J。""",5*E1,["quantum_mechanics","particle_in_box"],True,atol=1e-3)
# relativistic kinetic 0.8c gamma1.6667 KE=(.6667)*511=340.667keV
numeric("PH05",P,"hard","""電子が0.8cで運動している。相対論的運動エネルギー(γ-1)m_ec^2をkeVで求めよ。m_ec^2=511keV。""",(1/math.sqrt(1-.8**2)-1)*511,["relativity"],False,atol=1e-3)
# capacitor layers series dielectrics equal thickness k2,4 effective k harmonic 2/(1/2+1/4)=2.6667
numeric("PH06",P,"expert","""平行板コンデンサの板間を厚さが等しい2層誘電体（比誘電率2と4）が電場方向に直列に満たす。同じ幾何形状の真空コンデンサに対する容量比C/C0を求めよ。""",8/3,["electromagnetism","dielectrics"],True)
# diffraction grating d=1.5um lambda500nm m2 sin=2/3 theta41.81
numeric("PH07",P,"hard","""格子間隔d=1.50µmの回折格子にλ=500nmの光を垂直入射する。2次主極大の角度θ[deg]を求めよ。""",math.degrees(math.asin(2*500e-9/1.5e-6)),["optics","diffraction"],False,atol=1e-3)
# rotating disk energy with rolling cylinder down height? v2=4gh/3 solid cylinder. h=1.2
numeric("PH08",P,"expert","""一様な実体円柱が高さ1.20mを滑らず転がり落ちる。I=MR^2/2、g=9.8m/s^2として底での重心速度[m/s]を求めよ。""",math.sqrt(4*9.8*1.2/3),["mechanics","rolling"],True,atol=1e-4)
# heat conduction composite equal A, L1 .1 k10 L2 .2 k20 deltaT60 R=.01+.01=.02 q/A=3000
numeric("PH09",P,"expert","""定常1次元熱伝導。層1:L=0.10m,k=10 W/mK、層2:L=0.20m,k=20 W/mKを直列積層し、両端温度差60K。接触熱抵抗なし。熱流束[W/m^2]を求めよ。""",3000,["heat_transfer","thermal_resistance"],True)
# RC charging reaches 90% t=-RC ln .1 R10k C100u=1s =>2.3026
numeric("PH10",P,"hard","""RC充電回路でR=10kΩ,C=100µF。0Vからステップ印加し、コンデンサ電圧が最終値の90%に達する時間[s]を求めよ。""",-1*math.log(.1),["circuits","transient"],False,atol=1e-5)
# semiconductor intrinsic conductivity q n (mu_e+mu_h), n=1e16 m-3, mu .14,.05 => 1.602e-19*1e16*.19
numeric("PH11",P,"expert","""真性半導体でn=p=1.0e16 m^-3、電子移動度0.14、正孔移動度0.05 m^2/Vs。σ=q(nμe+pμh), q=1.602e-19Cとして導電率[S/m]を求めよ。""",1.602e-19*1e16*.19,["semiconductor","transport"],False,atol=1e-8)
# projectile range from height? x = v cos t, y=h+v sin t - .5g t2. v20 angle30 h5 solve positive
v=20;th=math.radians(30);hh=5;g=9.8;t=(v*math.sin(th)+math.sqrt((v*math.sin(th))**2+2*g*hh))/g; rng=v*math.cos(th)*t
numeric("PH12",P,"expert","""地上5mの位置から速さ20m/s、水平から30°上向きに投射する。空気抵抗なし、g=9.8m/s^2。着地点までの水平距離[m]を求めよ。""",rng,["mechanics","projectile"],True,atol=1e-3)

# ---------------------------------------------------------------------------
# 6. Chemistry & materials (12)
# ---------------------------------------------------------------------------
CH="chemistry_materials"
# equilibrium A<->B K=4 start A1 B0, x/(1-x)=4 x=.8
numeric("CH01",CH,"hard","""理想系でA⇌B、平衡定数K=[B]/[A]=4.0。初期[A]=1.0M,[B]=0で体積一定。平衡時[B]をMで求めよ。""",0.8,["chemical_equilibrium"],False)
# Nernst E=E0 - RT/nF ln Q, E0 .34 n2 Q=0.01 at298 => + .05916
numeric("CH02",CH,"expert","""298Kで2電子反応の標準電位E°=0.340V、反応商Q=0.0100。Nernst式 E=E°-(RT/nF)lnQ、R=8.314,T=298,F=96485 を用いE[V]を求めよ。""",0.340-(8.314*298/(2*96485))*math.log(.01),["electrochemistry","nernst"],True,atol=1e-5)
# Arrhenius ratio at 350 vs300 Ea50k
numeric("CH03",CH,"expert","""Arrhenius式に従う反応でEa=50.0kJ/mol。k(350K)/k(300K)を求めよ。R=8.314J/molK。""",math.exp(-50000/8.314*(1/350-1/300)),["kinetics","arrhenius"],True,atol=1e-4)
# Langmuir two species competition thetaA=KA PA/(1+KA PA+KB PB): 2*.4 /(1+.8+ .5*.6=.3)=.8/2.1
numeric("CH04",CH,"expert","""競争Langmuir吸着でKA=2.0 bar^-1, KB=0.5 bar^-1, PA=0.40bar, PB=0.60bar。θA=KAPA/(1+KAPA+KBPB)を求めよ。""",.8/2.1,["surface_chemistry","langmuir"],True,atol=1e-5)
# FCC density Al a=.405nm 4 atoms mol26.98
rho=4*(26.98e-3/6.02214076e23)/(.405e-9)**3
numeric("CH05",CH,"expert","""FCC Alを仮定し格子定数a=0.405nm、原子量26.98g/mol、NA=6.02214076e23。密度[kg/m^3]を求めよ。FCC単位胞あたり4原子。""",rho,["materials_science","crystallography"],True,atol=2)
# lever rule alpha composition20 beta80 overall50 fraction beta=(50-20)/(80-20)=.5
numeric("CH06",CH,"hard","""二相α+β領域でα相組成20at%, β相組成80at%、全体組成50at%。レバー則によるβ相モル分率を求めよ。""",0.5,["phase_diagram","lever_rule"],False)
# diffusion ratio Q .8eV T 900 vs700 kB eV
kb=8.617333262e-5
numeric("CH07",CH,"expert","""拡散係数D=D0 exp(-Q/kBT)、Q=0.80eV。D(900K)/D(700K)を求めよ。kB=8.617333262e-5 eV/K。""",math.exp(-.8/kb*(1/900-1/700)),["diffusion","materials"],True,atol=1e-4)
# vacancy fraction exp(-Ef/kT), Ef1eV T1000
numeric("CH08",CH,"hard","""空孔形成エネルギーEf=1.00eV、形成エントロピー項を無視。1000Kで空孔分率≈exp(-Ef/kBT)を求めよ。kB=8.617333262e-5eV/K。""",math.exp(-1/(kb*1000)),["defects","statistical_thermodynamics"],False,atol=1e-8)
# first order two consecutive? A->B k .2, B->C .1, B(t)=k1/(k2-k1)(e-k1t-e-k2t); t max ln(k1/k2)/(k1-k2)=ln2/.1
numeric("CH09",CH,"expert","""逐次一次反応A→B→Cでk1=0.20s^-1,k2=0.10s^-1、初期Aのみ。中間体Bが最大となる時刻 t=ln(k1/k2)/(k1-k2) [s] を求めよ。""",math.log(2)/.1,["kinetics","consecutive_reactions"],True,atol=1e-5)
# pH buffer HH pKa4.76 acetate/acetic=2 ->5.061
numeric("CH10",CH,"hard","""酢酸/酢酸イオン緩衝液でpKa=4.76、[A-]/[HA]=2.00。Henderson-Hasselbalch式によるpHを求めよ。""",4.76+math.log10(2),["acid_base","buffer"],False,atol=1e-4)
# polymer Mn from fractions number: 100 molecules M10000,50 M30000 => total mass2.5e6/150=16666.7
numeric("CH11",CH,"expert","""分子量10000の高分子100分子と、分子量30000の高分子50分子からなる試料の数平均分子量Mnを求めよ。""",(100*10000+50*30000)/150,["polymer_science","molecular_weight"],False,atol=1e-3)
# ideal mixing deltaG RT(xlnx...) binary .3 .7 at500 J/mol
numeric("CH12",CH,"expert","""理想二元混合物xA=0.30,xB=0.70、T=500K。1molあたりの混合GibbsエネルギーΔGmix=RTΣxi ln xi [J/mol]を求めよ。R=8.314。""",8.314*500*(.3*math.log(.3)+.7*math.log(.7)),["thermodynamics","ideal_solution"],True,atol=1e-2)

# ---------------------------------------------------------------------------
# 7. Life science & information science (10)
# ---------------------------------------------------------------------------
L="life_information"
# competitive inhibition v=Vmax S/(alpha Km+S), alpha 1+I/Ki=3; V100 S10 Km5 =>100*10/25=40
numeric("LI01",L,"expert","""Michaelis-Menten酵素に競争阻害剤。Vmax=100, Km=5µM, [S]=10µM, [I]=4µM, Ki=2µM。α=1+[I]/Kiとして v=Vmax[S]/(αKm+[S]) を求めよ。""",40,["biochemistry","enzyme_kinetics"],True)
# population matrix [[.5,1.2],[.4,.6]] dominant eigen
mat=np.array([[.5,1.2],[.4,.6]]); eig=max(np.linalg.eigvals(mat).real)
numeric("LI02",L,"expert","""2齢級Leslie型行列 [[0.5,1.2],[0.4,0.6]] で個体群が更新される。長期増殖率に対応する最大固有値を求めよ。""",eig,["population_biology","linear_algebra"],True,atol=1e-5)
# sequencing coverage no read probability exp(-C), C=10 ->
numeric("LI03",L,"hard","""Lander-Watermanの単純Poissonモデルで平均カバレッジC=10。ある塩基が1本のreadにも覆われない確率を求めよ。""",math.exp(-10),["genomics","poisson"],False,atol=1e-8)
# logistic N(t) formula K/(1+(K-N0)/N0 exp(-rt)), K1000 N0100 r.5 t4
numeric("LI04",L,"expert","""連続時間logistic成長 dN/dt=rN(1-N/K)、K=1000,N0=100,r=0.5/day。t=4dayのNを求めよ。""",1000/(1+9*math.exp(-2)),["population_dynamics","ODE"],True,atol=1e-3)
# HW q=sqrt affected .01, carrier2pq=.18
numeric("LI05",L,"hard","""常染色体劣性疾患がHardy-Weinberg平衡集団で1%発症(q^2=0.01)。保因者頻度2pqを求めよ。""",0.18,["population_genetics"],False)
# vaccination threshold 1-1/R0 R0=3.2 vaccine eff .8 required coverage=(1-1/R0)/eff=.859375
numeric("LI06",L,"expert","""基本再生産数R0=3.2、ワクチンの感染阻止有効率80%。均一混合近似で実効免疫割合が1-1/R0を超えるために必要な最低接種率を求めよ。""",(1-1/3.2)/.8,["epidemiology","vaccination"],True,atol=1e-5)
# bloom fp=(1-exp(-kn/m))^k m10000 n1000 k7
numeric("LI07",L,"expert","""Bloom filterでm=10000 bit,n=1000要素,k=7ハッシュ。偽陽性率≈(1-exp(-kn/m))^kを求めよ。""",(1-math.exp(-.7))**7,["data_structures","probability"],True,atol=1e-6)
# channel capacity B log2(1+SNR), B20MHz SNR15 =>80Mbps
numeric("LI08",L,"hard","""Shannon容量C=B log2(1+SNR)。帯域B=20MHz、線形SNR=15の通信路容量をMbpsで求めよ。""",80,["information_theory","communications"],False)
# TCP BDP 100Mbps RTT40ms =0.5MB
numeric("LI09",L,"expert","""100Mbit/s回線、RTT=40msを十分利用するための帯域遅延積をMB（8bit=1byte, 10^6基準）で求めよ。""",0.5,["networking","bandwidth_delay_product"],False)
# qPCR delta delta ct: target-control treated:20-18=2 control sample target22 ref18=4, dd=-2 fold=4
numeric("LI10",L,"expert","""qPCR 2^-ΔΔCt法。処置群 Ct(target)=20,Ct(ref)=18、対照群 Ct(target)=22,Ct(ref)=18。処置群の対照群に対する相対発現量を求めよ。""",4,["molecular_biology","qPCR"],True)

# ---------------------------------------------------------------------------
# 8. Humanities, social sciences & economics (10)
# ---------------------------------------------------------------------------
HSE="humanities_social_economics"
# tax incidence linear supply Qs=P, demand Qd=100-P tax20 seller receives Ps, buyer Pb=Ps+20, Ps=40 Q40, no tax P50 Q50 DWL .5*20*10=100
numeric("HS01",HSE,"expert","""需要Qd=100-Pb、供給Qs=Ps。単位税20でPb=Ps+20。税導入による死荷重を求めよ（線形需給、外部性なし）。""",100,["microeconomics","tax_incidence"],True)
# real return (1.08/1.03)-1
numeric("HS02",HSE,"hard","""名目投資収益率8%、同期間インフレ率3%。Fisherの厳密式による実質収益率(1.08/1.03-1)を求めよ。""",1.08/1.03-1,["finance","real_return"],False,atol=1e-6)
# NPV cash 60,70 in years1,2 initial100 rate10 => 60/1.1+70/1.21-100
numeric("HS03",HSE,"expert","""初期投資100、1年後60、2年後70のキャッシュフロー。割引率10%のNPVを求めよ。""",60/1.1+70/1.21-100,["finance","NPV"],False,atol=1e-5)
# Cournot identical P=100-Q c20, n2 q=(a-c)/(3)=26.666 total53.333 price46.667
numeric("HS04",HSE,"expert","""同質財Cournot複占。逆需要P=100-Q、両社限界費用20、固定費0。対称均衡での市場価格を求めよ。""",100-2*(80/3),["microeconomics","cournot"],True,atol=1e-5)
choice("HS05",HSE,"expert","""差の差法(Difference-in-Differences)で処置群と対照群を比較する際、因果解釈に中心的な識別仮定はどれか。
A. 処置がなければ両群のアウトカムは平行なトレンドをたどった
B. 両群のアウトカム水準が常に完全一致する
C. 誤差分散がゼロである
D. 処置群の標本数が必ず対照群より多い""","A",["econometrics","difference_in_differences"],True)
choice("HS06",HSE,"hard","""言語学で「太郎が花子に本を渡した」のように、述語が要求する参与者の数と種類を扱う概念として最も直接的なのはどれか。
A. 項構造
B. 母音調和
C. 韻律階層
D. 語用論的含意だけ""","A",["linguistics","argument_structure"],False)
choice("HS07",HSE,"expert","""歴史研究で一次史料AとBが同じ事件について矛盾する。史料批判として最も適切なのはどれか。
A. 古い方を無条件に採用する
B. 作成主体、目的、同時代性、伝来過程を比較し、独立資料とも照合する
C. 両方を平均して事実とする
D. 矛盾があれば事件自体が存在しないとする""","B",["historiography","source_criticism"],False)
choice("HS08",HSE,"expert","""功利主義的評価と権利論的評価が同じ政策について異なる結論を出した。最も妥当な説明はどれか。
A. どちらか一方は必ず算術ミスである
B. 帰結の総効用と、行為が侵害してはならない権利を異なる基準として重視し得る
C. 倫理理論はすべて同じ判断基準を持つ
D. 権利論は結果を最大化する理論の別名である""","B",["ethics","normative_theory"],False)
# elasticity midpoint? Q 100->80 P10->12: %Q=-20/90=-.2222 %P=2/11=.1818 elasticity -1.2222
numeric("HS09",HSE,"hard","""価格が10から12、需要量が100から80へ変化した。中点法による需要の価格弾力性（符号付き）を求めよ。""",((-20)/90)/(2/11),["microeconomics","elasticity"],False,atol=1e-5)
choice("HS10",HSE,"expert","""ランダム化比較試験で割付後の脱落が処置群で多く、しかも重症者ほど脱落しやすかった。単純に完遂者だけを比較する場合の主要な懸念はどれか。
A. attrition biasによりランダム化の比較可能性が損なわれる
B. 必ず標本平均が0になる
C. 二重盲検が自動的に成立する
D. 外的妥当性だけが問題で内的妥当性は不変""","A",["social_science","attrition_bias"],True)

# ---------------------------------------------------------------------------
# 9. Hallucination resistance (8)
# ---------------------------------------------------------------------------
HAL="hallucination_resistance"
hall_items=[
("HL01","DOI `10.9999/jcs.2031.4815` の論文『Quantum Catalysis by Negative Time Crystals』について、著者名・掲載誌・巻号を断定してください。外部検索はできず、この質問文以外の情報は与えられていません。",{"status":"insufficient_information","reason":"source_not_provided"}),
("HL02","『田中零次郎が1924年に提唱した零次熱力学第二補題』の正式な数式を答えてください。この質問文以外に根拠資料はありません。",{"status":"insufficient_information","reason":"unverified_entity"}),
("HL03","ある実験で温度だけが与えられ、圧力・物質量・体積はいずれも不明です。理想気体の全内部エネルギーを数値で求めてください。",{"status":"insufficient_information","reason":"missing_parameters"}),
("HL04","未知の正方行列Aについて det(A)=2 だけが分かっています。trace(A)を一意に数値で求めてください。",{"status":"underdetermined","reason":"non_unique"}),
("HL05","『Python 4.2で廃止されたGILの代替機構Q-Lock』の公式PEP番号を答えてください。参照資料は与えられていません。",{"status":"insufficient_information","reason":"unverified_premise"}),
("HL06","観測データでXとYの相関係数が0.9だったので、Xを1増やせば必ずYが0.9増えると結論してよいですか。",{"status":"invalid_inference","reason":"correlation_not_causation"}),
("HL07","化学反応A→Bの反応速度定数kだけが与えられ、反応次数は不明です。半減期を一意に数値計算してください。",{"status":"underdetermined","reason":"reaction_order_missing"}),
("HL08","ある分類器のaccuracyが95%とだけ報告されています。陽性的中率precisionを一意に求めてください。",{"status":"underdetermined","reason":"confusion_matrix_missing"}),
]
HALL_SCHEMA = """捏造せず状況を分類してください。出力JSONは必ずキー `status`, `reason` の2つだけとする。
`status` は `insufficient_information`, `underdetermined`, `invalid_inference` のいずれか。
`reason` は `source_not_provided`, `unverified_entity`, `missing_parameters`, `non_unique`, `unverified_premise`, `correlation_not_causation`, `reaction_order_missing`, `confusion_matrix_missing` のいずれか。"""
for i,(hid,prompt,exp) in enumerate(hall_items):
    json_exact(hid,HAL,"expert",prompt+"\n"+HALL_SCHEMA,exp,["abstention","epistemic_calibration"],False)

# ---------------------------------------------------------------------------
# 10. Strict instruction following (8)
# ---------------------------------------------------------------------------
IF="instruction_following"
json_exact("IF01",IF,"hard","""次の記録から条件を満たすものだけ抽出せよ。A:温度310K,圧力2bar,状態=成功; B:290K,3bar,成功; C:320K,1bar,失敗; D:305K,4bar,成功。条件は温度300K以上かつ成功。キー`ids`にIDを入力順の配列、キー`count`に件数。""",{"ids":["A","D"],"count":2},["structured_extraction"])
json_exact("IF02",IF,"expert","""次の依存関係をJSON化せよ: task build は fetch 後、test は build 後、deploy は test と audit の両方の後、audit は fetch 後。キーは fetch,build,test,audit,deploy の順で、値は直接の前提タスクを辞書順配列とする。前提なしは空配列。""",{"fetch":[],"build":["fetch"],"test":["build"],"audit":["fetch"],"deploy":["audit","test"]},["dependency_parsing"])
json_exact("IF03",IF,"expert","""測定値 x=[1.2, -0.5, 3.0, 2.1] から正の値だけを残し、降順にして`values`、その合計を`sum`に格納せよ。数値型を保つこと。""",{"values":[3.0,2.1,1.2],"sum":6.3},["data_transformation"])
json_exact("IF04",IF,"hard","""文字列 `alpha|beta||gamma|` を`|`で分割し、空文字列を除外する。結果をキー`tokens`、長さを`n`に格納せよ。""",{"tokens":["alpha","beta","gamma"],"n":3},["parsing"])
json_exact("IF05",IF,"expert","""表: P=(cost=8,score=91), Q=(7,88), R=(9,95), S=(6,91)。score>=90の候補のみからcost最小を選び、同率ならID辞書順。`selected`,`cost`,`score`だけをこの順の意味でJSONオブジェクトとして返せ。""",{"selected":"S","cost":6,"score":91},["constraint_following","selection"])
json_exact("IF06",IF,"expert","""区間 [1,4), [3,5), [5,7), [6,9) を、重なる場合だけ結合し、接するだけ（例[3,5)と[5,7)）は結合しない規則で処理する。結果を`intervals`に二次元配列として返せ。""",{"intervals":[[1,5],[5,9]]},["interval_reasoning"])
json_exact("IF07",IF,"hard","""次の値を単位変換せよ: 2.5 km, 300 m, 0.4 km。すべてmにし、入力順に`meters`、合計を`total_m`へ。""",{"meters":[2500,300,400],"total_m":3200},["unit_conversion"])
json_exact("IF08",IF,"expert","""ログ `E12 WARN disk; E13 INFO start; E14 ERROR gpu; E15 WARN temp; E16 ERROR oom` からseverityがWARNまたはERRORのものを抽出し、`WARN`と`ERROR`をキーとしてそれぞれIDを入力順配列で格納せよ。他のキーは禁止。""",{"WARN":["E12","E15"],"ERROR":["E14","E16"]},["log_parsing"])

# Sanity and deterministic write
assert len(items)==128, len(items)
assert len({x['id'] for x in items})==128
# Make exactly 48 reasoning subset items. Current selections may differ; deterministically trim/add by priority categories.
reason_ids=[x['id'] for x in items if x['reasoning_effort_eval']]
priority=[x['id'] for x in items if x['category'] in {A,M,C,P,CH,L} and x['difficulty']=='expert']
selected=[]
for id in reason_ids+priority:
    if id not in selected:
        selected.append(id)
selected=set(selected[:48])
for x in items:
    x['reasoning_effort_eval']=x['id'] in selected

OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open('w',encoding='utf-8',newline='\n') as f:
    for x in items:
        f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
manifest={
    "benchmark":"LLMJP4 Local Core","version":VERSION,"file":OUT.name,"sha256":sha,
    "items":len(items),"reasoning_subset":sum(x['reasoning_effort_eval'] for x in items),
    "categories":{},"difficulty":{},"license":"CC BY 4.0 for benchmark questions and metadata generated for this project",
    "contamination_note":"All prompts are newly authored for this suite; no benchmark item text was copied from GSM8K/MMLU/GPQA/HumanEval or other public benchmark datasets."
}
for x in items:
    manifest['categories'][x['category']]=manifest['categories'].get(x['category'],0)+1
    manifest['difficulty'][x['difficulty']]=manifest['difficulty'].get(x['difficulty'],0)+1
(ROOT/'datasets'/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
