# Audit notes for v1.3.1

v1.3.1 keeps Core v2.1.0 **bit-for-bit unchanged** and adds the separate Challenge v1.1.0 track to reduce ceiling effects observed in the v1.2.0 results.

## What changed relative to v1.2.0

1. Added `challenge_v1.1.0.jsonl`: 80 newly authored short-context items, exactly 8 per Core category.
2. Added `./run.sh challenge`, which performs setup, validation, server startup and strict preflight, then runs Challenge only. It does not rerun Core, low/high reasoning, performance probes or long-context probes.
3. Added `./run.sh core`; full mode runs both Core and Challenge.
4. Challenge resume state and reporting are independent of Core. Reports emit `challenge_summary.csv` and `track_summary.csv`.
5. Challenge hallucination-resistance prompts now contain an explicit label glossary before any model has been benchmarked on this Challenge release. This removes ambiguity from exact JSON classification.
6. Numeric parsing now preserves Unicode superscript scientific notation such as `-2.54 × 10³` and `8.18×10⁻³`.
7. Environment capture distinguishes the shell `nvcc` from the CUDA compiler recorded in the llama.cpp build's `CMakeCache.txt`, avoiding misleading toolkit metadata when multiple CUDA toolkits are installed.

## Calibration policy

Challenge difficulty is prospective, not fitted to LLM-jp or Qwen results. Once Challenge v1.1.0 is sealed, item text, expected answers and graders must not be modified based on model outcomes. A later ceiling/floor correction requires a new Challenge dataset version and separate reporting.

## Core v2.1.0 note

The existing Core inference is intentionally not invalidated. The v1.2.0 result still contains a few exact-label hallucination-classification ambiguities and one Unicode scientific-notation parsing edge case. These are documented in analysis and should not be silently rewritten into the historical Core score. Challenge v1.1.0 addresses both issues prospectively.
