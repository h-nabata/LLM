from __future__ import annotations

import ast
import json
import math
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

SAFE_IMPORTS = {"math", "statistics", "itertools", "collections", "functools", "heapq", "bisect", "operator", "re", "typing", "__future__"}
FORBIDDEN_CALLS = {"open", "exec", "eval", "compile", "__import__", "input", "breakpoint"}
FORBIDDEN_NAMES = {"os", "sys", "subprocess", "socket", "pathlib", "shutil", "ctypes", "multiprocessing"}


def extract_python_code(answer: str) -> str:
    blocks = re.findall(r"```(?:python)?\s*\n(.*?)```", answer, flags=re.DOTALL | re.IGNORECASE)
    if blocks:
        return max(blocks, key=len).strip()
    return answer.strip()


def validate_python_source(source: str) -> list[str]:
    errors: list[str] = []
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return [f"SyntaxError: {exc}"]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root not in SAFE_IMPORTS:
                    errors.append(f"forbidden import: {alias.name}")
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root not in SAFE_IMPORTS:
                errors.append(f"forbidden import: {node.module}")
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
            errors.append(f"forbidden call: {node.func.id}")
        elif isinstance(node, ast.Name) and node.id in FORBIDDEN_NAMES:
            errors.append(f"forbidden name: {node.id}")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            errors.append(f"dunder attribute is forbidden: {node.attr}")
    return sorted(set(errors))


def _limit_resources() -> None:
    try:
        import resource

        resource.setrlimit(resource.RLIMIT_CPU, (3, 3))
        memory = 512 * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1 * 1024 * 1024, 1 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        if hasattr(resource, "RLIMIT_NPROC"):
            resource.setrlimit(resource.RLIMIT_NPROC, (0, 0))
    except Exception:
        pass


def run_python_unit_tests(answer: str, grader: dict[str, Any]) -> tuple[float, bool, dict[str, Any]]:
    source = extract_python_code(answer)
    validation_errors = validate_python_source(source)
    if validation_errors:
        return 0.0, False, {"validation_errors": validation_errors}

    entrypoint = str(grader["entrypoint"])
    tests = list(grader["tests"])
    harness = r'''
import importlib.util, json, math, sys, traceback
solution_path, tests_path, entrypoint = sys.argv[1:4]
spec = importlib.util.spec_from_file_location("candidate_solution", solution_path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
fn = getattr(mod, entrypoint)
tests = json.load(open(tests_path, "r", encoding="utf-8"))
results=[]
def close(a,b,atol,rtol):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        return math.isclose(float(a),float(b),abs_tol=atol,rel_tol=rtol)
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return all(close(x,y,atol,rtol) for x,y in zip(a,b))
    if isinstance(a,tuple) and isinstance(b,(list,tuple)) and len(a)==len(b):
        return all(close(x,y,atol,rtol) for x,y in zip(a,b))
    if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():
        return all(close(a[k],b[k],atol,rtol) for k in a)
    return a==b
for i,t in enumerate(tests):
    try:
        got = fn(*t.get("args", []), **t.get("kwargs", {}))
        exp = t.get("expected")
        ok = close(got, exp, float(t.get("atol",1e-9)), float(t.get("rtol",1e-9)))
        results.append({"index":i,"ok":ok,"got":repr(got)[:500],"expected":repr(exp)[:500]})
    except Exception as e:
        results.append({"index":i,"ok":False,"error":f"{type(e).__name__}: {e}"})
print(json.dumps(results, ensure_ascii=False))
'''
    with tempfile.TemporaryDirectory(prefix="llmbench_code_") as tmp:
        tmp_path = Path(tmp)
        solution = tmp_path / "solution.py"
        tests_file = tmp_path / "tests.json"
        runner = tmp_path / "runner.py"
        solution.write_text(source, encoding="utf-8")
        tests_file.write_text(json.dumps(tests, ensure_ascii=False), encoding="utf-8")
        runner.write_text(harness, encoding="utf-8")
        try:
            proc = subprocess.run(
                [sys.executable, "-I", str(runner), str(solution), str(tests_file), entrypoint],
                cwd=tmp,
                env={"PATH": os.environ.get("PATH", ""), "PYTHONIOENCODING": "utf-8"},
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=float(grader.get("timeout_s", 5.0)),
                preexec_fn=_limit_resources if os.name == "posix" else None,
            )
        except subprocess.TimeoutExpired:
            return 0.0, False, {"error": "timeout"}
        if proc.returncode != 0:
            return 0.0, False, {"error": "runner_failed", "stderr": proc.stderr[-2000:]}
        try:
            results = json.loads(proc.stdout.strip().splitlines()[-1])
        except Exception:
            return 0.0, False, {"error": "invalid_runner_output", "stdout": proc.stdout[-2000:]}
    passed_count = sum(1 for r in results if r.get("ok"))
    score = passed_count / len(results) if results else 0.0
    return score, score == 1.0, {"passed_tests": passed_count, "total_tests": len(results), "tests": results}
