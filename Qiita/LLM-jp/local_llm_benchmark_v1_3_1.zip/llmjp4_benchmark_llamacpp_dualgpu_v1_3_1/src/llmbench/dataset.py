from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from llmbench.io_utils import iter_jsonl
from llmbench.types import BenchmarkSample

ALLOWED_DIFFICULTIES = {"hard", "expert", "challenge"}
ALLOWED_GRADERS = {"exact", "normalized_exact", "choice", "numeric", "regex", "json_exact", "json_fields", "python_unit_test"}


def load_dataset(path: Path) -> list[BenchmarkSample]:
    samples: list[BenchmarkSample] = []
    seen: set[str] = set()
    for row in iter_jsonl(path):
        sample = _parse_sample(row)
        if sample.id in seen:
            raise ValueError(f"Duplicate sample id: {sample.id}")
        seen.add(sample.id)
        samples.append(sample)
    if not samples:
        raise ValueError(f"Dataset is empty: {path}")
    return samples


def validate_dataset(path: Path) -> dict[str, Any]:
    samples = load_dataset(path)
    categories = Counter(s.category for s in samples)
    difficulties = Counter(s.difficulty for s in samples)
    graders = Counter(str(s.grader.get("type", "normalized_exact")) for s in samples)
    reasoning = sum(s.reasoning_effort_eval for s in samples)
    return {
        "items": len(samples),
        "categories": dict(sorted(categories.items())),
        "difficulties": dict(sorted(difficulties.items())),
        "graders": dict(sorted(graders.items())),
        "reasoning_subset": reasoning,
    }


def _parse_sample(row: dict[str, Any]) -> BenchmarkSample:
    required = ["id", "category", "difficulty", "prompt", "grader"]
    missing = [k for k in required if k not in row]
    if missing:
        raise ValueError(f"Missing required fields {missing} in sample {row.get('id', '<unknown>')}")
    difficulty = str(row["difficulty"])
    if difficulty not in ALLOWED_DIFFICULTIES:
        raise ValueError(f"Invalid difficulty {difficulty!r} for {row['id']}")
    grader = row["grader"]
    if not isinstance(grader, dict):
        raise ValueError(f"grader must be object for {row['id']}")
    grader_type = str(grader.get("type", "normalized_exact"))
    if grader_type not in ALLOWED_GRADERS:
        raise ValueError(f"Unsupported grader type {grader_type!r} for {row['id']}")
    if grader_type == "python_unit_test":
        if not grader.get("entrypoint") or not isinstance(grader.get("tests"), list):
            raise ValueError(f"python_unit_test grader requires entrypoint/tests for {row['id']}")
    return BenchmarkSample(
        id=str(row["id"]),
        category=str(row["category"]),
        difficulty=difficulty,  # type: ignore[arg-type]
        prompt=str(row["prompt"]),
        grader=grader,
        system_prompt=None if row.get("system_prompt") is None else str(row["system_prompt"]),
        tags=tuple(str(x) for x in row.get("tags", [])),
        reasoning_effort_eval=bool(row.get("reasoning_effort_eval", False)),
        metadata=dict(row.get("metadata", {})),
    )
