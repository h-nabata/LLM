from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from llmbench.backends.llama_cpp import LlamaCppBackend
from llmbench.runner import run_benchmark
from llmbench.types import GenerationConfig

DEFAULT_MODEL = "llm-jp-4-33b-thinking-Q4_K_M"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Reproducible local-LLM benchmark runner (llama.cpp backend)")
    parser.add_argument("--url", default="http://127.0.0.1:8080")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--reasoning-effort", choices=["none", "low", "medium", "high"], default="medium")
    parser.add_argument("--context", type=int, default=8192)
    parser.add_argument("--server-context", type=int, default=8192)
    parser.add_argument("--max-tokens", type=int, default=2048)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--top-p", type=float, default=1.0)
    parser.add_argument("--top-k", type=int, default=0)
    parser.add_argument("--min-p", type=float, default=0.0)
    parser.add_argument("--repeat-penalty", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--timeout", type=float, default=1200.0)
    parser.add_argument("--monitor-interval", type=float, default=0.2)
    parser.add_argument("--only-reasoning-subset", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    args.run_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[logging.FileHandler(args.run_dir / "benchmark.log", encoding="utf-8"), logging.StreamHandler()],
    )
    reasoning = None if args.reasoning_effort == "none" else args.reasoning_effort
    generation = GenerationConfig(
        max_tokens=args.max_tokens,
        context_size=args.context,
        temperature=args.temperature,
        top_p=args.top_p,
        top_k=args.top_k,
        min_p=args.min_p,
        repeat_penalty=args.repeat_penalty,
        seed=args.seed,
        reasoning_effort=reasoning,  # type: ignore[arg-type]
    )
    backend = LlamaCppBackend(args.url, args.model, timeout_s=args.timeout, server_context=args.server_context)
    summary = run_benchmark(
        backend=backend,
        dataset_path=args.dataset,
        run_dir=args.run_dir,
        generation=generation,
        model_name=args.model,
        backend_name="llama.cpp",
        backend_url=args.url,
        monitor_interval_s=args.monitor_interval,
        only_reasoning_subset=args.only_reasoning_subset,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 1 if summary.get("errors", 0) else 0


if __name__ == "__main__":
    raise SystemExit(main())
