from __future__ import annotations

import csv
import io
import math
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any

import psutil

from llmbench.io_utils import append_jsonl


NVIDIA_FIELDS = [
    "index",
    "name",
    "utilization.gpu",
    "memory.used",
    "memory.total",
    "power.draw",
    "temperature.gpu",
]


@dataclass
class HardwareMonitor:
    output_path: Path
    interval_s: float = 0.2

    def __post_init__(self) -> None:
        if self.interval_s <= 0:
            raise ValueError("interval_s must be > 0")
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._active_label: str | None = None
        self._samples: dict[str, list[dict[str, Any]]] = {}
        self._nvidia_smi = shutil.which("nvidia-smi")

    def start(self) -> None:
        if self._thread is not None:
            return
        psutil.cpu_percent(interval=None)
        self._thread = threading.Thread(target=self._loop, name="hardware-monitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=max(2.0, self.interval_s * 4))
            self._thread = None

    def set_active_label(self, label: str | None) -> None:
        with self._lock:
            self._active_label = label
            if label is not None:
                self._samples.setdefault(label, [])

    def summarize(self, label: str) -> dict[str, Any]:
        with self._lock:
            samples = list(self._samples.get(label, []))
        return summarize_hardware_samples(samples)

    def _loop(self) -> None:
        next_tick = time.perf_counter()
        while not self._stop_event.is_set():
            next_tick += self.interval_s
            sample = self._sample_once()
            with self._lock:
                label = self._active_label
                sample["label"] = label
                if label is not None:
                    self._samples.setdefault(label, []).append(sample)
            append_jsonl(self.output_path, sample)
            remaining = next_tick - time.perf_counter()
            if remaining > 0:
                self._stop_event.wait(remaining)

    def _sample_once(self) -> dict[str, Any]:
        vm = psutil.virtual_memory()
        row: dict[str, Any] = {
            "timestamp_unix": time.time(),
            "monotonic_s": time.perf_counter(),
            "cpu_percent": psutil.cpu_percent(interval=None),
            "ram_used_bytes": int(vm.used),
            "ram_percent": float(vm.percent),
            "gpus": self._sample_gpus(),
        }
        return row

    def _sample_gpus(self) -> list[dict[str, Any]]:
        if self._nvidia_smi is None:
            return []
        query = ",".join(NVIDIA_FIELDS)
        try:
            proc = subprocess.run(
                [self._nvidia_smi, f"--query-gpu={query}", "--format=csv,noheader,nounits"],
                check=True,
                capture_output=True,
                text=True,
                timeout=2.0,
            )
        except (subprocess.SubprocessError, OSError):
            return []

        parsed: list[dict[str, Any]] = []
        reader = csv.reader(io.StringIO(proc.stdout))
        for values in reader:
            if len(values) != len(NVIDIA_FIELDS):
                continue
            clean = [v.strip() for v in values]
            parsed.append(
                {
                    "index": _to_int(clean[0]),
                    "name": clean[1],
                    "utilization_gpu_percent": _to_float(clean[2]),
                    "memory_used_mib": _to_float(clean[3]),
                    "memory_total_mib": _to_float(clean[4]),
                    "power_draw_w": _to_float(clean[5]),
                    "temperature_c": _to_float(clean[6]),
                }
            )
        return parsed


def summarize_hardware_samples(samples: list[dict[str, Any]]) -> dict[str, Any]:
    if not samples:
        return {"sample_count": 0}

    summary: dict[str, Any] = {
        "sample_count": len(samples),
        "cpu_percent_mean": _mean_present(s.get("cpu_percent") for s in samples),
        "cpu_percent_max": _max_present(s.get("cpu_percent") for s in samples),
        "ram_used_bytes_mean": _mean_present(s.get("ram_used_bytes") for s in samples),
        "ram_used_bytes_max": _max_present(s.get("ram_used_bytes") for s in samples),
    }

    gpu_indices = sorted(
        {
            int(g["index"])
            for s in samples
            for g in s.get("gpus", [])
            if g.get("index") is not None
        }
    )
    gpu_summaries: list[dict[str, Any]] = []
    for idx in gpu_indices:
        gpu_rows = [
            g
            for s in samples
            for g in s.get("gpus", [])
            if g.get("index") == idx
        ]
        if not gpu_rows:
            continue
        power_values = [g.get("power_draw_w") for g in gpu_rows]
        energy_j = _integrate_gpu_energy(samples, idx)
        gpu_summaries.append(
            {
                "index": idx,
                "name": gpu_rows[0].get("name"),
                "utilization_gpu_percent_mean": _mean_present(g.get("utilization_gpu_percent") for g in gpu_rows),
                "utilization_gpu_percent_max": _max_present(g.get("utilization_gpu_percent") for g in gpu_rows),
                "memory_used_mib_mean": _mean_present(g.get("memory_used_mib") for g in gpu_rows),
                "memory_used_mib_max": _max_present(g.get("memory_used_mib") for g in gpu_rows),
                "power_draw_w_mean": _mean_present(power_values),
                "power_draw_w_max": _max_present(power_values),
                "temperature_c_mean": _mean_present(g.get("temperature_c") for g in gpu_rows),
                "temperature_c_max": _max_present(g.get("temperature_c") for g in gpu_rows),
                "energy_j_estimate": energy_j,
            }
        )
    summary["gpus"] = gpu_summaries
    summary["gpu_energy_j_total_estimate"] = sum(
        x["energy_j_estimate"] for x in gpu_summaries if isinstance(x.get("energy_j_estimate"), (int, float))
    )
    return summary


def _integrate_gpu_energy(samples: list[dict[str, Any]], index: int) -> float | None:
    points: list[tuple[float, float]] = []
    for sample in samples:
        t = sample.get("monotonic_s")
        if not isinstance(t, (int, float)):
            continue
        for gpu in sample.get("gpus", []):
            if gpu.get("index") == index and isinstance(gpu.get("power_draw_w"), (int, float)):
                points.append((float(t), float(gpu["power_draw_w"])))
                break
    if len(points) < 2:
        return None
    energy = 0.0
    for (t0, p0), (t1, p1) in zip(points, points[1:]):
        dt = max(0.0, t1 - t0)
        energy += 0.5 * (p0 + p1) * dt
    return energy


def _mean_present(values: Any) -> float | None:
    vals = [float(v) for v in values if isinstance(v, (int, float)) and math.isfinite(float(v))]
    return None if not vals else mean(vals)


def _max_present(values: Any) -> float | None:
    vals = [float(v) for v in values if isinstance(v, (int, float)) and math.isfinite(float(v))]
    return None if not vals else max(vals)


def _to_float(value: str) -> float | None:
    try:
        return float(value)
    except ValueError:
        return None


def _to_int(value: str) -> int | None:
    try:
        return int(value)
    except ValueError:
        return None
