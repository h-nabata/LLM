from __future__ import annotations

import dataclasses
import logging
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from llmbench.backends.base import InferenceBackend
from llmbench.dataset import load_dataset
from llmbench.environment import capture_environment
from llmbench.hardware_monitor import HardwareMonitor
from llmbench.io_utils import append_jsonl, completed_sample_keys, sha256_file, write_json_atomic
from llmbench.scoring import score_answer
from llmbench.types import GenerationConfig, InferenceRequest

LOGGER = logging.getLogger(__name__)


def classify_error(exc: Exception) -> str:
    text = f"{type(exc).__name__}: {exc}".lower()
    if any(k in text for k in ["out of memory", "oom", "memory allocation", "not enough memory", "cuda error"]):
        return "resource_limit"
    if any(k in text for k in ["timeout", "timed out"]):
        return "timeout"
    if any(k in text for k in ["connection", "503", "502", "server"]):
        return "backend_error"
    return "inference_error"


def run_benchmark(
    backend: InferenceBackend,
    dataset_path: Path,
    run_dir: Path,
    generation: GenerationConfig,
    model_name: str,
    backend_name: str = "llama.cpp",
    backend_url: str | None = None,
    monitor_interval_s: float = 0.2,
    only_reasoning_subset: bool = False,
) -> dict[str, Any]:
    run_dir.mkdir(parents=True, exist_ok=True)
    result_path = run_dir / "results.jsonl"
    hardware_path = run_dir / "hardware_samples.jsonl"
    environment_path = run_dir / "environment.json"

    if not environment_path.exists():
        env = capture_environment()
        env["experiment"] = {
            "model_name": model_name,
            "backend": backend_name,
            "backend_url": backend_url,
            "dataset": str(dataset_path.resolve()),
            "dataset_sha256": sha256_file(dataset_path),
            "generation": dataclasses.asdict(generation),
            "monitor_interval_s": monitor_interval_s,
        }
        write_json_atomic(environment_path, env)

    dataset_sha256 = sha256_file(dataset_path)
    samples = load_dataset(dataset_path)
    if only_reasoning_subset:
        samples = [s for s in samples if s.reasoning_effort_eval]
        if not samples:
            raise ValueError("No samples marked reasoning_effort_eval=true")

    completed = completed_sample_keys(result_path)
    monitor = HardwareMonitor(hardware_path, interval_s=monitor_interval_s)
    monitor.start()
    attempted = skipped = ok = errors = 0
    try:
        for sample in samples:
            effort_key = generation.reasoning_effort or "none"
            run_key = f"{sample.id}::ds{dataset_sha256[:12]}::{effort_key}::ctx{generation.context_size}::seed{generation.seed}"
            if run_key in completed:
                skipped += 1
                continue
            attempted += 1
            monitor.set_active_label(run_key)
            try:
                messages: list[dict[str, str]] = []
                if sample.system_prompt:
                    messages.append({"role": "system", "content": sample.system_prompt})
                messages.append({"role": "user", "content": sample.prompt})
                inference = backend.generate(InferenceRequest(sample_id=sample.id, messages=messages, generation=generation))
                scoring = score_answer(inference.content, sample.grader)
                row: dict[str, Any] = {
                    "schema_version": "1.0.0",
                    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                    "status": "ok",
                    "run_key": run_key,
                    "sample": {
                        "id": sample.id,
                        "category": sample.category,
                        "difficulty": sample.difficulty,
                        "tags": list(sample.tags),
                        "reasoning_effort_eval": sample.reasoning_effort_eval,
                    },
                    "prompt": sample.prompt,
                    "system_prompt": sample.system_prompt,
                    "expected": sample.grader.get("expected"),
                    "grader": sample.grader,
                    "generation": dataclasses.asdict(generation),
                    "response": {
                        "reasoning": inference.reasoning_content,
                        "final_answer": inference.content,
                        "finish_reason": inference.finish_reason,
                    },
                    "metrics": {
                        "wall_time_s": inference.wall_time_s,
                        "ttft_s": inference.ttft_s,
                        "load_time_s": inference.load_time_s,
                        "backend_total_time_s": inference.backend_total_time_s,
                        "prompt_tokens": inference.prompt_tokens,
                        "completion_tokens": inference.completion_tokens,
                        "total_tokens": inference.total_tokens,
                        "reasoning_tokens_estimate": inference.reasoning_tokens_estimate,
                        "answer_tokens_estimate": inference.answer_tokens_estimate,
                        "prompt_tokens_per_s": inference.prompt_tokens_per_s,
                        "completion_tokens_per_s": inference.completion_tokens_per_s,
                        "prompt_ms": inference.prompt_ms,
                        "predicted_ms": inference.predicted_ms,
                    },
                    "score": dataclasses.asdict(scoring),
                    "hardware": monitor.summarize(run_key),
                    "backend_metadata": inference.raw_metadata,
                }
                append_jsonl(result_path, row)
                ok += 1
            except Exception as exc:
                LOGGER.exception("Sample %s failed", sample.id)
                append_jsonl(result_path, {
                    "schema_version": "1.0.0",
                    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                    "status": "error",
                    "error_class": classify_error(exc),
                    "run_key": run_key,
                    "sample": {"id": sample.id, "category": sample.category, "difficulty": sample.difficulty},
                    "generation": dataclasses.asdict(generation),
                    "error": {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()},
                    "hardware": monitor.summarize(run_key),
                })
                errors += 1
            finally:
                monitor.set_active_label(None)
    finally:
        monitor.stop()

    summary = {
        "schema_version": "1.0.0",
        "attempted": attempted,
        "ok": ok,
        "errors": errors,
        "skipped_existing": skipped,
        "total_selected": len(samples),
        "result_path": str(result_path),
    }
    write_json_atomic(run_dir / "run_summary.json", summary)
    return summary
