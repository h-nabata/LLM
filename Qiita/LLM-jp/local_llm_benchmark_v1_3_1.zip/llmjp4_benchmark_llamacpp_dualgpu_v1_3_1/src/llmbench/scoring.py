from __future__ import annotations

import json
import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

from llmbench.code_grader import run_python_unit_tests


@dataclass(frozen=True)
class ScoreResult:
    score: float
    passed: bool
    method: str
    details: dict[str, Any]


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).strip().casefold()
    text = re.sub(r"\s+", "", text)
    text = re.sub(r"[。．.、,，!！?？]+$", "", text)
    return text


def _strip_json_fence(text: str) -> str:
    m = re.search(r"```(?:json)?\s*\n(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    return (m.group(1) if m else text).strip()


def score_answer(answer: str, grader: dict[str, Any]) -> ScoreResult:
    method = str(grader.get("type", "normalized_exact"))
    expected = grader.get("expected")

    if method == "exact":
        passed = answer.strip() == str(expected)
        return ScoreResult(float(passed), passed, method, {"expected": expected})

    if method == "normalized_exact":
        got = normalize_text(answer)
        exp = normalize_text(str(expected))
        passed = got == exp
        return ScoreResult(float(passed), passed, method, {"expected": expected, "normalized": got})

    if method == "choice":
        allowed = [str(x) for x in grader.get("choices", [])]
        if not allowed:
            raise ValueError("choice grader requires non-empty 'choices'")
        normalized = unicodedata.normalize("NFKC", answer)
        found: list[str] = []
        for choice in allowed:
            pattern = rf"(?<![A-Za-z0-9]){re.escape(choice)}(?![A-Za-z0-9])"
            if re.search(pattern, normalized, flags=re.IGNORECASE):
                found.append(choice)
        unique = sorted(set(found))
        passed = len(unique) == 1 and normalize_text(unique[0]) == normalize_text(str(expected))
        return ScoreResult(float(passed), passed, method, {"expected": expected, "found_choices": unique})

    if method == "numeric":
        target = float(expected)
        atol = float(grader.get("atol", 1e-9))
        rtol = float(grader.get("rtol", 1e-9))
        value = _extract_final_number(answer)
        passed = value is not None and math.isclose(value, target, rel_tol=rtol, abs_tol=atol)
        return ScoreResult(float(passed), passed, method, {"expected": target, "parsed": value, "atol": atol, "rtol": rtol})

    if method == "regex":
        pattern = str(grader["pattern"])
        flags = re.IGNORECASE if grader.get("ignore_case", False) else 0
        passed = re.fullmatch(pattern, answer.strip(), flags=flags) is not None
        return ScoreResult(float(passed), passed, method, {"pattern": pattern})

    if method in {"json_exact", "json_fields"}:
        try:
            got_obj = json.loads(_strip_json_fence(answer))
            if method == "json_exact":
                passed = got_obj == expected
            else:
                passed = isinstance(got_obj, dict) and isinstance(expected, dict) and all(got_obj.get(k) == v for k, v in expected.items())
                if not grader.get("allow_extra", False) and isinstance(got_obj, dict) and isinstance(expected, dict):
                    passed = passed and set(got_obj) == set(expected)
            details: dict[str, Any] = {"expected": expected, "parsed": got_obj}
        except json.JSONDecodeError as exc:
            passed = False
            details = {"expected": expected, "error": str(exc)}
        return ScoreResult(float(passed), passed, method, details)

    if method == "python_unit_test":
        score, passed, details = run_python_unit_tests(answer, grader)
        return ScoreResult(score, passed, method, details)

    raise ValueError(f"Unsupported grader type: {method}")


def _parse_numeric_prefix(text: str) -> float | None:
    """Parse a conservative numeric expression at the start of *text*.

    Accepted forms are a decimal/scientific literal, a simple fraction such as
    ``8/3``, or scientific notation written as ``-2.54×10^3``.  This is not an
    expression evaluator and intentionally rejects arbitrary arithmetic.
    """
    s = text.strip()
    sci = re.match(
        r"^([-+]?(?:\d+(?:\.\d*)?|\.\d+))\s*[×xX*]\s*10\s*\^\s*\{?\s*([-+]?\d+)\s*\}?",
        s,
    )
    if sci:
        return float(sci.group(1)) * (10.0 ** int(sci.group(2)))
    frac = re.match(
        r"^([-+]?(?:\d+(?:\.\d*)?|\.\d+))\s*/\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+))",
        s,
    )
    if frac:
        den = float(frac.group(2))
        return None if den == 0 else float(frac.group(1)) / den
    num = re.match(r"^([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)", s)
    return float(num.group(1)) if num else None


def _normalize_superscript_exponents(text: str) -> str:
    """Convert Unicode superscript exponent notation (e.g. 10³, 10⁻³) to 10^3/10^-3."""
    trans = str.maketrans({
        "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
        "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
        "⁺": "+", "⁻": "-",
    })
    pattern = re.compile(r"10([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)")
    return pattern.sub(lambda m: "10^" + m.group(1).translate(trans), text)


def _extract_final_number(text: str) -> float | None:
    # Normalize superscripts before NFKC; NFKC would otherwise turn 10³ into 103
    # and lose the fact that 3 was an exponent.
    text = _normalize_superscript_exponents(text)
    normalized = unicodedata.normalize("NFKC", text).replace(",", "")
    # Prefer an explicitly requested final-answer line. Units after the number
    # are harmless and ignored.
    m = re.search(r"(?:FINAL|最終回答|答え)\s*[:：]\s*(.+)", normalized, flags=re.IGNORECASE)
    if m:
        return _parse_numeric_prefix(m.group(1))
    # Without a marker, accept only when the whole answer begins with one
    # numeric expression and contains no second independent numeric literal.
    value = _parse_numeric_prefix(normalized)
    if value is None:
        return None
    numeric_literals = re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", normalized)
    # Fractions/scientific x10 notation legitimately contain two literals.
    if re.match(r"^\s*[-+]?(?:\d+(?:\.\d*)?|\.\d+)\s*/", normalized) or re.match(
        r"^\s*[-+]?(?:\d+(?:\.\d*)?|\.\d+)\s*[×xX*]\s*10\s*\^", normalized
    ):
        return value
    return value if len(numeric_literals) == 1 else None
