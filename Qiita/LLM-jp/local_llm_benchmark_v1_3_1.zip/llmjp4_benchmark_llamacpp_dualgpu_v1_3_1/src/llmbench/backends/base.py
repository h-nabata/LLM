from __future__ import annotations

from abc import ABC, abstractmethod

from llmbench.types import InferenceRequest, InferenceResult


class InferenceBackend(ABC):
    """Backend-neutral inference interface."""

    @abstractmethod
    def generate(self, request: InferenceRequest) -> InferenceResult:
        raise NotImplementedError
