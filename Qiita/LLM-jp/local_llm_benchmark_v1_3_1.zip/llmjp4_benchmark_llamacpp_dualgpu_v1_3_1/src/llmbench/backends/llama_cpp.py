from __future__ import annotations

import time
from typing import Any

import requests

from llmbench.backends.base import InferenceBackend
from llmbench.types import InferenceRequest, InferenceResult


class LlamaCppBackend(InferenceBackend):
    """llama-server OpenAI-compatible /v1/chat/completions backend.

    The canonical benchmark uses non-streaming responses because llama.cpp returns
    authoritative prompt/decode timings in the final JSON object. Prefix-cache reuse
    is disabled per request to prevent repeated benchmark prompts from receiving an
    unfair prompt-processing advantage.
    """

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8080",
        model_name: str = "llm-jp-4-33b-thinking-Q4_K_M",
        timeout_s: float = 1200.0,
        server_context: int = 8192,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model_name = model_name
        self.timeout_s = timeout_s
        self.server_context = server_context
        self.session = requests.Session()

    def count_chat_tokens(self, messages: list[dict[str, str]], reasoning_effort: str | None = None) -> int:
        """Count input tokens after chat-template application without inference.

        Newer llama-server builds expose /v1/chat/completions/input_tokens.
        A conservative /apply-template -> /tokenize fallback keeps the benchmark
        usable with forks that do not expose the convenience endpoint.
        """
        payload: dict[str, Any] = {"model": self.model_name, "messages": messages}
        if reasoning_effort is not None:
            payload["chat_template_kwargs"] = {"reasoning_effort": reasoning_effort}
        try:
            r = self.session.post(
                f"{self.base_url}/v1/chat/completions/input_tokens", json=payload, timeout=(10.0, 60.0)
            )
            if r.ok:
                data = r.json()
                n = _as_int(data.get("input_tokens")) if isinstance(data, dict) else None
                if n is not None and n > 0:
                    return n
        except requests.RequestException:
            pass

        templ = self.session.post(
            f"{self.base_url}/apply-template", json=payload, timeout=(10.0, 60.0)
        )
        templ.raise_for_status()
        tdata = templ.json()
        prompt = tdata.get("prompt") if isinstance(tdata, dict) else None
        if not isinstance(prompt, str):
            raise RuntimeError("llama-server token-count fallback returned no templated prompt")
        tok = self.session.post(
            f"{self.base_url}/tokenize", json={"content": prompt, "add_special": False}, timeout=(10.0, 60.0)
        )
        tok.raise_for_status()
        data = tok.json()
        tokens = data.get("tokens") if isinstance(data, dict) else None
        if not isinstance(tokens, list):
            raise RuntimeError("llama-server /tokenize returned no token list")
        return len(tokens)

    def generate(self, request: InferenceRequest) -> InferenceResult:
        g = request.generation
        if g.context_size > self.server_context:
            raise ValueError(
                f"Request context {g.context_size} exceeds fixed llama-server context {self.server_context}; "
                "restart the server with a larger --ctx-size for a separate profile."
            )

        payload: dict[str, Any] = {
            "messages": request.messages,
            "stream": False,
            "max_tokens": g.max_tokens,
            "temperature": g.temperature,
            "top_p": g.top_p,
            "top_k": g.top_k,
            "min_p": g.min_p,
            "repeat_penalty": g.repeat_penalty,
            "seed": g.seed,
            # llama.cpp-specific extension supported by the chat endpoint.
            # This is deliberately false for benchmark reproducibility.
            "cache_prompt": False,
        }
        if g.reasoning_effort is not None:
            # LLM-jp-4's Jinja template reads reasoning_effort. Supplying the
            # template kwarg explicitly avoids relying on backend-generic effort semantics.
            payload["chat_template_kwargs"] = {"reasoning_effort": g.reasoning_effort}

        started = time.perf_counter()
        response = self.session.post(
            f"{self.base_url}/v1/chat/completions",
            json=payload,
            timeout=(10.0, self.timeout_s),
        )
        response.raise_for_status()
        ended = time.perf_counter()
        data = response.json()
        if not isinstance(data, dict):
            raise RuntimeError("llama-server returned a non-object JSON response")

        choices = data.get("choices")
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
            raise RuntimeError(f"llama-server response has no valid choices[0]: {data!r}")
        choice = choices[0]
        message = choice.get("message") or {}
        if not isinstance(message, dict):
            message = {}

        content = message.get("content")
        reasoning = message.get("reasoning_content")
        content = content if isinstance(content, str) else ""
        reasoning = reasoning if isinstance(reasoning, str) and reasoning else None

        usage = data.get("usage") or {}
        timings = data.get("timings") or {}
        prompt_details = usage.get("prompt_tokens_details") or {} if isinstance(usage, dict) else {}
        prompt_tokens = _as_int(usage.get("prompt_tokens")) if isinstance(usage, dict) else None
        completion_tokens = _as_int(usage.get("completion_tokens")) if isinstance(usage, dict) else None
        total_tokens = _as_int(usage.get("total_tokens")) if isinstance(usage, dict) else None
        cached_tokens = _as_int(prompt_details.get("cached_tokens")) if isinstance(prompt_details, dict) else None

        prompt_ms = _as_float(timings.get("prompt_ms")) if isinstance(timings, dict) else None
        predicted_ms = _as_float(timings.get("predicted_ms")) if isinstance(timings, dict) else None
        prompt_tps = _as_float(timings.get("prompt_per_second")) if isinstance(timings, dict) else None
        completion_tps = _as_float(timings.get("predicted_per_second")) if isinstance(timings, dict) else None

        return InferenceResult(
            content=content,
            reasoning_content=reasoning,
            wall_time_s=ended - started,
            # Non-streaming canonical path: do not pretend wall time or prompt time is TTFT.
            ttft_s=None,
            load_time_s=None,
            backend_total_time_s=None,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            prompt_tokens_per_s=prompt_tps,
            completion_tokens_per_s=completion_tps,
            prompt_ms=prompt_ms,
            predicted_ms=predicted_ms,
            reasoning_tokens_estimate=None,
            answer_tokens_estimate=None,
            finish_reason=_as_str(choice.get("finish_reason")),
            raw_metadata={
                "llama_cpp": {
                    "model": data.get("model"),
                    "system_fingerprint": data.get("system_fingerprint"),
                    "created": data.get("created"),
                    "cached_prompt_tokens": cached_tokens,
                    "thinking_chars": 0 if reasoning is None else len(reasoning),
                    "answer_chars": len(content),
                    "timings": timings,
                    "usage": usage,
                    "cache_prompt_requested": False,
                    "reasoning_effort": g.reasoning_effort,
                }
            },
        )


def _as_int(value: Any) -> int | None:
    try:
        return None if value is None else int(value)
    except (TypeError, ValueError):
        return None


def _as_float(value: Any) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def _as_str(value: Any) -> str | None:
    return None if value is None else str(value)
