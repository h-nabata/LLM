from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import psutil

from llmbench.io_utils import sha256_file


def capture_environment(
    model_file: Path | None = None,
    declared_model_sha256: str | None = None,
    verify_model_hash: bool = False,
    llama_server_bin: str | None = None,
    llama_repo: Path | None = None,
) -> dict[str, Any]:
    env: dict[str, Any] = {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "command_line": sys.argv,
        "cwd": os.getcwd(),
        "os": {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "wsl_distro_name": os.environ.get("WSL_DISTRO_NAME"),
            "wsl_interop": bool(os.environ.get("WSL_INTEROP")),
        },
        "python": {"version": platform.python_version(), "executable": sys.executable},
        "cpu": {
            "model": _cpu_model(),
            "logical_cores": psutil.cpu_count(logical=True),
            "physical_cores": psutil.cpu_count(logical=False),
        },
        "ram": {"total_bytes": int(psutil.virtual_memory().total)},
        "nvidia": _nvidia_environment(),
        # shell_nvcc is informational only; it can differ from the compiler used to build llama.cpp.
        "shell_nvcc": _command_output(["nvcc", "--version"]),
        "llama_cpp": _llama_environment(llama_server_bin, llama_repo),
        "relevant_environment_variables": {
            key: os.environ.get(key)
            for key in ["CUDA_VISIBLE_DEVICES", "GGML_CUDA_DISABLE_GRAPHS"]
        },
        "model": {
            "path": None if model_file is None else str(model_file.resolve()),
            "filename": None if model_file is None else model_file.name,
            "size_bytes": None if model_file is None or not model_file.exists() else model_file.stat().st_size,
            "declared_sha256": declared_model_sha256,
            "verified_sha256": None,
        },
    }
    if verify_model_hash and model_file is not None and model_file.exists():
        env["model"]["verified_sha256"] = sha256_file(model_file)
    return env


def _cpu_model() -> str:
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        for line in cpuinfo.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.lower().startswith("model name") and ":" in line:
                return line.split(":", 1)[1].strip()
    return platform.processor() or "unknown"


def _nvidia_environment() -> dict[str, Any]:
    exe = shutil.which("nvidia-smi")
    if exe is None:
        return {"available": False, "gpus": []}
    fields = "index,name,uuid,memory.total,pci.bus_id,driver_version"
    try:
        proc = subprocess.run(
            [exe, f"--query-gpu={fields}", "--format=csv,noheader,nounits"],
            check=True, capture_output=True, text=True, timeout=5.0,
        )
        rows = []
        for line in proc.stdout.splitlines():
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 6:
                rows.append({
                    "index": parts[0], "name": parts[1], "uuid": parts[2],
                    "memory_total_mib": parts[3], "pci_bus_id": parts[4], "driver_version": parts[5],
                })
        return {"available": True, "gpus": rows, "raw": _command_output([exe])}
    except (subprocess.SubprocessError, OSError) as exc:
        return {"available": False, "error": str(exc), "gpus": []}


def _llama_environment(llama_server_bin: str | None, llama_repo: Path | None) -> dict[str, Any]:
    binary = llama_server_bin
    build_cuda_compiler = None
    build_cuda_toolkit = None
    cmake_cache = None
    if binary:
        try:
            bpath = Path(binary).expanduser().resolve()
            # Typical layout: <repo>/<build-dir>/bin/llama-server
            candidate = bpath.parent.parent / "CMakeCache.txt"
            if candidate.exists():
                cmake_cache = str(candidate)
                for line in candidate.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.startswith("CMAKE_CUDA_COMPILER:") and "=" in line:
                        build_cuda_compiler = line.split("=", 1)[1].strip()
                        break
                if build_cuda_compiler:
                    build_cuda_toolkit = _command_output([build_cuda_compiler, "--version"])
        except Exception:
            pass
    result: dict[str, Any] = {
        "server_binary": binary,
        "version_output": None if binary is None else _command_output([binary, "--version"]),
        "list_devices_output": None if binary is None else _command_output([binary, "--list-devices"]),
        "repo": None if llama_repo is None else str(llama_repo.resolve()),
        "git_commit": None,
        "git_status_porcelain": None,
        "cmake_cache": cmake_cache,
        "build_cuda_compiler": build_cuda_compiler,
        "build_cuda_toolkit": build_cuda_toolkit,
    }
    if llama_repo is not None and llama_repo.exists():
        result["git_commit"] = _command_output(["git", "-C", str(llama_repo), "rev-parse", "HEAD"])
        result["git_status_porcelain"] = _command_output(["git", "-C", str(llama_repo), "status", "--porcelain"])
    return result


def _command_output(cmd: list[str]) -> str | None:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15.0, check=False)
        text = (proc.stdout + ("\n" + proc.stderr if proc.stderr else "")).strip()
        return text or None
    except (OSError, subprocess.SubprocessError):
        return None
