from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

ReasoningEffort = Literal["true", "low", "medium", "high"]
Difficulty = Literal["hard", "expert", "challenge"]


@dataclass(frozen=True)
class GenerationConfig:
    max_tokens: int = 2048
    context_size: int = 8192
    temperature: float = 0.0
    top_p: float = 1.0
    top_k: int = 0
    min_p: float = 0.0
    repeat_penalty: float = 1.0
    seed: int = 42
    reasoning_effort: ReasoningEffort | None = None


@dataclass(frozen=True)
class InferenceRequest:
    sample_id: str
    messages: list[dict[str, str]]
    generation: GenerationConfig


@dataclass
class InferenceResult:
    content: str
    reasoning_content: str | None
    wall_time_s: float
    ttft_s: float | None
    load_time_s: float | None = None
    backend_total_time_s: float | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None
    prompt_tokens_per_s: float | None = None
    completion_tokens_per_s: float | None = None
    prompt_ms: float | None = None
    predicted_ms: float | None = None
    reasoning_tokens_estimate: int | None = None
    answer_tokens_estimate: int | None = None
    finish_reason: str | None = None
    raw_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BenchmarkSample:
    id: str
    category: str
    difficulty: Difficulty
    prompt: str
    grader: dict[str, Any]
    system_prompt: str | None = None
    tags: tuple[str, ...] = ()
    reasoning_effort_eval: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
