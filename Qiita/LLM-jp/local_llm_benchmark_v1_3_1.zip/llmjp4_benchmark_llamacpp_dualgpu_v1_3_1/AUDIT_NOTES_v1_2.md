# Audit notes for v1.2.0

v1.2.0 supersedes v1.1.0 for publishable model-quality scores.

A completed v1.1.0 LLM-jp-4-33B-thinking Q4_K_M run exposed the following benchmark-design issues:

1. **Numeric false negatives.** Many correct answers were rounded to ordinary scientific precision (for example 0.399 vs 0.3991265) but were rejected by tolerances as strict as 1e-5 or 1e-6. Simple exact fractions (`8/3`, `9/13`) and Unicode scientific notation (`-2.54×10^3`) were also parsed incorrectly.
2. **Hidden hallucination schema.** The hallucination-resistance prompts asked for JSON but did not reveal the exact `status`/`reason` key/value vocabulary required by `json_exact`; semantically correct abstentions were therefore scored as failures.
3. **Hidden code import policy.** Prompts allowed safe standard-library modules but did not disclose the allow-list; harmless `typing` and `__future__` imports were rejected.
4. **Reasoning output truncation.** With `max_tokens=2048`, 9/48 high-effort items and 2/128 medium Core items reached `finish_reason=length`, confounding reasoning-effort accuracy.
5. **Long-context probe was not actually near 8K.** The old 8K long-context phase averaged about 2604 input tokens. v1.2 sizes prompts using llama-server's token-count endpoint and targets about 80% of the configured context.
6. **One long-context JSON item had a hidden identifier-format assumption.** The prompt now explicitly requires `P`/`Q` IDs rather than names such as `装置P`.
7. **Resume keys now include the dataset SHA prefix**, preventing results from an older dataset version from being silently reused.

The v1.1.0 raw generations and timing measurements remain useful for diagnostic analysis, but its reported 62.5% Core accuracy and reasoning-effort score table should not be published as final model-quality results.

For model-to-model comparison, rerun every model on `core_v2.1.0.jsonl` with the same benchmark policy.
