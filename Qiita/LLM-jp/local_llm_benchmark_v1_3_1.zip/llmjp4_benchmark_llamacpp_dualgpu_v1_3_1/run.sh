#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$ROOT/.venv"
PY="$VENV/bin/python"
MODE="${1:-full}"

case "$MODE" in
  full|core|challenge|quick|report|validate) ;;
  -h|--help|help)
    cat <<'HELP'
Usage:
  ./run.sh            # full: Core 128 + reasoning subset + Challenge 80 + performance + long-context + report
  ./run.sh core       # Core 128 + reasoning subset + performance + long-context; skip Challenge
  ./run.sh challenge  # Challenge 80 only; DOES NOT rerun Core/reasoning/performance/long-context
  ./run.sh quick      # setup + unit tests + server + strict preflight only
  ./run.sh validate   # validate sealed Core and Challenge datasets only
  ./run.sh report     # rebuild reports from whatever results already exist

Canonical profile: LLM-jp llama.cpp, 8K context, tensor split 16:7, all GPU layers,
F16 K/V cache, Flash Attention on, prompt-cache reuse off, parallel=1.

`./run.sh challenge` is intended for the case where Core inference has already been completed.
Challenge results are written to results/challenge_medium_ctx8192/ and resume independently.

Optional path overrides:
  LLMJP_MODEL=/path/to/model.gguf
  LLMJP_LLAMA_SERVER=/path/to/llama-server
HELP
    exit 0 ;;
  *) echo "Unknown mode: $MODE" >&2; exit 2 ;;
esac

command -v python3 >/dev/null || { echo "ERROR: python3 is required" >&2; exit 2; }
if [[ "$MODE" != "report" && "$MODE" != "validate" ]]; then
  command -v nvidia-smi >/dev/null || { echo "ERROR: nvidia-smi is required" >&2; exit 2; }
fi

if [[ ! -x "$PY" ]]; then
  echo "[setup] Creating .venv"
  python3 -m venv "$VENV"
fi
REQ_HASH="$(sha256sum "$ROOT/requirements.txt" | awk '{print $1}')"
STAMP="$VENV/.requirements_sha256"
if [[ ! -f "$STAMP" || "$(cat "$STAMP")" != "$REQ_HASH" ]]; then
  echo "[setup] Installing Python dependencies"
  "$PY" -m pip install -q --upgrade pip
  "$PY" -m pip install -q -r "$ROOT/requirements.txt"
  printf '%s\n' "$REQ_HASH" > "$STAMP"
fi

cd "$ROOT"
exec "$PY" scripts/run_suite.py "$MODE" --config config/user.yaml
