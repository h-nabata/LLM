#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            out.append(obj)
    return out


def safe_num(v: Any) -> float | None:
    return float(v) if isinstance(v, (int, float)) and math.isfinite(float(v)) else None


def stats(values: list[Any]) -> dict[str, float | int | None]:
    vals = [float(x) for x in values if safe_num(x) is not None]
    if not vals:
        return {"n": 0, "mean": None, "median": None, "std": None, "min": None, "max": None}
    a = np.asarray(vals, dtype=float)
    return {
        "n": int(a.size), "mean": float(a.mean()), "median": float(np.median(a)),
        "std": float(a.std(ddof=1)) if a.size > 1 else 0.0,
        "min": float(a.min()), "max": float(a.max()),
    }


def wilson(k: int, n: int, z: float = 1.95996398454) -> tuple[float | None, float | None]:
    if n <= 0:
        return None, None
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def mcnemar_exact(a_pass: list[bool], b_pass: list[bool]) -> tuple[int, int, float]:
    # b01: A wrong -> B right; b10: A right -> B wrong.
    b01 = sum((not a) and b for a, b in zip(a_pass, b_pass))
    b10 = sum(a and (not b) for a, b in zip(a_pass, b_pass))
    d = b01 + b10
    if d == 0:
        return b01, b10, 1.0
    m = min(b01, b10)
    tail = sum(math.comb(d, i) for i in range(m + 1)) / (2 ** d)
    return b01, b10, min(1.0, 2.0 * tail)


def paired_bootstrap_delta(a_pass: list[bool], b_pass: list[bool], seed: int = 42, reps: int = 10000) -> tuple[float | None, float | None]:
    n = len(a_pass)
    if n == 0:
        return None, None
    rng = np.random.default_rng(seed)
    a = np.asarray(a_pass, dtype=float); b = np.asarray(b_pass, dtype=float)
    idx = rng.integers(0, n, size=(reps, n))
    diffs = (b[idx] - a[idx]).mean(axis=1)
    lo, hi = np.quantile(diffs, [0.025, 0.975])
    return float(lo), float(hi)


def savefig(fig: Any, path: Path, formats: list[str]) -> None:
    for ext in formats:
        fig.savefig(path.with_suffix("." + ext), bbox_inches="tight", dpi=180)
    plt.close(fig)


def reasoning_chars(row: dict[str, Any]) -> int | None:
    value = row.get("backend_metadata", {}).get("llama_cpp", {}).get("thinking_chars")
    return int(value) if isinstance(value, int) else None


def core_group_row(group_type: str, group: str, rr: list[dict[str, Any]], error_count: int = 0) -> dict[str, Any]:
    n = len(rr); k = sum(bool(r.get("score", {}).get("passed")) for r in rr); lo, hi = wilson(k, n)
    frac = [safe_num(r.get("score", {}).get("score")) for r in rr]
    frac = [x for x in frac if x is not None]
    return {
        "group_type": group_type, "group": group, "n_scored": n, "n_inference_errors": error_count,
        "n_truncated": sum(r.get("response", {}).get("finish_reason") == "length" for r in rr),
        "passed": k, "accuracy": k / n if n else None, "ci95_low": lo, "ci95_high": hi,
        "mean_fractional_score": float(np.mean(frac)) if frac else None,
        "mean_completion_tokens": stats([r.get("metrics", {}).get("completion_tokens") for r in rr])["mean"],
        "mean_reasoning_chars": stats([reasoning_chars(r) for r in rr])["mean"],
        "mean_wall_s": stats([r.get("metrics", {}).get("wall_time_s") for r in rr])["mean"],
        "mean_ttft_s": stats([r.get("metrics", {}).get("ttft_s") for r in rr])["mean"],
        "mean_prompt_tokens_per_s": stats([r.get("metrics", {}).get("prompt_tokens_per_s") for r in rr])["mean"],
        "mean_completion_tokens_per_s": stats([r.get("metrics", {}).get("completion_tokens_per_s") for r in rr])["mean"],
    }


def flatten_metric_stats(row: dict[str, Any], prefix: str, values: list[Any]) -> None:
    for key, val in stats(values).items():
        row[f"{prefix}_{key}"] = val


def aggregate_hardware(rr: list[dict[str, Any]], row: dict[str, Any]) -> None:
    flatten_metric_stats(row, "cpu_percent_mean", [r.get("hardware", {}).get("cpu_percent_mean") for r in rr])
    flatten_metric_stats(row, "ram_used_gib_max", [safe_num(r.get("hardware", {}).get("ram_used_bytes_max")) / (1024 ** 3) if safe_num(r.get("hardware", {}).get("ram_used_bytes_max")) is not None else None for r in rr])
    flatten_metric_stats(row, "gpu_energy_j_total", [r.get("hardware", {}).get("gpu_energy_j_total_estimate") for r in rr])
    vram_sums: list[float] = []; power_sums: list[float] = []; util_means: list[float] = []; temp_maxes: list[float] = []; jpt: list[float] = []
    for r in rr:
        gpus = r.get("hardware", {}).get("gpus", []) or []
        vr = [safe_num(g.get("memory_used_mib_max")) for g in gpus]; vr = [x for x in vr if x is not None]
        pw = [safe_num(g.get("power_draw_w_mean")) for g in gpus]; pw = [x for x in pw if x is not None]
        ut = [safe_num(g.get("utilization_gpu_percent_mean")) for g in gpus]; ut = [x for x in ut if x is not None]
        tp = [safe_num(g.get("temperature_c_max")) for g in gpus]; tp = [x for x in tp if x is not None]
        if vr: vram_sums.append(sum(vr))
        if pw: power_sums.append(sum(pw))
        if ut: util_means.append(float(np.mean(ut)))
        if tp: temp_maxes.append(max(tp))
        e = safe_num(r.get("hardware", {}).get("gpu_energy_j_total_estimate")); tok = safe_num(r.get("metrics", {}).get("completion_tokens"))
        if e is not None and tok is not None and tok > 0: jpt.append(e / tok)
    flatten_metric_stats(row, "vram_mib_max_sum", vram_sums)
    flatten_metric_stats(row, "gpu_power_w_mean_sum", power_sums)
    flatten_metric_stats(row, "gpu_utilization_percent_mean", util_means)
    flatten_metric_stats(row, "gpu_temperature_c_max", temp_maxes)
    flatten_metric_stats(row, "gpu_energy_j_per_completion_token", jpt)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, required=True)
    ap.add_argument("--dataset", type=Path, required=True)
    ap.add_argument("--challenge-dataset", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    a = ap.parse_args(); a.output_dir.mkdir(parents=True, exist_ok=True)
    figdir = a.output_dir / "figures"; figdir.mkdir(exist_ok=True); formats = ["png", "svg"]

    # ---- Core ----
    core_dirs = sorted([p for p in a.results.glob("core_*") if (p / "results.jsonl").exists()])
    core_rows = read_jsonl(core_dirs[-1] / "results.jsonl") if core_dirs else []
    ok = [r for r in core_rows if r.get("status") == "ok"]
    errors = [r for r in core_rows if r.get("status") == "error"]
    summary: list[dict[str, Any]] = []
    if core_rows:
        summary = [core_group_row("overall", "overall", ok, len(errors))]
        for group_key in ["category", "difficulty"]:
            groups = sorted({str(r.get("sample", {}).get(group_key)) for r in ok})
            for g in groups:
                rr = [r for r in ok if str(r.get("sample", {}).get(group_key)) == g]
                ee = [r for r in errors if str(r.get("sample", {}).get(group_key)) == g]
                summary.append(core_group_row(group_key, g, rr, len(ee)))
    df = pd.DataFrame(summary); df.to_csv(a.output_dir / "core_summary.csv", index=False)
    if not df.empty:
        cat = df[df.group_type == "category"].copy()
        if not cat.empty:
            fig, ax = plt.subplots(figsize=(9, 5)); ax.barh(cat["group"], cat["accuracy"]); ax.set_xlabel("Accuracy"); ax.set_xlim(0, 1); ax.set_title("Core v2.1.0 accuracy by category"); fig.tight_layout(); savefig(fig, figdir / "core_category_accuracy", formats)
        dif = df[df.group_type == "difficulty"]
        if not dif.empty:
            fig, ax = plt.subplots(figsize=(6, 4)); ax.bar(dif["group"], dif["accuracy"]); ax.set_ylim(0, 1); ax.set_ylabel("Accuracy"); ax.set_title("Core accuracy by difficulty"); fig.tight_layout(); savefig(fig, figdir / "core_difficulty_accuracy", formats)

    # ---- Challenge ----
    challenge_dirs = sorted([p for p in a.results.glob("challenge_*") if (p / "results.jsonl").exists()])
    challenge_rows = read_jsonl(challenge_dirs[-1] / "results.jsonl") if challenge_dirs else []
    chok = [r for r in challenge_rows if r.get("status") == "ok"]
    cherr = [r for r in challenge_rows if r.get("status") == "error"]
    chsummary: list[dict[str, Any]] = []
    if challenge_rows:
        chsummary = [core_group_row("overall", "overall", chok, len(cherr))]
        for group_key in ["category", "difficulty"]:
            groups = sorted({str(r.get("sample", {}).get(group_key)) for r in chok})
            for g in groups:
                rr = [r for r in chok if str(r.get("sample", {}).get(group_key)) == g]
                ee = [r for r in cherr if str(r.get("sample", {}).get(group_key)) == g]
                chsummary.append(core_group_row(group_key, g, rr, len(ee)))
    chdf = pd.DataFrame(chsummary); chdf.to_csv(a.output_dir / "challenge_summary.csv", index=False)
    if not chdf.empty:
        cat = chdf[chdf.group_type == "category"].copy()
        if not cat.empty:
            fig, ax = plt.subplots(figsize=(9, 5)); ax.barh(cat["group"], cat["accuracy"]); ax.set_xlabel("Accuracy"); ax.set_xlim(0, 1); ax.set_title("Challenge v1.0.0 accuracy by category"); fig.tight_layout(); savefig(fig, figdir / "challenge_category_accuracy", formats)

    # Track-level summary deliberately keeps Core and Challenge separate; no arbitrary weighted score.
    track_rows: list[dict[str, Any]] = []
    for track, table in [("core", df), ("challenge", chdf)]:
        if not table.empty:
            oo = table[(table["group_type"] == "overall") & (table["group"] == "overall")]
            if not oo.empty:
                row = oo.iloc[0].to_dict(); row["track"] = track; track_rows.append(row)
    track_df = pd.DataFrame(track_rows)
    if not track_df.empty:
        cols = ["track"] + [c for c in track_df.columns if c != "track"]
        track_df = track_df[cols]
    track_df.to_csv(a.output_dir / "track_summary.csv", index=False)

    # ---- Reasoning effort and paired comparisons ----
    effort_rows: dict[str, list[dict[str, Any]]] = {}
    sources = {
        "low": list(a.results.glob("reasoning_low_*/results.jsonl")),
        "medium": [core_dirs[-1] / "results.jsonl"] if core_dirs else [],
        "high": list(a.results.glob("reasoning_high_*/results.jsonl")),
    }
    reasoning: list[dict[str, Any]] = []
    for effort, paths in sources.items():
        rr = read_jsonl(paths[-1]) if paths else []
        rr = [r for r in rr if r.get("status") == "ok" and (effort != "medium" or (r.get("sample", {}).get("reasoning_effort_eval") and r.get("generation", {}).get("reasoning_effort") == "medium"))]
        effort_rows[effort] = rr
        if rr:
            n = len(rr); k = sum(bool(r.get("score", {}).get("passed")) for r in rr); lo, hi = wilson(k, n)
            reasoning.append({
                "effort": effort, "n": n, "passed": k, "accuracy": k / n,
                "n_truncated": sum(r.get("response", {}).get("finish_reason") == "length" for r in rr),
                "ci95_low": lo, "ci95_high": hi,
                "mean_wall_s": stats([r.get("metrics", {}).get("wall_time_s") for r in rr])["mean"],
                "mean_ttft_s": stats([r.get("metrics", {}).get("ttft_s") for r in rr])["mean"],
                "mean_completion_tokens": stats([r.get("metrics", {}).get("completion_tokens") for r in rr])["mean"],
                "mean_reasoning_chars": stats([reasoning_chars(r) for r in rr])["mean"],
                "mean_completion_tokens_per_s": stats([r.get("metrics", {}).get("completion_tokens_per_s") for r in rr])["mean"],
            })
    rdf = pd.DataFrame(reasoning); rdf.to_csv(a.output_dir / "reasoning_summary.csv", index=False)
    pair_rows: list[dict[str, Any]] = []
    for aa, bb in [("low", "medium"), ("medium", "high"), ("low", "high")]:
        ma = {str(r.get("sample", {}).get("id")): bool(r.get("score", {}).get("passed")) for r in effort_rows.get(aa, [])}
        mb = {str(r.get("sample", {}).get("id")): bool(r.get("score", {}).get("passed")) for r in effort_rows.get(bb, [])}
        ids = sorted(set(ma) & set(mb))
        if not ids: continue
        av = [ma[i] for i in ids]; bv = [mb[i] for i in ids]
        b01, b10, p = mcnemar_exact(av, bv); lo, hi = paired_bootstrap_delta(av, bv)
        pair_rows.append({
            "condition_a": aa, "condition_b": bb, "n_paired": len(ids),
            "accuracy_a": float(np.mean(av)), "accuracy_b": float(np.mean(bv)),
            "delta_b_minus_a": float(np.mean(bv) - np.mean(av)),
            "paired_bootstrap_ci95_low": lo, "paired_bootstrap_ci95_high": hi,
            "a_wrong_b_right": b01, "a_right_b_wrong": b10, "mcnemar_exact_p": p,
        })
    pdf = pd.DataFrame(pair_rows); pdf.to_csv(a.output_dir / "reasoning_paired_comparisons.csv", index=False)
    if not rdf.empty:
        order = [x for x in ["low", "medium", "high"] if x in set(rdf.effort)]; rr = rdf.set_index("effort").loc[order].reset_index()
        fig, ax = plt.subplots(figsize=(6, 4)); ax.bar(rr.effort, rr.accuracy); ax.set_ylim(0, 1); ax.set_ylabel("Accuracy"); ax.set_title("Reasoning effort vs accuracy"); fig.tight_layout(); savefig(fig, figdir / "reasoning_accuracy", formats)
        fig, ax = plt.subplots(figsize=(6, 4)); ax.bar(rr.effort, rr.mean_wall_s); ax.set_ylabel("Mean wall time (s)"); ax.set_title("Reasoning effort vs latency"); fig.tight_layout(); savefig(fig, figdir / "reasoning_latency", formats)

    # ---- Context performance: full repeated statistics + hardware ----
    sys_rows = [r for r in read_jsonl(a.results / "context_performance" / "system_results.jsonl") if r.get("kind") == "measured"]
    crows: list[dict[str, Any]] = []
    for ctx in sorted({int(r["context"]) for r in sys_rows if isinstance(r.get("context"), int)}):
        all_ctx = [r for r in sys_rows if r.get("context") == ctx]; rr = [r for r in all_ctx if r.get("status") == "ok"]
        row: dict[str, Any] = {"context": ctx, "n_ok": len(rr), "n_errors": len(all_ctx) - len(rr)}
        for key in ["load_time_s", "wall_time_s", "ttft_s", "prompt_tokens_per_s", "completion_tokens_per_s", "prompt_tokens", "completion_tokens"]:
            flatten_metric_stats(row, key, [r.get("metrics", {}).get(key) for r in rr])
        flatten_metric_stats(row, "target_prompt_tokens", [r.get("target_prompt_tokens") for r in rr])
        flatten_metric_stats(row, "counted_prompt_tokens_before_inference", [r.get("counted_prompt_tokens_before_inference") for r in rr])
        flatten_metric_stats(row, "prompt_context_fraction", [
            (safe_num(r.get("metrics", {}).get("prompt_tokens")) / ctx) if safe_num(r.get("metrics", {}).get("prompt_tokens")) is not None else None
            for r in rr
        ])
        aggregate_hardware(rr, row); crows.append(row)
    cdf = pd.DataFrame(crows); cdf.to_csv(a.output_dir / "context_performance.csv", index=False)
    if not cdf.empty:
        for key, filename, title, ylabel in [
            ("completion_tokens_per_s_mean", "completion_tokens_per_s", "Context size vs generation speed", "Tokens/s"),
            ("prompt_tokens_per_s_mean", "prompt_tokens_per_s", "Context size vs prompt speed", "Tokens/s"),
            ("vram_mib_max_sum_max", "vram_mib_max_sum", "Context size vs measured VRAM", "VRAM used (MiB)"),
        ]:
            if key not in cdf.columns: continue
            dd = cdf.dropna(subset=[key]);
            if dd.empty: continue
            fig, ax = plt.subplots(figsize=(7, 4)); ax.plot(dd.context, dd[key], marker="o"); ax.set_xscale("log", base=2); ax.set_xlabel("Configured context"); ax.set_ylabel(ylabel); ax.set_title(title); fig.tight_layout(); savefig(fig, figdir / filename, formats)

    # ---- Long-context accuracy ----
    lrows = read_jsonl(a.results / "long_context_accuracy" / "results.jsonl"); long_rows: list[dict[str, Any]] = []
    for ctx in sorted({int(r["context"]) for r in lrows if isinstance(r.get("context"), int)}):
        rr = [r for r in lrows if r.get("context") == ctx]; good = [r for r in rr if r.get("status") == "ok"]; k = sum(bool(r.get("score", {}).get("passed")) for r in good); lo, hi = wilson(k, len(rr))
        mean_prompt = stats([r.get("metrics", {}).get("prompt_tokens") for r in good])["mean"]
        long_rows.append({"context": ctx, "n_target": len(rr), "n_responses": len(good), "n_errors": len(rr)-len(good), "passed": k, "accuracy_over_target": k/len(rr) if rr else None, "ci95_low": lo, "ci95_high": hi, "mean_prompt_tokens": mean_prompt, "mean_prompt_context_fraction": (mean_prompt/ctx if mean_prompt is not None else None), "mean_target_prompt_tokens": stats([r.get("target_prompt_tokens") for r in good])["mean"], "mean_wall_s": stats([r.get("metrics", {}).get("wall_time_s") for r in good])["mean"]})
    ldf = pd.DataFrame(long_rows); ldf.to_csv(a.output_dir / "long_context_summary.csv", index=False)
    if not ldf.empty:
        fig, ax = plt.subplots(figsize=(7, 4)); ax.plot(ldf.context, ldf.accuracy_over_target, marker="o"); ax.set_xscale("log", base=2); ax.set_ylim(0, 1); ax.set_xlabel("Configured context"); ax.set_ylabel("Accuracy"); ax.set_title("Long-context accuracy"); fig.tight_layout(); savefig(fig, figdir / "long_context_accuracy", formats)

    # ---- VRAM margin sweep ----
    mrows: list[dict[str, Any]] = []
    for p in sorted(a.results.glob("vram_margin_*")):
        if not p.is_dir(): continue
        try: target = int(p.name.rsplit("_", 1)[1])
        except ValueError: continue
        rr0 = [r for r in read_jsonl(p / "system_results.jsonl") if r.get("kind") == "measured"]
        rr = [r for r in rr0 if r.get("status") == "ok"]
        row: dict[str, Any] = {"fit_target_mib_per_gpu": target, "n_ok": len(rr), "n_errors": len(rr0)-len(rr)}
        for key in ["wall_time_s", "ttft_s", "prompt_tokens_per_s", "completion_tokens_per_s"]:
            flatten_metric_stats(row, key, [r.get("metrics", {}).get(key) for r in rr])
        aggregate_hardware(rr, row); mrows.append(row)
    mdf = pd.DataFrame(mrows).sort_values("fit_target_mib_per_gpu") if mrows else pd.DataFrame(); mdf.to_csv(a.output_dir / "vram_margin_summary.csv", index=False)
    if not mdf.empty and "completion_tokens_per_s_mean" in mdf.columns:
        dd = mdf.dropna(subset=["completion_tokens_per_s_mean"])
        if not dd.empty:
            fig, ax = plt.subplots(figsize=(7, 4)); ax.plot(dd.fit_target_mib_per_gpu, dd.completion_tokens_per_s_mean, marker="o"); ax.set_xlabel("llama.cpp fit target per GPU (MiB)"); ax.set_ylabel("Generation tokens/s"); ax.set_title("VRAM fit target vs generation speed"); fig.tight_layout(); savefig(fig, figdir / "vram_margin_speed", formats)

    # ---- Failures ----
    fail_counts: dict[tuple[str, str], int] = {}
    sources_for_fail = [("core", core_rows), ("challenge", challenge_rows), ("context", sys_rows), ("long_context", lrows)]
    for p in a.results.glob("reasoning_*_*/results.jsonl"):
        sources_for_fail.append((p.parent.name, read_jsonl(p)))
    for phase, rows in sources_for_fail:
        for r in rows:
            if r.get("status") == "error":
                key = (phase, str(r.get("error_class") or "unknown")); fail_counts[key] = fail_counts.get(key, 0) + 1
    fdf = pd.DataFrame([{"phase": p, "error_class": e, "count": n} for (p, e), n in sorted(fail_counts.items())]); fdf.to_csv(a.output_dir / "failure_summary.csv", index=False)

    # ---- Markdown ----
    manifest = a.results / "run_manifest.json"; env = a.results / "environment.json"; md = ["# Benchmark result summary", ""]
    if manifest.exists():
        mm = json.loads(manifest.read_text()); md += ["## Run status", "", "| Phase | Status |", "|---|---|"] + [f"| {x.get('name')} | {x.get('status')} |" for x in mm.get("phases", [])] + [""]
    for title, table in [("Track overview", track_df), ("Core results", df), ("Challenge results", chdf), ("Reasoning effort", rdf), ("Paired reasoning comparisons", pdf), ("Context performance", cdf), ("Long-context accuracy", ldf), ("VRAM margin sweep (disabled in canonical profile unless data exist)", mdf), ("Failures", fdf)]:
        md += [f"## {title}", ""]
        md.append("No data." if table.empty else table.to_markdown(index=False, floatfmt=".4f")); md.append("")
    md += ["## Interpretation note", "", "Core and Challenge are reported as separate tracks. Challenge is intentionally harder and exactly category-balanced; do not average the two into a single score without declaring a weighting rule. Reasoning-effort differences should be interpreted with the paired confidence interval and exact McNemar p-value. Any non-zero n_truncated means the comparison is completion-budget-confounded and should be treated cautiously.", ""]
    (a.output_dir / "benchmark_results.md").write_text("\n".join(md), encoding="utf-8")

    # ---- Conditions ----
    cond = ["# Experiment conditions", "", f"- Core dataset: `{a.dataset.name}`", f"- Core dataset SHA256: `{hashlib.sha256(a.dataset.read_bytes()).hexdigest()}`", f"- Challenge dataset: `{a.challenge_dataset.name}`", f"- Challenge dataset SHA256: `{hashlib.sha256(a.challenge_dataset.read_bytes()).hexdigest()}`"]
    if env.exists():
        e = json.loads(env.read_text()); cond.append(f"- CPU: {e.get('cpu', {}).get('model')}"); cond.append(f"- RAM bytes: {e.get('ram', {}).get('total_bytes')}")
        for g in e.get("selected_gpus", []): cond.append(f"- GPU: {g.get('name')} / {g.get('memory_total_mib')} MiB / {g.get('uuid')}")
        cond.append(f"- llama.cpp: {e.get('llama_cpp', {}).get('version_output')}")
        cfg = e.get("benchmark_config", {})
        cond.append(f"- Model: `{cfg.get('model', {}).get('name')}`")
        cond.append(f"- Model SHA256: `{e.get('model', {}).get('verified_sha256') or e.get('model', {}).get('declared_sha256')}`")
        cond.append(f"- Core context: {cfg.get('quality', {}).get('context')}")
        cond.append(f"- Tensor split: {cfg.get('server', {}).get('tensor_split')}")
        cond.append(f"- GPU layers: {cfg.get('server', {}).get('n_gpu_layers')}")
        cond.append(f"- Split mode: {cfg.get('server', {}).get('split_mode')}")
        cond.append(f"- KV cache: K={cfg.get('server', {}).get('cache_type_k')}, V={cfg.get('server', {}).get('cache_type_v')}")
        cond.append(f"- Flash Attention: {cfg.get('server', {}).get('flash_attention')}")
        cond.append(f"- Prompt cache RAM MiB: {cfg.get('server', {}).get('cache_ram_mib')}")
        cond.append(f"- Force cuBLAS required: {cfg.get('server', {}).get('require_force_cublas')}")
    (a.output_dir / "experiment_conditions.md").write_text("\n".join(cond) + "\n", encoding="utf-8")
    print(f"Report written to {a.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
