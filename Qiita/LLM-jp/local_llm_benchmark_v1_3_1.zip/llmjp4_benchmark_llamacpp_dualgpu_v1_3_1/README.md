# LLM-jp-4 Local Benchmark v1.3.1 — Core 128 + Challenge 80 / llama.cpp dual-GPU 8K

LLM-jp-4-33B-thinking Q4_K_M を、RTX 5070 Ti 16 GB + RTX 3070 Ti 8 GB の固定デュアルGPU条件で再現性高く評価するベンチマークです。

v1.3.1では、v1.2.0で修正したCore 128問を**一切変更せず保持**したまま、天井効果を抑えるための独立した **Challenge 80問** を追加しました。ChallengeはCoreと同じ10領域を各8問ずつ含み、短い8K contextの範囲内で、推論深度・複数制約・因果識別・境界条件・科学的複合計算・hallucination耐性を強化しています。

この版は **LLM-jp fork of llama.cpp** を直接使用します。RTX 5070 Ti (Blackwell) で観測したMMQ `mmq_x_best=0` クラッシュ回避のため、既定では `GGML_CUDA_FORCE_CUBLAS=ON` でビルドした `llama-server` を要求します。

## Tracks

### Core v2.1.0

- 128問
- 広い能力範囲と長期比較の安定性を重視
- 48問をlow / medium / high reasoning比較に固定
- v1.2.0からbit-for-bitで変更なし

### Challenge v1.0.0

- 80問
- Coreと同じ10カテゴリ × 各8問
- medium reasoning固定
- 30B級reasoning model間の天井効果を減らすことを目的とする
- Coreとは別スコアとして報告

| Challenge category | Items |
|---|---:|
| advanced_japanese | 8 |
| analytical_reasoning | 8 |
| mathematics_statistics | 8 |
| coding | 8 |
| physics_engineering | 8 |
| chemistry_materials | 8 |
| life_information | 8 |
| humanities_social_economics | 8 |
| hallucination_resistance | 8 |
| instruction_following | 8 |
| **Total** | **80** |

Challenge grader構成は numeric 35 / choice 21 / JSON 16 / Python unit test 8 です。詳細は `datasets/CHALLENGE_DESIGN.md` を参照してください。

## Canonical profile

- model: LLM-jp-4-33B-thinking Q4_K_M
- context: **8192**
- split mode: `layer`
- tensor split: **`16,7`**
- GPU layers: **`all`**
- KV cache: **K=f16, V=f16**
- Flash Attention: on
- `-fit off`
- `--parallel 1`
- `--cache-ram 0`
- request-level `cache_prompt=false`
- Jinja chat template: on
- reasoning: on
- Core / Challenge main comparison: medium

8Kでは全層GPU offloadが成立するため、16Kで必要になるCPU offloadやKV-cache量子化を品質評価へ混入させません。

## Prerequisites

- Windows 11 + WSL2 Ubuntu
- NVIDIA driver visible from WSL (`nvidia-smi`)
- Python 3 + `python3-venv`
- RTX 5070 Ti 16 GB + RTX 3070 Ti 8 GB
- LLM-jp fork of llama.cpp
- CUDA版 `llama-server` built with `GGML_CUDA_FORCE_CUBLAS=ON`
- local Q4_K_M GGUF

既定パス:

```text
llama-server: ~/llama.cpp-llmjp/build-cublas/bin/llama-server
model: /usr/share/ollama/.ollama/models/blobs/sha256-12c23619261c824f88facec565a4b6750d2b0872db7e57f6289ad677822e00dd
```

別パスの場合:

```bash
export LLMJP_LLAMA_SERVER=/path/to/llama-server
export LLMJP_MODEL=/path/to/llm-jp-4-33b-thinking-Q4_K_M.gguf
```

## Execution

### Full benchmark

```bash
chmod +x run.sh
./run.sh
```

順に、dataset seal検証 → unit tests → model/server/preflight → Core 128 → low/high reasoning subset → Challenge 80 → 8K performance → 8K long-context → report を実行します。

### Core inference is already complete: run Challenge only

```bash
./run.sh challenge
```

これは今回追加した重要なモードです。以下は**実行しません**。

- Core 128
- reasoning low/high 48問
- context-performance probe
- long-context probe

一方、再現性・安全性のため、dataset SHA検証、unit tests、model SHA検証、llama-server自動起動、strict preflightは実行します。

Challenge結果は独立して

```text
results/challenge_medium_ctx8192/
```

へ保存されます。中断しても再度 `./run.sh challenge` を実行すれば完了済みitemをskipしてresumeします。

### Core track only

```bash
./run.sh core
```

v1.2.0相当のCore + reasoning + performance + long-contextを実行し、Challengeを省略します。

### Other modes

```bash
./run.sh quick      # server起動 + strict preflightまで
./run.sh validate   # Core/Challenge dataset検証
./run.sh report     # 既存resultからreport再生成
```

## v1.2 scoring/audit fixes retained

v1.3.1はv1.2.0の以下の修正を全て維持しています。

- 数値問題は通常の科学的丸めを許容し、分数と`a×10^b`表記を安全にparse
- hallucination項目ではgraderが要求するschema/labelをpromptに明示
- coding import allow-listをpromptに明示し、`typing`, `__future__`を許可
- Core/reasoning `max_tokens=4096`
- long-context/performance promptはllama-serverのtoken countで実際の長さを調整
- resume keyにdataset SHA prefixを含める

詳細: `AUDIT_NOTES_v1_2.md`

## Challenge calibration policy

Challengeは「特定モデルに勝たせる/負けさせる」ために結果を見て調整してはいけません。v1.0.0はSHA256でsealされます。実測後に難しすぎる/易しすぎることが判明した場合は、既存v1.0.0を編集せず、新しいdataset versionを発行してください。

そのため、LLM-jpとQwen3.8を比較する場合も、**同一のChallenge v1.0.0を両方に一度ずつ適用**するのが基本です。

## Prompt caching

llama.cppのprefix cacheによる性能値汚染を避けるため、サーバ側 `--cache-ram 0` に加え、各requestで `cache_prompt=false` を明示します。

## Outputs

```text
results/
├── environment.json
├── preflight.json
├── run_manifest.json
├── logs/llama_server.log
├── core_medium_ctx8192/
├── reasoning_low_ctx8192/
├── reasoning_high_ctx8192/
├── challenge_medium_ctx8192/
├── context_performance/
├── long_context_accuracy/
└── report/
    ├── experiment_conditions.md
    ├── benchmark_results.md
    ├── track_summary.csv
    ├── core_summary.csv
    ├── challenge_summary.csv
    ├── reasoning_summary.csv
    ├── reasoning_paired_comparisons.csv
    ├── context_performance.csv
    ├── long_context_summary.csv
    ├── failure_summary.csv
    └── figures/
```

CoreとChallengeは別trackとして表示します。標準reportでは恣意的な加重平均を作りません。

## Dataset governance

- Core: `datasets/core_v2.1.0.jsonl` + `datasets/MANIFEST.json`
- Challenge: `datasets/challenge_v1.1.0.jsonl` + `datasets/CHALLENGE_MANIFEST.json`

問題文・正答・grader・hidden unit testの変更は必ずdataset versionを上げて行ってください。

## Publication notes

記事では最低限以下を明記してください。

- model GGUF名とSHA256
- llama.cpp fork / commit / build version
- `GGML_CUDA_FORCE_CUBLAS=ON`
- GPU構成
- context 8192
- tensor split 16:7
- `-ngl all`
- K=f16 / V=f16
- Flash Attention on
- prompt-cache reuse off
- deterministic sampling設定
- Core dataset version/hash
- Challenge dataset version/hash

Q4_K_Mの量子化損失自体を論じるには、同一datasetを高精度quant/BF16 referenceでも評価する必要があります。
