# Benchmark datasets

## Core v2.1.0

`core_v2.1.0.jsonl` is the fixed longitudinal Core set.

- 128 newly authored Japanese-language items.
- Difficulty labels: `hard` and `expert`.
- 48 items are frozen in advance as the paired reasoning-effort subset.
- Any edit to prompt, expected answer, grader, or hidden unit test requires a new Core dataset version and SHA256.
- Seal: `MANIFEST.json`.

## Challenge v1.1.0

`challenge_v1.1.0.jsonl` is the separate ceiling-reduction / model-discrimination track.

- 80 newly authored items.
- Exactly 8 items in each of the same 10 categories used by Core.
- Difficulty label: `challenge`.
- Medium-reasoning controlled comparison only in this release; it is not part of the low/medium/high reasoning-effort subset.
- Any edit requires a new Challenge dataset version and SHA256.
- Seal: `CHALLENGE_MANIFEST.json`.
- Design rationale and category/grader counts: `CHALLENGE_DESIGN.md`.

No public benchmark item text from GSM8K, MMLU, GPQA, HumanEval, etc. is copied into either dataset.

Coding items use local unit-test grading. Generated Python is AST-screened; unsafe imports, shell/file/network-oriented modules and dangerous builtins are rejected before execution. The sandbox is a best-effort grading isolation mechanism, not a general-purpose security boundary.
